<?php
/**
 * テーマの起点。inc/ 以下の機能ファイルを読み込むだけにして、役割ごとにファイルを分けている。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

define( 'RYUGAKU_VERSION', '1.0.0' );
define( 'RYUGAKU_DIR', get_template_directory() );
define( 'RYUGAKU_URI', get_template_directory_uri() );

$ryugaku_includes = array(
	'inc/helpers.php',
	'inc/setup.php',
	'inc/post-types.php',
	'inc/meta-boxes.php',
	'inc/customizer.php',
	'inc/seo.php',
	'inc/performance.php',
	'inc/query.php',
	'inc/contact.php',
	'inc/demo-content.php',
	'inc/admin.php',
);

foreach ( $ryugaku_includes as $ryugaku_file ) {
	require_once RYUGAKU_DIR . '/' . $ryugaku_file;
}
