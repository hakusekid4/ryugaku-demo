<?php
/**
 * 学校詳細。特徴・コース・滞在方法・おすすめ・基本情報・同じ国の学校。
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_id      = get_the_ID();
$ryugaku_country = ryugaku_school_country( $ryugaku_id );
$ryugaku_courses = ryugaku_meta_pairs( 'school_courses' );
$ryugaku_accom   = ryugaku_meta_pairs( 'school_accommodation' );
$ryugaku_others  = $ryugaku_country ? get_posts( array( 'post_type' => 'school', 'posts_per_page' => 3, 'post__not_in' => array( $ryugaku_id ), 'meta_key' => '_ryugaku_school_country', 'meta_value' => $ryugaku_country->ID ) ) : array();
?>
<article class="school">
	<section class="detail-hero">
		<div class="container detail-hero__inner">
			<div class="detail-hero__text">
				<?php if ( $ryugaku_country ) : ?>
					<p class="eyebrow"><a href="<?php echo esc_url( get_permalink( $ryugaku_country ) ); ?>"><?php echo esc_html( ryugaku_flag( $ryugaku_country->ID ) . ' ' . $ryugaku_country->post_title ); ?></a><?php echo ryugaku_meta( 'school_city' ) ? esc_html( ' / ' . ryugaku_meta( 'school_city' ) ) : ''; ?></p>
				<?php endif; ?>
				<h1 class="detail-hero__title"><?php the_title(); ?></h1>
				<?php if ( ryugaku_meta( 'school_rating' ) ) : ?>
					<?php ryugaku_stars( ryugaku_meta( 'school_rating' ) ); ?>
				<?php endif; ?>
				<?php if ( has_excerpt() ) : ?>
					<p class="detail-hero__catch"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
				<dl class="spec-list">
					<div><dt>4週間の費用目安</dt><dd><?php echo esc_html( ryugaku_man( ryugaku_meta( 'school_cost_4w', '' ) ) ); ?>〜</dd></div>
					<div><dt>最短期間</dt><dd><?php echo esc_html( ryugaku_meta( 'school_min_weeks', '1' ) ); ?>週間〜</dd></div>
					<div><dt>定員</dt><dd><?php echo esc_html( ryugaku_meta( 'school_capacity', '—' ) ); ?>名</dd></div>
					<div><dt>日本人比率</dt><dd><?php echo esc_html( ryugaku_meta( 'school_japanese_ratio', '—' ) ); ?></dd></div>
					<div><dt>設立</dt><dd><?php echo esc_html( ryugaku_meta( 'school_founded', '—' ) ); ?></dd></div>
				</dl>
				<?php ryugaku_cta_buttons( '', false ); ?>
			</div>
			<div class="detail-hero__media">
				<?php ryugaku_thumbnail( 'ryugaku-hero' ); ?>
			</div>
		</div>
	</section>

	<section class="section">
		<div class="container container--narrow">
			<?php ryugaku_section_title( '学校の特徴', 'FEATURES', '', 'left' ); ?>
			<?php ryugaku_check_list( ryugaku_meta_lines( 'school_features' ), 'check-list check-list--grid' ); ?>
			<?php if ( get_the_content() ) : ?>
				<div class="prose"><?php the_content(); ?></div>
			<?php endif; ?>
		</div>
	</section>

	<?php if ( $ryugaku_courses ) : ?>
		<section class="section section--tint">
			<div class="container container--narrow">
				<?php ryugaku_section_title( 'コース', 'COURSES', '', 'left' ); ?>
				<div class="table-wrap">
					<table class="price-table price-table--compact">
						<tbody>
							<?php foreach ( $ryugaku_courses as $ryugaku_row ) : ?>
								<tr><th scope="row"><?php echo esc_html( $ryugaku_row[0] ); ?></th><td><?php echo esc_html( $ryugaku_row[1] ); ?></td></tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $ryugaku_accom ) : ?>
		<section class="section">
			<div class="container container--narrow">
				<?php ryugaku_section_title( '滞在方法', 'ACCOMMODATION', '', 'left' ); ?>
				<div class="grid grid--2">
					<?php foreach ( $ryugaku_accom as $ryugaku_row ) : ?>
						<div class="info-card"><h3><?php echo esc_html( $ryugaku_row[0] ); ?></h3><p><?php echo esc_html( $ryugaku_row[1] ); ?></p></div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( ryugaku_meta_lines( 'school_recommended' ) ) : ?>
		<section class="section section--tint">
			<div class="container container--narrow">
				<?php ryugaku_section_title( 'こんな人におすすめ', 'RECOMMENDED', '', 'left' ); ?>
				<?php ryugaku_check_list( ryugaku_meta_lines( 'school_recommended' ), 'check-list check-list--cards' ); ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="section">
		<div class="container container--narrow">
			<?php ryugaku_section_title( '基本情報', 'INFO', '', 'left' ); ?>
			<div class="table-wrap">
				<table class="price-table price-table--compact">
					<tbody>
						<tr><th scope="row">学校名</th><td><?php the_title(); ?></td></tr>
						<?php if ( $ryugaku_country ) : ?><tr><th scope="row">国・都市</th><td><?php echo esc_html( $ryugaku_country->post_title . ' / ' . ryugaku_meta( 'school_city' ) ); ?></td></tr><?php endif; ?>
						<?php if ( ryugaku_meta( 'school_address' ) ) : ?><tr><th scope="row">住所</th><td><?php echo esc_html( ryugaku_meta( 'school_address' ) ); ?></td></tr><?php endif; ?>
						<?php if ( ryugaku_meta( 'school_website' ) ) : ?><tr><th scope="row">公式サイト</th><td><a href="<?php echo esc_url( ryugaku_meta( 'school_website' ) ); ?>" target="_blank" rel="noopener nofollow"><?php echo esc_html( ryugaku_meta( 'school_website' ) ); ?></a></td></tr><?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</section>

	<?php if ( $ryugaku_others ) : ?>
		<section class="section section--tint">
			<div class="container">
				<?php ryugaku_section_title( $ryugaku_country->post_title . 'のほかの学校', 'MORE SCHOOLS', '', 'left' ); ?>
				<div class="grid grid--3">
					<?php
					global $post;
					foreach ( $ryugaku_others as $post ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride
						setup_postdata( $post );
						get_template_part( 'template-parts/card', 'school' );
					endforeach;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<section class="section">
		<div class="container inline-cta">
			<h2 class="inline-cta__title"><?php the_title(); ?>の空き状況・見積もりを確認する</h2>
			<p>最新の料金・キャンペーン・空室状況はカウンセラーがすぐにお調べします。</p>
			<?php ryugaku_cta_buttons(); ?>
		</div>
	</section>
</article>
<?php get_footer(); ?>
