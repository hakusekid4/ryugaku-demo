<?php
/**
 * 全ページ共通のフッター。CTA 帯・フッターメニュー・規約リンク・スマホ固定 CTA。
 *
 * @package Ryugaku
 */
?>
</main>

<?php if ( ! is_page_template( 'page-templates/contact.php' ) && ! is_404() ) : ?>
	<?php get_template_part( 'template-parts/cta-band' ); ?>
<?php endif; ?>

<footer class="site-footer">
	<div class="container">
		<div class="site-footer__grid">
			<div class="site-footer__brand">
				<a class="site-logo site-logo--footer" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<span class="site-logo__mark" aria-hidden="true">✈</span>
					<span class="site-logo__text"><?php bloginfo( 'name' ); ?></span>
				</a>
				<p class="site-footer__desc"><?php bloginfo( 'description' ); ?></p>
				<?php if ( ryugaku_option( 'phone', '' ) ) : ?>
					<p class="site-footer__tel">TEL：<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', ryugaku_option( 'phone' ) ) ); ?>"><?php echo esc_html( ryugaku_option( 'phone' ) ); ?></a><br><small><?php echo esc_html( ryugaku_option( 'business_hours', '' ) ); ?></small></p>
				<?php endif; ?>
				<div class="site-footer__cta">
					<a class="btn btn--line btn--sm" href="<?php echo ryugaku_line_url(); ?>" target="_blank" rel="noopener"><span class="btn__icon"><?php echo ryugaku_icon( 'line' ); ?></span>LINEで無料相談</a>
				</div>
			</div>
			<div class="site-footer__nav">
				<h2 class="site-footer__heading">留学を探す・知る</h2>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'container'      => false,
						'menu_class'     => 'footer-menu',
						'fallback_cb'    => 'ryugaku_fallback_footer_menu',
						'depth'          => 1,
					)
				);
				?>
			</div>
			<div class="site-footer__nav">
				<h2 class="site-footer__heading">会社情報・規約</h2>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'legal',
						'container'      => false,
						'menu_class'     => 'footer-menu footer-menu--legal',
						'fallback_cb'    => 'ryugaku_fallback_legal_menu',
						'depth'          => 1,
					)
				);
				?>
			</div>
		</div>
		<p class="site-footer__copy">&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( ryugaku_option( 'company_name', get_bloginfo( 'name' ) ) ); ?></p>
	</div>
</footer>

<div class="mobile-cta" aria-label="相談する">
	<a class="mobile-cta__line" href="<?php echo ryugaku_line_url(); ?>" target="_blank" rel="noopener"><?php echo ryugaku_icon( 'line' ); ?>LINEで相談</a>
	<a class="mobile-cta__primary" href="<?php echo ryugaku_counseling_url(); ?>"><?php echo ryugaku_icon( 'calendar' ); ?>無料カウンセリング</a>
</div>

<?php wp_footer(); ?>
</body>
</html>
