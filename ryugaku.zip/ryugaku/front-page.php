<?php
/**
 * トップページ(HOME)。ファーストビュー → LINE 相談 → カウンセリング → 国診断 → 人気国 → タイプ → 理由 → 料金 → 体験談 → コラム の順。
 *
 * @package Ryugaku
 */

get_header();

$ryugaku_hero_title = ryugaku_option( 'hero_title', "あなたに合う留学が、\nきっと見つかる。" );
$ryugaku_hero_lead  = ryugaku_option( 'hero_lead', '' );
$ryugaku_hero_image = ryugaku_option( 'hero_image', '' );
$ryugaku_stats      = array();
for ( $i = 1; $i <= 4; $i++ ) {
	$raw = ryugaku_option( 'stat_' . $i, '' );
	if ( $raw && false !== strpos( $raw, '|' ) ) {
		$ryugaku_stats[] = array_map( 'trim', explode( '|', $raw, 2 ) );
	}
}
?>

<section class="hero">
	<div class="container hero__inner">
		<div class="hero__content">
			<p class="hero__eyebrow">留学エージェント｜相談・手続き 0円</p>
			<h1 class="hero__title"><?php echo nl2br( esc_html( $ryugaku_hero_title ) ); ?></h1>
			<?php if ( $ryugaku_hero_lead ) : ?>
				<p class="hero__lead"><?php echo esc_html( $ryugaku_hero_lead ); ?></p>
			<?php endif; ?>
			<?php ryugaku_cta_buttons( 'lg', false ); ?>
			<ul class="hero__points">
				<li><?php echo ryugaku_icon( 'check' ); ?>無理な営業なし</li>
				<li><?php echo ryugaku_icon( 'check' ); ?>留学経験者が担当</li>
				<li><?php echo ryugaku_icon( 'check' ); ?>出発後も現地サポート</li>
			</ul>
		</div>
		<div class="hero__visual">
			<?php if ( $ryugaku_hero_image ) : ?>
				<img src="<?php echo esc_url( $ryugaku_hero_image ); ?>" alt="" width="640" height="560" fetchpriority="high" decoding="async">
			<?php else : ?>
				<div class="hero__art" aria-hidden="true">
					<span class="hero__art-card hero__art-card--1">🇵🇭 セブ島<br><small>1ヶ月 25万円〜</small></span>
					<span class="hero__art-card hero__art-card--2">🇦🇺 シドニー<br><small>ワーホリ人気No.1</small></span>
					<span class="hero__art-card hero__art-card--3">🇨🇦 バンクーバー<br><small>Co-op留学</small></span>
					<span class="hero__art-globe">🌏</span>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php if ( $ryugaku_stats ) : ?>
		<div class="container">
			<ul class="stats">
				<?php foreach ( $ryugaku_stats as $ryugaku_stat ) : ?>
					<li><span class="stats__label"><?php echo esc_html( $ryugaku_stat[0] ); ?></span><strong class="stats__value"><?php echo esc_html( $ryugaku_stat[1] ); ?></strong></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
</section>

<section class="section section--line">
	<div class="container line-cta">
		<div class="line-cta__text">
			<p class="eyebrow">LINE CONSULTATION</p>
			<h2>LINEで気軽に無料相談</h2>
			<p>「予算内でどこに行ける？」「英語が話せないけど大丈夫？」など、どんな小さな疑問でもOK。友だち追加後、メッセージを送るだけでカウンセラーが回答します。</p>
		</div>
		<div class="line-cta__action">
			<a class="btn btn--line btn--lg" href="<?php echo ryugaku_line_url(); ?>" target="_blank" rel="noopener"><span class="btn__icon"><?php echo ryugaku_icon( 'line' ); ?></span>LINEで無料相談する</a>
			<p class="line-cta__note">通常1営業日以内に返信</p>
		</div>
	</div>
</section>

<section class="section">
	<div class="container">
		<?php ryugaku_section_title( '無料カウンセリング', 'COUNSELING', 'オンライン（Zoom）または来社で、約60分。目的・予算・期間から、あなた専用の留学プランを一緒に作ります。' ); ?>
		<div class="counseling-grid">
			<div class="counseling-card">
				<span class="counseling-card__num">01</span>
				<h3>目的と予算をヒアリング</h3>
				<p>英語力アップ・ワーホリ・キャリアなど、目的に合わせて最適な国とプランを整理します。</p>
			</div>
			<div class="counseling-card">
				<span class="counseling-card__num">02</span>
				<h3>複数の国・学校を比較提案</h3>
				<p>費用シミュレーション付きで、2〜3パターンのプランをご提案。比較して選べます。</p>
			</div>
			<div class="counseling-card">
				<span class="counseling-card__num">03</span>
				<h3>その場で決めなくてOK</h3>
				<p>持ち帰ってじっくり検討していただけます。しつこい営業は一切行いません。</p>
			</div>
		</div>
		<div class="cta-buttons cta-buttons--center">
			<a class="btn btn--primary btn--lg" href="<?php echo ryugaku_counseling_url(); ?>"><span class="btn__icon"><?php echo ryugaku_icon( 'calendar' ); ?></span>無料カウンセリングを予約する</a>
		</div>
	</div>
</section>

<section class="section section--tint" id="diagnosis">
	<div class="container">
		<?php ryugaku_section_title( 'おすすめの国・都市診断', 'DIAGNOSIS', '4つの質問に答えるだけ。あなたにぴったりの留学先を診断します。' ); ?>
		<div class="diagnosis" data-diagnosis>
			<div class="diagnosis__progress"><span data-diagnosis-bar></span></div>
			<div class="diagnosis__steps">
				<fieldset class="diagnosis__step is-active" data-step="purpose">
					<legend><span class="diagnosis__q">Q1</span>留学の目的は？</legend>
					<div class="diagnosis__options">
						<button type="button" data-value="language">英語力を伸ばしたい</button>
						<button type="button" data-value="working-holiday">働きながら海外生活</button>
						<button type="button" data-value="internship">海外で就業経験を積む</button>
						<button type="button" data-value="career">キャリアアップ・進学</button>
					</div>
				</fieldset>
				<fieldset class="diagnosis__step" data-step="budget">
					<legend><span class="diagnosis__q">Q2</span>1ヶ月あたりの予算は？</legend>
					<div class="diagnosis__options">
						<button type="button" data-value="20">〜20万円</button>
						<button type="button" data-value="35">〜35万円</button>
						<button type="button" data-value="50">〜50万円</button>
						<button type="button" data-value="999">こだわらない</button>
					</div>
				</fieldset>
				<fieldset class="diagnosis__step" data-step="climate">
					<legend><span class="diagnosis__q">Q3</span>好みの気候は？</legend>
					<div class="diagnosis__options">
						<button type="button" data-value="warm">一年中あたたかい</button>
						<button type="button" data-value="mild">四季があって過ごしやすい</button>
						<button type="button" data-value="cold">涼しい・雪も楽しみたい</button>
						<button type="button" data-value="any">気にしない</button>
					</div>
				</fieldset>
				<fieldset class="diagnosis__step" data-step="distance">
					<legend><span class="diagnosis__q">Q4</span>日本からの距離は？</legend>
					<div class="diagnosis__options">
						<button type="button" data-value="near">近いほうがいい（〜6時間）</button>
						<button type="button" data-value="mid">ほどほど（〜12時間）</button>
						<button type="button" data-value="far">遠くても気にしない</button>
						<button type="button" data-value="any">こだわらない</button>
					</div>
				</fieldset>
			</div>
			<div class="diagnosis__result" data-diagnosis-result hidden>
				<p class="eyebrow">RESULT</p>
				<h3>あなたにおすすめの留学先</h3>
				<div class="diagnosis__cards" data-diagnosis-cards></div>
				<div class="diagnosis__actions">
					<button type="button" class="btn btn--ghost" data-diagnosis-reset>もう一度診断する</button>
					<a class="btn btn--line" href="<?php echo ryugaku_line_url(); ?>" target="_blank" rel="noopener"><span class="btn__icon"><?php echo ryugaku_icon( 'line' ); ?></span>診断結果をもとにLINEで相談</a>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
$ryugaku_popular = new WP_Query(
	array(
		'post_type'      => 'country',
		'posts_per_page' => 6,
		'meta_key'       => '_ryugaku_popularity',
		'orderby'        => 'meta_value_num',
		'order'          => 'DESC',
	)
);
if ( $ryugaku_popular->have_posts() ) :
	?>
	<section class="section">
		<div class="container">
			<?php ryugaku_section_title( '人気の留学先', 'POPULAR COUNTRIES', '費用・英語環境・生活しやすさのバランスで選ばれている国をランキングで紹介。' ); ?>
			<div class="grid grid--3">
				<?php
				$ryugaku_rank = 0;
				while ( $ryugaku_popular->have_posts() ) :
					$ryugaku_popular->the_post();
					$ryugaku_rank++;
					get_template_part( 'template-parts/card', 'country', array( 'rank' => $ryugaku_rank ) );
				endwhile;
				wp_reset_postdata();
				?>
			</div>
			<p class="section__more"><a class="btn btn--ghost" href="<?php echo esc_url( get_post_type_archive_link( 'country' ) ); ?>">すべての国を見る<?php echo ryugaku_icon( 'arrow' ); ?></a></p>
		</div>
	</section>
<?php endif; ?>

<?php
$ryugaku_types = new WP_Query( array( 'post_type' => 'purpose', 'posts_per_page' => 4, 'orderby' => 'menu_order title', 'order' => 'ASC' ) );
if ( $ryugaku_types->have_posts() ) :
	?>
	<section class="section section--tint">
		<div class="container">
			<?php ryugaku_section_title( '留学タイプから選ぶ', 'STUDY TYPES', '目的に合わせて、最適な留学のかたちを。' ); ?>
			<div class="grid grid--4">
				<?php
				while ( $ryugaku_types->have_posts() ) :
					$ryugaku_types->the_post();
					?>
					<a class="type-card" href="<?php the_permalink(); ?>">
						<span class="type-card__icon" aria-hidden="true"><?php echo esc_html( ryugaku_meta( 'icon', '✈️' ) ); ?></span>
						<h3 class="type-card__title"><?php the_title(); ?></h3>
						<p class="type-card__catch"><?php echo esc_html( ryugaku_meta( 'catch', ryugaku_excerpt( 40 ) ) ); ?></p>
						<span class="type-card__more">詳しく見る<?php echo ryugaku_icon( 'arrow' ); ?></span>
					</a>
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			</div>
		</div>
	</section>
<?php endif; ?>

<section class="section">
	<div class="container">
		<?php ryugaku_section_title( '選ばれる理由', 'WHY US', '「安心して任せられる」と言っていただける理由があります。' ); ?>
		<div class="reasons">
			<div class="reason">
				<span class="reason__num">01</span>
				<h3>手数料0円・追加費用なし</h3>
				<p>学校からの紹介料で運営しているため、カウンセリング・手続き代行・出発後サポートまで無料。学校へ直接申し込むより安くなるケースも。</p>
			</div>
			<div class="reason">
				<span class="reason__num">02</span>
				<h3>カウンセラー全員が留学経験者</h3>
				<p>自分自身の留学で感じた「困った」を知っているからこそ、リアルなアドバイスができます。</p>
			</div>
			<div class="reason">
				<span class="reason__num">03</span>
				<h3>提携450校から中立に提案</h3>
				<p>特定の学校を推すことはありません。複数校を費用・環境で比較し、あなたに合う学校だけをご提案します。</p>
			</div>
			<div class="reason">
				<span class="reason__num">04</span>
				<h3>出発後もLINEで24時間サポート</h3>
				<p>トラブルや相談は出発後こそ増えるもの。現地オフィスと日本のスタッフが連携して対応します。</p>
			</div>
		</div>
		<p class="section__more"><a class="btn btn--ghost" href="<?php echo esc_url( ryugaku_page_url( 'reasons' ) ); ?>">選ばれる理由をもっと見る<?php echo ryugaku_icon( 'arrow' ); ?></a></p>
	</div>
</section>

<?php
$ryugaku_cost_countries = get_posts(
	array(
		'post_type'      => 'country',
		'posts_per_page' => 5,
		'meta_key'       => '_ryugaku_popularity',
		'orderby'        => 'meta_value_num',
		'order'          => 'DESC',
	)
);
if ( $ryugaku_cost_countries ) :
	?>
	<section class="section section--tint">
		<div class="container">
			<?php ryugaku_section_title( '料金イメージ', 'PRICE', '授業料＋滞在費の目安。航空券・保険・ビザは別途。プランや時期により変動します。' ); ?>
			<div class="table-wrap">
				<table class="price-table">
					<thead>
						<tr><th>国</th><th>1ヶ月</th><th>3ヶ月</th><th>6ヶ月</th><th>1年</th></tr>
					</thead>
					<tbody>
						<?php foreach ( $ryugaku_cost_countries as $ryugaku_c ) : ?>
							<tr>
								<th scope="row"><a href="<?php echo esc_url( get_permalink( $ryugaku_c ) ); ?>"><?php echo esc_html( ryugaku_flag( $ryugaku_c->ID ) . ' ' . $ryugaku_c->post_title ); ?></a></th>
								<td><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_month', '', $ryugaku_c->ID ) ) ); ?>〜</td>
								<td><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_3month', '', $ryugaku_c->ID ) ) ); ?>〜</td>
								<td><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_6month', '', $ryugaku_c->ID ) ) ); ?>〜</td>
								<td><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_year', '', $ryugaku_c->ID ) ) ); ?>〜</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<p class="section__more"><a class="btn btn--ghost" href="<?php echo esc_url( ryugaku_page_url( 'plan' ) ); ?>">料金プランを詳しく見る<?php echo ryugaku_icon( 'arrow' ); ?></a></p>
		</div>
	</section>
<?php endif; ?>

<?php
$ryugaku_voices = new WP_Query(
	array(
		'post_type'      => 'voice',
		'posts_per_page' => 3,
		'meta_key'       => '_ryugaku_voice_featured',
		'meta_value'     => '1',
	)
);
if ( ! $ryugaku_voices->have_posts() ) {
	$ryugaku_voices = new WP_Query( array( 'post_type' => 'voice', 'posts_per_page' => 3 ) );
}
if ( $ryugaku_voices->have_posts() ) :
	?>
	<section class="section">
		<div class="container">
			<?php ryugaku_section_title( '体験談', 'VOICES', '留学した先輩たちのリアルな声。' ); ?>
			<div class="grid grid--3">
				<?php
				while ( $ryugaku_voices->have_posts() ) :
					$ryugaku_voices->the_post();
					get_template_part( 'template-parts/card', 'voice' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>
			<p class="section__more"><a class="btn btn--ghost" href="<?php echo esc_url( get_post_type_archive_link( 'voice' ) ); ?>">体験談をもっと見る<?php echo ryugaku_icon( 'arrow' ); ?></a></p>
		</div>
	</section>
<?php endif; ?>

<?php
$ryugaku_columns = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 3 ) );
if ( $ryugaku_columns->have_posts() ) :
	?>
	<section class="section section--tint">
		<div class="container">
			<?php ryugaku_section_title( '留学コラム', 'COLUMN', '費用・国比較・英語学習など、準備に役立つ情報を発信中。' ); ?>
			<div class="grid grid--3">
				<?php
				while ( $ryugaku_columns->have_posts() ) :
					$ryugaku_columns->the_post();
					get_template_part( 'template-parts/card', 'post' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>
			<p class="section__more"><a class="btn btn--ghost" href="<?php echo esc_url( ryugaku_column_url() ); ?>">コラム一覧へ<?php echo ryugaku_icon( 'arrow' ); ?></a></p>
		</div>
	</section>
<?php endif; ?>

<?php get_footer(); ?>
