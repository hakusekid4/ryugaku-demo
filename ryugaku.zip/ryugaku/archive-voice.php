<?php
/**
 * 体験談一覧と実績数値。
 *
 * @package Ryugaku
 */

get_header();
?>
<?php ryugaku_page_hero( '体験談・実績', '留学前の不安から、留学後の変化、その先のキャリアまで。先輩たちのリアルな声をお届けします。', 'VOICES' ); ?>

<section class="section">
	<div class="container">
		<?php if ( have_posts() ) : ?>
			<div class="grid grid--3">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/card', 'voice' );
				endwhile;
				?>
			</div>
			<?php get_template_part( 'template-parts/pagination' ); ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/no-results' ); ?>
		<?php endif; ?>
	</div>
</section>

<section class="section section--tint">
	<div class="container">
		<?php ryugaku_section_title( '実績', 'RESULTS' ); ?>
		<ul class="stats stats--static">
			<?php
			for ( $ryugaku_i = 1; $ryugaku_i <= 4; $ryugaku_i++ ) :
				$ryugaku_raw = ryugaku_option( 'stat_' . $ryugaku_i, '' );
				if ( ! $ryugaku_raw || false === strpos( $ryugaku_raw, '|' ) ) {
					continue;
				}
				$ryugaku_stat = array_map( 'trim', explode( '|', $ryugaku_raw, 2 ) );
				?>
				<li><span class="stats__label"><?php echo esc_html( $ryugaku_stat[0] ); ?></span><strong class="stats__value"><?php echo esc_html( $ryugaku_stat[1] ); ?></strong></li>
			<?php endfor; ?>
		</ul>
	</div>
</section>
<?php get_footer(); ?>
