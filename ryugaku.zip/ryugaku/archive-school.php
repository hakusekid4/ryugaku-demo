<?php
/**
 * 学校一覧。国・都市・留学タイプ・キーワードで絞り込み、費用順などで並び替え。
 *
 * @package Ryugaku
 */

get_header();
$ryugaku_keyword   = ryugaku_current_keyword();
$ryugaku_country   = (int) ryugaku_current_filter( 'country' );
$ryugaku_city      = ryugaku_current_filter( 'city' );
$ryugaku_type      = ryugaku_current_filter( 'type' );
$ryugaku_countries = get_posts( array( 'post_type' => 'country', 'posts_per_page' => -1, 'orderby' => 'menu_order title', 'order' => 'ASC' ) );
$ryugaku_types     = get_terms( array( 'taxonomy' => 'study_type', 'hide_empty' => true ) );
$ryugaku_title     = '学校一覧';
if ( $ryugaku_country ) {
	$ryugaku_title = get_the_title( $ryugaku_country ) . 'の学校一覧';
}
?>
<?php ryugaku_page_hero( $ryugaku_title, '国・都市・費用で絞り込んで、提携校を比較できます。掲載外の学校も手配可能です。', 'SCHOOLS' ); ?>

<section class="section section--flush">
	<div class="container">
		<form class="filter-form filter-form--wide" method="get" action="<?php echo esc_url( get_post_type_archive_link( 'school' ) ); ?>" role="search">
			<label class="filter-form__search">
				<span class="screen-reader-text">学校名で検索</span>
				<?php echo ryugaku_icon( 'search' ); ?>
				<input type="search" name="q" value="<?php echo esc_attr( $ryugaku_keyword ); ?>" placeholder="学校名・キーワード">
			</label>
			<label class="filter-form__select">
				<span class="screen-reader-text">国</span>
				<select name="country">
					<option value="">国：すべて</option>
					<?php foreach ( $ryugaku_countries as $ryugaku_c ) : ?>
						<option value="<?php echo esc_attr( $ryugaku_c->ID ); ?>" <?php selected( $ryugaku_country, $ryugaku_c->ID ); ?>><?php echo esc_html( ryugaku_flag( $ryugaku_c->ID ) . ' ' . $ryugaku_c->post_title ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label class="filter-form__select">
				<span class="screen-reader-text">都市</span>
				<input type="text" name="city" value="<?php echo esc_attr( $ryugaku_city ); ?>" placeholder="都市名（例：セブ）">
			</label>
			<?php if ( $ryugaku_types && ! is_wp_error( $ryugaku_types ) ) : ?>
				<label class="filter-form__select">
					<span class="screen-reader-text">留学タイプ</span>
					<select name="type">
						<option value="">留学タイプ：すべて</option>
						<?php foreach ( $ryugaku_types as $ryugaku_t ) : ?>
							<option value="<?php echo esc_attr( $ryugaku_t->slug ); ?>" <?php selected( $ryugaku_type, $ryugaku_t->slug ); ?>><?php echo esc_html( $ryugaku_t->name ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
			<?php endif; ?>
			<input type="hidden" name="sort" value="<?php echo esc_attr( ryugaku_current_sort() ); ?>">
			<button class="btn btn--primary" type="submit">絞り込む</button>
		</form>

		<?php get_template_part( 'template-parts/sort-bar', null, array( 'options' => array( 'popular' => 'おすすめ順', 'cost' => '費用が安い順', 'cost_desc' => '費用が高い順', 'name' => '名前順' ) ) ); ?>

		<?php if ( have_posts() ) : ?>
			<div class="grid grid--3">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/card', 'school' );
				endwhile;
				?>
			</div>
			<?php get_template_part( 'template-parts/pagination' ); ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/no-results' ); ?>
		<?php endif; ?>
	</div>
</section>

<section class="section section--tint">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '学校選びのポイント', 'HOW TO CHOOSE' ); ?>
		<div class="grid grid--2">
			<div class="info-card"><h3>日本人比率</h3><p>英語漬けにしたいなら日本人比率が低い学校を。初めての海外で不安なら日本人スタッフ常駐校が安心です。</p></div>
			<div class="info-card"><h3>授業形式</h3><p>マンツーマン中心（フィリピン）かグループ中心（欧米）かで、伸ばせる力も費用も変わります。</p></div>
			<div class="info-card"><h3>規模と国籍バランス</h3><p>大規模校はコースが豊富、小規模校はアットホーム。国籍が偏っていないかもチェック。</p></div>
			<div class="info-card"><h3>立地と滞在方法</h3><p>都市部か郊外か、寮かホームステイか。生活スタイルの好みで満足度が大きく変わります。</p></div>
		</div>
	</div>
</section>
<?php get_footer(); ?>
