<?php
/**
 * 固定ページ「料金プラン」。プラン・国別・期間別・オプション・分割払い・FAQ。
 *
 * Template Name: 料金プラン
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_countries = get_posts( array( 'post_type' => 'country', 'posts_per_page' => 8, 'meta_key' => '_ryugaku_popularity', 'orderby' => 'meta_value_num', 'order' => 'DESC' ) );
?>
<?php ryugaku_page_hero( '料金プラン', '当社へのお支払いは0円。学校・滞在先の実費のみで留学できます。国別・期間別の目安をご覧ください。', 'PRICE' ); ?>

<section class="section">
	<div class="container">
		<?php ryugaku_section_title( 'プラン一覧', 'PLANS', 'すべてのプランでエージェント手数料は無料です。' ); ?>
		<div class="grid grid--3 plan-grid">
			<div class="plan-card">
				<p class="plan-card__name">短期集中プラン</p>
				<p class="plan-card__period">1〜4週間</p>
				<p class="plan-card__price"><small>目安</small>15万円〜</p>
				<ul class="check-list">
					<li><span class="check-list__icon"><?php echo ryugaku_icon( 'check' ); ?></span><span>社会人の休暇・学生の春夏休みに</span></li>
					<li><span class="check-list__icon"><?php echo ryugaku_icon( 'check' ); ?></span><span>ビザ不要の国が中心</span></li>
					<li><span class="check-list__icon"><?php echo ryugaku_icon( 'check' ); ?></span><span>マンツーマン集中コース可</span></li>
				</ul>
			</div>
			<div class="plan-card is-featured">
				<p class="plan-card__tag">人気No.1</p>
				<p class="plan-card__name">スタンダードプラン</p>
				<p class="plan-card__period">2〜6ヶ月</p>
				<p class="plan-card__price"><small>目安</small>50万円〜</p>
				<ul class="check-list">
					<li><span class="check-list__icon"><?php echo ryugaku_icon( 'check' ); ?></span><span>英語力を確実に伸ばしたい方に</span></li>
					<li><span class="check-list__icon"><?php echo ryugaku_icon( 'check' ); ?></span><span>2ヶ国留学の組み合わせも可</span></li>
					<li><span class="check-list__icon"><?php echo ryugaku_icon( 'check' ); ?></span><span>出発前英会話レッスン無料</span></li>
				</ul>
			</div>
			<div class="plan-card">
				<p class="plan-card__name">長期・ワーホリプラン</p>
				<p class="plan-card__period">6ヶ月〜1年以上</p>
				<p class="plan-card__price"><small>目安</small>100万円〜</p>
				<ul class="check-list">
					<li><span class="check-list__icon"><?php echo ryugaku_icon( 'check' ); ?></span><span>ワーホリ・Co-op・進学に</span></li>
					<li><span class="check-list__icon"><?php echo ryugaku_icon( 'check' ); ?></span><span>現地で収入を得ながら滞在</span></li>
					<li><span class="check-list__icon"><?php echo ryugaku_icon( 'check' ); ?></span><span>長期割引・ビザサポート付き</span></li>
				</ul>
			</div>
		</div>
	</div>
</section>

<?php if ( $ryugaku_countries ) : ?>
	<section class="section section--tint">
		<div class="container">
			<?php ryugaku_section_title( '国別料金例', 'BY COUNTRY', '授業料＋滞在費の目安。航空券・海外保険・ビザ申請費・お小遣いは別途。' ); ?>
			<div class="table-wrap">
				<table class="price-table">
					<thead><tr><th>国</th><th>1ヶ月</th><th>3ヶ月</th><th>6ヶ月</th><th>1年</th><th></th></tr></thead>
					<tbody>
						<?php foreach ( $ryugaku_countries as $ryugaku_c ) : ?>
							<tr>
								<th scope="row"><?php echo esc_html( ryugaku_flag( $ryugaku_c->ID ) . ' ' . $ryugaku_c->post_title ); ?></th>
								<td><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_month', '', $ryugaku_c->ID ) ) ); ?>〜</td>
								<td><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_3month', '', $ryugaku_c->ID ) ) ); ?>〜</td>
								<td><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_6month', '', $ryugaku_c->ID ) ) ); ?>〜</td>
								<td><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_year', '', $ryugaku_c->ID ) ) ); ?>〜</td>
								<td><a class="text-link" href="<?php echo esc_url( get_permalink( $ryugaku_c ) ); ?>">詳細<?php echo ryugaku_icon( 'arrow' ); ?></a></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</section>
<?php endif; ?>

<section class="section">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '期間別の費用内訳', 'BY PERIOD', 'フィリピン・セブ島（マンツーマン6コマ／寮2人部屋）の例。' ); ?>
		<div class="table-wrap">
			<table class="price-table">
				<thead><tr><th>項目</th><th>4週間</th><th>12週間</th><th>24週間</th></tr></thead>
				<tbody>
					<tr><th scope="row">授業料＋寮費（食事付）</th><td>18万円</td><td>50万円</td><td>95万円</td></tr>
					<tr><th scope="row">入学金・SSP・ビザ延長等の現地費用</th><td>4万円</td><td>7万円</td><td>11万円</td></tr>
					<tr><th scope="row">航空券（往復）</th><td>6万円</td><td>6万円</td><td>6万円</td></tr>
					<tr><th scope="row">海外旅行保険</th><td>1.5万円</td><td>4万円</td><td>8万円</td></tr>
					<tr><th scope="row">お小遣い（目安）</th><td>3万円</td><td>9万円</td><td>18万円</td></tr>
					<tr class="is-total"><th scope="row">合計目安</th><td>約32.5万円</td><td>約76万円</td><td>約138万円</td></tr>
				</tbody>
			</table>
		</div>
	</div>
</section>

<section class="section section--tint">
	<div class="container">
		<?php ryugaku_section_title( 'オプション', 'OPTIONS', '必要なものだけ選べます。すべて任意です。' ); ?>
		<div class="grid grid--3">
			<div class="info-card"><h3>空港送迎</h3><p>到着日の深夜便でも安心。学校スタッフまたは提携ドライバーが空港でお迎えします。<strong>5,000円〜／片道</strong></p></div>
			<div class="info-card"><h3>海外旅行保険</h3><p>治療・救援費用無制限の留学生向けプラン。クレジットカード付帯保険との比較もご案内。<strong>月額 1.2万円〜</strong></p></div>
			<div class="info-card"><h3>滞在先アップグレード</h3><p>寮の1人部屋、ホームステイ、シェアハウス、学生アパートなど。<strong>月額 +3万円〜</strong></p></div>
			<div class="info-card"><h3>出発前オンライン英会話</h3><p>お申し込みから出発まで、週2回のレッスンを無料提供。追加レッスンも可能。<strong>無料</strong></p></div>
			<div class="info-card"><h3>SIM・Wi-Fi手配</h3><p>現地SIMを事前手配し、到着直後から使える状態でお渡し。<strong>3,000円〜</strong></p></div>
			<div class="info-card"><h3>帰国後キャリア相談</h3><p>留学経験を活かした就職・転職相談。提携する人材サービスをご紹介。<strong>無料</strong></p></div>
		</div>
	</div>
</section>

<section class="section">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '分割払い・お支払い方法', 'PAYMENT' ); ?>
		<div class="grid grid--2">
			<div class="info-card"><h3>銀行振込（一括）</h3><p>お申し込み確定後、請求書をお送りします。出発の4週間前までにお振込みください。</p></div>
			<div class="info-card"><h3>クレジットカード</h3><p>VISA／Master／JCB／AMEXに対応。カード会社の分割・リボ払いをご利用いただけます。</p></div>
			<div class="info-card"><h3>教育ローン（分割）</h3><p>提携信販会社の教育ローンで最大60回払いが可能。学生の方は保護者名義でのお申し込みとなります。審査は最短即日。</p></div>
			<div class="info-card"><h3>2回払い</h3><p>お申し込み時に入学金相当額、残額を出発4週間前までにお支払いいただく方法も選べます。手数料はかかりません。</p></div>
		</div>
	</div>
</section>

<section class="section section--tint">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '料金に関するよくある質問', 'FAQ' ); ?>
		<?php
		ryugaku_faq_list(
			array(
				array( '本当にエージェント手数料は無料ですか？', 'はい。当社は提携校から紹介料をいただいて運営しているため、お客様にカウンセリング料や手続き代行料をご請求することはありません。学校提示の正規料金でお申し込みいただけます。' ),
				array( '表示されている費用以外にかかるものは？', '航空券・海外旅行保険・ビザ申請費・現地でのお小遣いは別途必要です。お見積もりでは総額でご案内しますのでご安心ください。' ),
				array( '為替の変動はどう扱われますか？', '現地通貨建ての費用は、お支払い時点の当社レートで円換算します。市場レートに数円の手数料を加えた透明なレートを採用しています。' ),
				array( 'キャンセル料はかかりますか？', '学校ごとに規定が異なります。お申し込み前にキャンセルポリシーを必ずご説明し、書面でお渡しします。' ),
				array( '学生でも分割払いはできますか？', '提携の教育ローンを保護者名義でお申し込みいただけます。詳細はカウンセリングでご案内します。' ),
			)
		);
		?>
	</div>
</section>

<?php if ( get_the_content() ) : ?>
	<section class="section"><div class="container container--narrow prose"><?php the_content(); ?></div></section>
<?php endif; ?>
<?php get_footer(); ?>
