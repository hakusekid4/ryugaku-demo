<?php
/**
 * 固定ページ「お問い合わせ」。LINE・フォーム・電話の 3 導線とフォーム本体。
 *
 * Template Name: お問い合わせ
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_status = isset( $_GET['contact'] ) ? sanitize_key( wp_unslash( $_GET['contact'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$ryugaku_state  = ryugaku_contact_state();
$ryugaku_errors = $ryugaku_state['errors'];
$ryugaku_values = $ryugaku_state['values'];
$ryugaku_val    = function ( $key ) use ( $ryugaku_values ) {
	return isset( $ryugaku_values[ $key ] ) ? $ryugaku_values[ $key ] : '';
};
$ryugaku_countries = get_posts( array( 'post_type' => 'country', 'posts_per_page' => -1, 'orderby' => 'menu_order title', 'order' => 'ASC' ) );
?>
<?php ryugaku_page_hero( 'お問い合わせ・無料カウンセリング', '相談は無料。無理な営業は一切ありません。LINEかフォーム、お好きな方法でどうぞ。', 'CONTACT' ); ?>

<section class="section">
	<div class="container">
		<div class="contact-options">
			<a class="contact-option contact-option--line" href="<?php echo ryugaku_line_url(); ?>" target="_blank" rel="noopener">
				<span class="contact-option__icon"><?php echo ryugaku_icon( 'line' ); ?></span>
				<span class="contact-option__title">LINEで相談する</span>
				<span class="contact-option__desc">いちばん気軽。友だち追加してメッセージを送るだけ。返信は1営業日以内。</span>
			</a>
			<a class="contact-option contact-option--form" href="#counseling">
				<span class="contact-option__icon"><?php echo ryugaku_icon( 'calendar' ); ?></span>
				<span class="contact-option__title">無料カウンセリングを予約</span>
				<span class="contact-option__desc">オンライン（Zoom）または来社で約60分。下のフォームからご希望日時をお送りください。</span>
			</a>
			<?php if ( ryugaku_option( 'phone', '' ) ) : ?>
				<a class="contact-option contact-option--tel" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', ryugaku_option( 'phone' ) ) ); ?>">
					<span class="contact-option__icon">📞</span>
					<span class="contact-option__title"><?php echo esc_html( ryugaku_option( 'phone' ) ); ?></span>
					<span class="contact-option__desc"><?php echo esc_html( ryugaku_option( 'business_hours', '' ) ); ?></span>
				</a>
			<?php endif; ?>
		</div>

		<ul class="promise-list">
			<li><?php echo ryugaku_icon( 'check' ); ?>相談・手続き代行は0円</li>
			<li><?php echo ryugaku_icon( 'check' ); ?>無理な営業・電話勧誘なし</li>
			<li><?php echo ryugaku_icon( 'check' ); ?>その場で決めなくてOK</li>
			<li><?php echo ryugaku_icon( 'check' ); ?>個人情報は厳重に管理</li>
		</ul>
	</div>
</section>

<section class="section section--tint" id="counseling">
	<div class="container container--narrow">
		<?php ryugaku_section_title( 'お問い合わせフォーム', 'FORM', '必須項目はお名前とメールアドレスだけ。わかる範囲でご記入ください。' ); ?>

		<?php if ( 'sent' === $ryugaku_status ) : ?>
			<div class="notice notice--success" role="status">
				<strong>送信が完了しました。</strong>ご入力いただいたメールアドレスに確認メールをお送りしました。担当カウンセラーより1営業日以内にご連絡いたします。
			</div>
		<?php elseif ( 'invalid' === $ryugaku_status ) : ?>
			<div class="notice notice--error" role="alert">入力内容をご確認ください。必須項目が未入力、または形式に誤りがあります。</div>
		<?php elseif ( 'error' === $ryugaku_status ) : ?>
			<div class="notice notice--error" role="alert">送信に失敗しました。お手数ですが再度お試しいただくか、LINEからご連絡ください。</div>
		<?php endif; ?>

		<?php if ( 'sent' !== $ryugaku_status ) : ?>
			<form class="contact-form" method="post" action="<?php echo esc_url( get_permalink() ); ?>#counseling" novalidate>
				<?php wp_nonce_field( 'ryugaku_contact', 'ryugaku_contact_nonce' ); ?>
				<input type="hidden" name="ryugaku_contact" value="1">
				<input type="hidden" name="ryugaku_ts" value="<?php echo esc_attr( time() ); ?>">
				<p class="hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>

				<div class="form-row">
					<label class="form-field <?php echo in_array( 'name', $ryugaku_errors, true ) ? 'has-error' : ''; ?>">
						<span class="form-field__label">お名前 <em>必須</em></span>
						<input type="text" name="name" value="<?php echo esc_attr( $ryugaku_val( 'name' ) ); ?>" required autocomplete="name" placeholder="留学 太郎">
					</label>
					<label class="form-field <?php echo in_array( 'email', $ryugaku_errors, true ) ? 'has-error' : ''; ?>">
						<span class="form-field__label">メールアドレス <em>必須</em></span>
						<input type="email" name="email" value="<?php echo esc_attr( $ryugaku_val( 'email' ) ); ?>" required autocomplete="email" placeholder="example@email.com">
					</label>
				</div>
				<div class="form-row">
					<label class="form-field">
						<span class="form-field__label">電話番号</span>
						<input type="tel" name="tel" value="<?php echo esc_attr( $ryugaku_val( 'tel' ) ); ?>" autocomplete="tel" placeholder="090-1234-5678">
					</label>
					<label class="form-field">
						<span class="form-field__label">ご相談内容</span>
						<select name="type">
							<?php foreach ( array( '無料カウンセリング希望', '費用について相談したい', '国・学校について相談したい', 'ビザについて相談したい', '資料が欲しい', 'その他' ) as $ryugaku_opt ) : ?>
								<option value="<?php echo esc_attr( $ryugaku_opt ); ?>" <?php selected( $ryugaku_val( 'type' ), $ryugaku_opt ); ?>><?php echo esc_html( $ryugaku_opt ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
				</div>
				<div class="form-row">
					<label class="form-field">
						<span class="form-field__label">希望の国</span>
						<select name="country">
							<option value="">未定・相談したい</option>
							<?php foreach ( $ryugaku_countries as $ryugaku_c ) : ?>
								<option value="<?php echo esc_attr( $ryugaku_c->post_title ); ?>" <?php selected( $ryugaku_val( 'country' ), $ryugaku_c->post_title ); ?>><?php echo esc_html( ryugaku_flag( $ryugaku_c->ID ) . ' ' . $ryugaku_c->post_title ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label class="form-field">
						<span class="form-field__label">希望期間</span>
						<select name="period">
							<?php foreach ( array( '未定', '1〜4週間', '1〜3ヶ月', '3〜6ヶ月', '6ヶ月〜1年', '1年以上' ) as $ryugaku_opt ) : ?>
								<option value="<?php echo esc_attr( $ryugaku_opt ); ?>" <?php selected( $ryugaku_val( 'period' ), $ryugaku_opt ); ?>><?php echo esc_html( $ryugaku_opt ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
				</div>
				<div class="form-row">
					<label class="form-field">
						<span class="form-field__label">出発時期</span>
						<select name="timing">
							<?php foreach ( array( '未定', '3ヶ月以内', '半年以内', '1年以内', '1年以上先' ) as $ryugaku_opt ) : ?>
								<option value="<?php echo esc_attr( $ryugaku_opt ); ?>" <?php selected( $ryugaku_val( 'timing' ), $ryugaku_opt ); ?>><?php echo esc_html( $ryugaku_opt ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label class="form-field">
						<span class="form-field__label">希望の連絡方法</span>
						<select name="method">
							<?php foreach ( array( 'メール', 'LINE', '電話', 'オンライン面談（Zoom）', '来社' ) as $ryugaku_opt ) : ?>
								<option value="<?php echo esc_attr( $ryugaku_opt ); ?>" <?php selected( $ryugaku_val( 'method' ), $ryugaku_opt ); ?>><?php echo esc_html( $ryugaku_opt ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
				</div>
				<label class="form-field">
					<span class="form-field__label">ご質問・ご要望・希望日時など</span>
					<textarea name="message" rows="5" placeholder="例：来月の平日夜にオンラインで相談したいです。予算は総額80万円くらいで、3ヶ月ほどの語学留学を考えています。"><?php echo esc_textarea( $ryugaku_val( 'message' ) ); ?></textarea>
				</label>
				<label class="form-check <?php echo in_array( 'agree', $ryugaku_errors, true ) ? 'has-error' : ''; ?>">
					<input type="checkbox" name="agree" value="1" required>
					<span><a href="<?php echo esc_url( ryugaku_page_url( 'privacy-policy' ) ); ?>" target="_blank" rel="noopener">プライバシーポリシー</a>に同意する <em>必須</em></span>
				</label>
				<div class="form-submit">
					<button class="btn btn--primary btn--lg" type="submit">送信する</button>
					<p class="note">送信後、自動返信メールをお送りします。届かない場合は迷惑メールフォルダをご確認ください。</p>
				</div>
			</form>
		<?php endif; ?>
	</div>
</section>

<?php if ( get_the_content() ) : ?>
	<section class="section"><div class="container container--narrow prose"><?php the_content(); ?></div></section>
<?php endif; ?>
<?php get_footer(); ?>
