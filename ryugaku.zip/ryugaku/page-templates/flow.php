<?php
/**
 * 固定ページ「留学の流れ」。LINE 相談 → カウンセリング → 学校決定 → 手続き → 出発 → 現地生活。
 *
 * Template Name: 留学の流れ
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_steps = array(
	array( 'LINE相談', '気になることをLINEで送るだけ', 'まずは友だち追加して、「予算」「行きたい国」「時期」など気になることを送ってください。カウンセラーが1営業日以内に返信します。まだ何も決まっていなくてOKです。', '所要：1分', ryugaku_line_url() ),
	array( '無料カウンセリング', 'オンライン or 来社で約60分', '目的・予算・期間をヒアリングし、国・都市・学校の候補を2〜3パターンご提案。費用シミュレーションもその場でお出しします。その場で決める必要はありません。', '所要：60分', ryugaku_counseling_url() ),
	array( '学校決定・お申し込み', '比較表を見ながらじっくり検討', '提案内容をもとにご家族とも相談いただき、学校とコースを決定。お申し込み書は当社が作成します。キャンセルポリシーも事前に書面でご説明します。', '出発3〜6ヶ月前', '' ),
	array( '手続き・お支払い', 'ビザ・航空券・保険をまとめてサポート', '入学許可証の取得、ビザ申請、航空券・海外保険の手配、滞在先の確定を進めます。並行して出発前オンライン英会話がスタート。', '出発1〜3ヶ月前', '' ),
	array( '出発', 'オリエンテーションで最終確認', '持ち物リスト・現地生活ガイド・緊急連絡先をお渡しし、出発前説明会を実施。空港送迎の手配も済ませて、いよいよ出発です。', '出発当日', '' ),
	array( '現地生活', '出発後もLINEで24時間サポート', '到着後のオリエンテーション、生活立ち上げ、学校生活のフォロー。延長や2ヶ国目のご相談、帰国後のキャリア相談まで伴走します。', '留学中〜帰国後', '' ),
);
?>
<?php ryugaku_page_hero( '留学の流れ', 'LINE相談から現地生活まで。6つのステップで、初めての留学もスムーズに。', 'FLOW' ); ?>

<section class="section">
	<div class="container container--narrow">
		<ol class="flow">
			<?php foreach ( $ryugaku_steps as $ryugaku_i => $ryugaku_step ) : ?>
				<li class="flow-step">
					<div class="flow-step__num"><span>STEP</span><strong><?php echo esc_html( $ryugaku_i + 1 ); ?></strong></div>
					<div class="flow-step__body">
						<p class="flow-step__timing"><?php echo esc_html( $ryugaku_step[3] ); ?></p>
						<h2 class="flow-step__title"><?php echo esc_html( $ryugaku_step[0] ); ?></h2>
						<p class="flow-step__sub"><?php echo esc_html( $ryugaku_step[1] ); ?></p>
						<p><?php echo esc_html( $ryugaku_step[2] ); ?></p>
						<?php if ( $ryugaku_step[4] ) : ?>
							<a class="btn btn--sm <?php echo 0 === $ryugaku_i ? 'btn--line' : 'btn--primary'; ?>" href="<?php echo esc_url( $ryugaku_step[4] ); ?>"<?php echo 0 === $ryugaku_i ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo esc_html( $ryugaku_step[0] ); ?>はこちら</a>
						<?php endif; ?>
					</div>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<section class="section section--tint">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '出発までのスケジュール目安', 'SCHEDULE' ); ?>
		<div class="table-wrap">
			<table class="price-table">
				<thead><tr><th>留学タイプ</th><th>相談開始の目安</th><th>理由</th></tr></thead>
				<tbody>
					<tr><th scope="row">短期語学留学（〜3ヶ月）</th><td>出発の2〜3ヶ月前</td><td>ビザ不要のことが多く、航空券の確保が主な準備</td></tr>
					<tr><th scope="row">長期語学留学（3ヶ月〜）</th><td>出発の4〜6ヶ月前</td><td>学生ビザの申請に1〜2ヶ月かかるため</td></tr>
					<tr><th scope="row">ワーキングホリデー</th><td>出発の6〜12ヶ月前</td><td>ビザの抽選・申請時期が限られる国があるため</td></tr>
					<tr><th scope="row">インターン・キャリア留学</th><td>出発の6〜9ヶ月前</td><td>英語力要件のクリアとプログラム選考があるため</td></tr>
				</tbody>
			</table>
		</div>
		<p class="note">※ 直前のご相談でも対応可能な場合があります。まずはお気軽にご連絡ください。</p>
	</div>
</section>

<?php if ( get_the_content() ) : ?>
	<section class="section"><div class="container container--narrow prose"><?php the_content(); ?></div></section>
<?php endif; ?>
<?php get_footer(); ?>
