<?php
/**
 * 固定ページ「会社概要」。カスタマイザーの会社情報を表にして表示し、規約ページへリンク。
 *
 * Template Name: 会社概要
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_rows = array(
	array( '会社名', ryugaku_option( 'company_name', get_bloginfo( 'name' ) ) ),
	array( '所在地', ryugaku_option( 'company_address', '' ) ),
	array( '代表者', ryugaku_option( 'company_ceo', '' ) ),
	array( '設立', ryugaku_option( 'company_founded', '' ) ),
	array( '事業内容', '留学カウンセリング・留学手続き代行・海外教育機関の紹介・語学学習サポート' ),
	array( '登録・認可', ryugaku_option( 'company_license', '' ) ),
	array( '電話番号', ryugaku_option( 'phone', '' ) ),
	array( '受付時間', ryugaku_option( 'business_hours', '' ) ),
	array( 'メール', ryugaku_option( 'contact_email', '' ) ),
);
$ryugaku_links = array(
	array( 'プライバシーポリシー', 'privacy-policy' ),
	array( '利用規約', 'terms' ),
	array( '約款・条件書', 'agreement' ),
	array( 'カスタマーハラスメントに対する行動指針', 'customer-harassment-policy' ),
);
?>
<?php ryugaku_page_hero( '会社概要', '', 'COMPANY' ); ?>

<section class="section">
	<div class="container container--narrow">
		<div class="table-wrap">
			<table class="price-table price-table--compact company-table">
				<tbody>
					<?php foreach ( $ryugaku_rows as $ryugaku_row ) : ?>
						<?php if ( '' === $ryugaku_row[1] ) { continue; } ?>
						<tr><th scope="row"><?php echo esc_html( $ryugaku_row[0] ); ?></th><td><?php echo esc_html( $ryugaku_row[1] ); ?></td></tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php if ( get_the_content() ) : ?>
			<div class="prose" style="margin-top:2rem"><?php the_content(); ?></div>
		<?php endif; ?>
	</div>
</section>

<section class="section section--tint">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '規約・ポリシー', 'POLICIES' ); ?>
		<ul class="link-cards">
			<?php foreach ( $ryugaku_links as $ryugaku_link ) : ?>
				<li><a href="<?php echo esc_url( ryugaku_page_url( $ryugaku_link[1] ) ); ?>"><?php echo esc_html( $ryugaku_link[0] ); ?><?php echo ryugaku_icon( 'arrow' ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
<?php get_footer(); ?>
