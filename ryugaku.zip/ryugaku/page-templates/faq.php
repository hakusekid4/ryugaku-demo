<?php
/**
 * 固定ページ「よくある質問」。FAQ 投稿をカテゴリ(費用・英語力・期間・サポート)ごとに表示。
 *
 * Template Name: よくある質問
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_groups = ryugaku_faq_groups();
?>
<?php ryugaku_page_hero( 'よくある質問', '費用・英語力・期間・サポートについて、よくいただくご質問にお答えします。', 'FAQ' ); ?>

<section class="section">
	<div class="container container--narrow">
		<?php if ( $ryugaku_groups ) : ?>
			<ul class="chip-list chip-list--center" aria-label="カテゴリ">
				<?php foreach ( $ryugaku_groups as $ryugaku_slug => $ryugaku_group ) : ?>
					<li><a class="chip" href="#faq-<?php echo esc_attr( $ryugaku_slug ); ?>"><?php echo esc_html( $ryugaku_group['term']->name ); ?></a></li>
				<?php endforeach; ?>
			</ul>
			<?php foreach ( $ryugaku_groups as $ryugaku_slug => $ryugaku_group ) : ?>
				<div class="faq-group" id="faq-<?php echo esc_attr( $ryugaku_slug ); ?>">
					<h2 class="faq-group__title"><?php echo esc_html( $ryugaku_group['term']->name ); ?></h2>
					<?php
					$ryugaku_pairs = array();
					foreach ( $ryugaku_group['items'] as $ryugaku_item ) {
						$ryugaku_pairs[] = array( $ryugaku_item->post_title, $ryugaku_item->post_content );
					}
					ryugaku_faq_list( $ryugaku_pairs );
					?>
				</div>
			<?php endforeach; ?>
		<?php else : ?>
			<p>FAQは管理画面の「FAQ」から追加できます。カテゴリ（費用・英語力・期間・サポート）を設定すると、ここにグループ表示されます。</p>
		<?php endif; ?>

		<?php if ( get_the_content() ) : ?>
			<div class="prose"><?php the_content(); ?></div>
		<?php endif; ?>

		<div class="inline-cta inline-cta--compact">
			<p class="inline-cta__title">解決しない場合は、お気軽にご相談ください</p>
			<?php ryugaku_cta_buttons(); ?>
		</div>
	</div>
</section>
<?php get_footer(); ?>
