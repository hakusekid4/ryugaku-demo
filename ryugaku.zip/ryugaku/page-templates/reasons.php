<?php
/**
 * 固定ページ「選ばれる理由」。強み 5 つ・他社比較・実績・サポート比較。
 *
 * Template Name: 選ばれる理由
 *
 * @package Ryugaku
 */

get_header();
the_post();
?>
<?php ryugaku_page_hero( '選ばれる理由', '「安さ」だけでも「手厚さ」だけでもない。留学を成功させるための、私たちのこだわりをご紹介します。', 'WHY US' ); ?>

<section class="section">
	<div class="container">
		<?php ryugaku_section_title( '5つの強み', 'STRENGTHS' ); ?>
		<div class="reasons reasons--detail">
			<div class="reason"><span class="reason__num">01</span><h3>手数料0円・追加費用なし</h3><p>学校からの紹介料で運営しているため、カウンセリング・入学手続き・ビザ申請サポート・出発後サポートまでご負担はありません。学校提示価格そのまま、キャンペーン価格も適用されます。</p></div>
			<div class="reason"><span class="reason__num">02</span><h3>カウンセラー全員が留学経験者</h3><p>フィリピン・オーストラリア・カナダ・アメリカ・イギリスなど、実際に留学した経験を持つカウンセラーが担当。パンフレットには載っていない現地のリアルをお伝えします。</p></div>
			<div class="reason"><span class="reason__num">03</span><h3>提携450校から中立に比較提案</h3><p>特定の学校を優先することはありません。目的・予算・環境の希望を聞いたうえで、複数校を比較表にしてご提案します。</p></div>
			<div class="reason"><span class="reason__num">04</span><h3>出発前の英語学習サポート</h3><p>お申し込み後、出発までオンライン英会話レッスンを無料で提供。「現地で最初の1ヶ月を無駄にしない」ための準備を一緒に進めます。</p></div>
			<div class="reason"><span class="reason__num">05</span><h3>出発後もLINEで24時間サポート</h3><p>現地オフィスと日本のスタッフが連携し、トラブル・体調不良・学校変更・延長などに対応。留学中の「困った」を放置しません。</p></div>
		</div>
	</div>
</section>

<section class="section section--tint">
	<div class="container">
		<?php ryugaku_section_title( '他社との比較', 'COMPARISON', '一般的な留学エージェントとの違いをまとめました。' ); ?>
		<div class="table-wrap">
			<table class="price-table compare-table">
				<thead><tr><th></th><th class="is-highlight">当社</th><th>大手エージェントA</th><th>格安エージェントB</th><th>学校へ直接申込</th></tr></thead>
				<tbody>
					<tr><th scope="row">手数料</th><td class="is-highlight">0円</td><td>5〜15万円</td><td>0円</td><td>0円</td></tr>
					<tr><th scope="row">提携校数</th><td class="is-highlight">450校</td><td>1,000校以上</td><td>50校</td><td>—</td></tr>
					<tr><th scope="row">カウンセラーの留学経験</th><td class="is-highlight">全員あり</td><td>一部</td><td>一部</td><td>—</td></tr>
					<tr><th scope="row">出発前英語レッスン</th><td class="is-highlight">無料</td><td>有料</td><td>なし</td><td>なし</td></tr>
					<tr><th scope="row">現地サポート</th><td class="is-highlight">現地オフィス＋LINE 24h</td><td>現地オフィス</td><td>メールのみ</td><td>学校対応のみ</td></tr>
					<tr><th scope="row">ビザ申請サポート</th><td class="is-highlight">無料</td><td>有料</td><td>なし</td><td>自分で申請</td></tr>
					<tr><th scope="row">為替・キャンペーン適用</th><td class="is-highlight">学校価格そのまま</td><td>独自レート</td><td>学校価格</td><td>学校価格</td></tr>
				</tbody>
			</table>
		</div>
		<p class="note">※ 比較内容は一般的な事例をもとにした当社調べです。</p>
	</div>
</section>

<section class="section">
	<div class="container">
		<?php ryugaku_section_title( '実績', 'RESULTS' ); ?>
		<ul class="stats stats--static">
			<?php
			for ( $ryugaku_i = 1; $ryugaku_i <= 4; $ryugaku_i++ ) :
				$ryugaku_raw = ryugaku_option( 'stat_' . $ryugaku_i, '' );
				if ( ! $ryugaku_raw || false === strpos( $ryugaku_raw, '|' ) ) {
					continue;
				}
				$ryugaku_stat = array_map( 'trim', explode( '|', $ryugaku_raw, 2 ) );
				?>
				<li><span class="stats__label"><?php echo esc_html( $ryugaku_stat[0] ); ?></span><strong class="stats__value"><?php echo esc_html( $ryugaku_stat[1] ); ?></strong></li>
			<?php endfor; ?>
		</ul>
		<?php
		$ryugaku_voices = get_posts( array( 'post_type' => 'voice', 'posts_per_page' => 3 ) );
		if ( $ryugaku_voices ) :
			?>
			<div class="grid grid--3" style="margin-top:2.5rem">
				<?php
				global $post;
				foreach ( $ryugaku_voices as $post ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride
					setup_postdata( $post );
					get_template_part( 'template-parts/card', 'voice' );
				endforeach;
				wp_reset_postdata();
				?>
			</div>
		<?php endif; ?>
	</div>
</section>

<section class="section section--tint">
	<div class="container">
		<?php ryugaku_section_title( 'サポート内容の比較', 'SUPPORT', '出発前から帰国後まで、どこまで対応しているかの違いです。' ); ?>
		<div class="table-wrap">
			<table class="price-table compare-table">
				<thead><tr><th>サポート項目</th><th class="is-highlight">当社</th><th>一般的なエージェント</th></tr></thead>
				<tbody>
					<tr><th scope="row">無料カウンセリング（回数無制限）</th><td class="is-highlight">◎</td><td>○（回数制限あり）</td></tr>
					<tr><th scope="row">学校選定・比較資料作成</th><td class="is-highlight">◎</td><td>○</td></tr>
					<tr><th scope="row">入学手続き代行</th><td class="is-highlight">◎</td><td>○</td></tr>
					<tr><th scope="row">ビザ申請サポート</th><td class="is-highlight">◎ 無料</td><td>△ 有料</td></tr>
					<tr><th scope="row">航空券・海外保険の手配</th><td class="is-highlight">◎</td><td>○</td></tr>
					<tr><th scope="row">出発前オンライン英会話</th><td class="is-highlight">◎ 無料</td><td>△ 有料 or なし</td></tr>
					<tr><th scope="row">現地オフィス</th><td class="is-highlight">◎ 主要都市</td><td>△ 一部</td></tr>
					<tr><th scope="row">緊急時24時間対応</th><td class="is-highlight">◎ LINE</td><td>△ メール</td></tr>
					<tr><th scope="row">帰国後のキャリア相談</th><td class="is-highlight">◎</td><td>×</td></tr>
				</tbody>
			</table>
		</div>
		<p class="section__more"><a class="btn btn--ghost" href="<?php echo esc_url( ryugaku_page_url( 'support' ) ); ?>">サポート内容を詳しく見る<?php echo ryugaku_icon( 'arrow' ); ?></a></p>
	</div>
</section>

<?php if ( get_the_content() ) : ?>
	<section class="section"><div class="container container--narrow prose"><?php the_content(); ?></div></section>
<?php endif; ?>
<?php get_footer(); ?>
