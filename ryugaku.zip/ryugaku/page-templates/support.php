<?php
/**
 * 固定ページ「サポート内容」。出発前・学校選定・ビザ・航空券・出発後・現地・他社との違い。
 *
 * Template Name: サポート内容
 *
 * @package Ryugaku
 */

get_header();
the_post();
?>
<?php ryugaku_page_hero( 'サポート内容', '出発前から出発後まで。すべて無料でサポートします。', 'SUPPORT' ); ?>

<nav class="local-nav" aria-label="ページ内リンク">
	<div class="container">
		<ul>
			<li><a href="#before">出発前サポート</a></li>
			<li><a href="#school">学校選定</a></li>
			<li><a href="#visa">ビザ</a></li>
			<li><a href="#flight">航空券・保険</a></li>
			<li><a href="#after">出発後サポート</a></li>
			<li><a href="#local">現地サポート</a></li>
			<li><a href="#compare">他社との違い</a></li>
		</ul>
	</div>
</nav>

<section class="section" id="before">
	<div class="container">
		<?php ryugaku_section_title( '出発前サポート', 'BEFORE DEPARTURE', '', 'left' ); ?>
		<div class="support-grid">
			<div class="support-item"><span class="support-item__icon">💬</span><h3>無料カウンセリング（回数無制限）</h3><p>目的・予算・期間の整理から、国・都市・学校の比較まで。納得いくまで何度でもご相談いただけます。</p></div>
			<div class="support-item"><span class="support-item__icon">📝</span><h3>入学手続き代行</h3><p>申込書の作成、学校とのやり取り、入学許可証の取得まで日本語で完結。英語での書類も代行します。</p></div>
			<div class="support-item"><span class="support-item__icon">🎧</span><h3>出発前オンライン英会話</h3><p>お申し込みから出発まで週2回の無料レッスン。現地初日から授業についていける状態を作ります。</p></div>
			<div class="support-item"><span class="support-item__icon">📚</span><h3>出発前オリエンテーション</h3><p>持ち物・現地の生活・お金・治安・緊急連絡先を網羅したガイドブックと説明会をご用意。</p></div>
		</div>
	</div>
</section>

<section class="section section--tint" id="school">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '学校選定', 'SCHOOL SELECTION', '', 'left' ); ?>
		<p class="lead-text">提携450校の中から、あなたの目的に合う学校を中立の立場で比較提案します。「大手だから」「安いから」ではなく、日本人比率・授業形式・国籍バランス・立地・滞在環境を総合的に判断します。</p>
		<?php ryugaku_check_list( array( '2〜3校を比較表にしてご提案', '実際に視察したカウンセラーのコメント付き', 'キャンペーン・割引情報を随時反映', '空き状況の確認・仮押さえも無料' ), 'check-list check-list--cards' ); ?>
	</div>
</section>

<section class="section" id="visa">
	<div class="container container--narrow">
		<?php ryugaku_section_title( 'ビザ申請サポート', 'VISA', '', 'left' ); ?>
		<div class="grid grid--2">
			<div class="info-card"><h3>学生ビザ</h3><p>オーストラリア・カナダ・アメリカ・イギリスなどの学生ビザ申請書類の作成、オンライン申請の代行、面接対策まで無料でサポートします。</p></div>
			<div class="info-card"><h3>ワーキングホリデービザ</h3><p>抽選や先着の国も、申請開始日のリマインドから書類チェックまで対応。取得率を高めるコツもお伝えします。</p></div>
			<div class="info-card"><h3>観光ビザ・ETA等</h3><p>短期留学に必要な電子渡航認証（ESTA・ETA・eTA）の取得手順をご案内し、必要に応じて代行します。</p></div>
			<div class="info-card"><h3>現地でのビザ延長</h3><p>フィリピンの滞在延長やオーストラリアのビザ切替など、現地オフィスと連携して手続きをサポート。</p></div>
		</div>
	</div>
</section>

<section class="section section--tint" id="flight">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '航空券・海外保険', 'FLIGHT & INSURANCE', '', 'left' ); ?>
		<div class="grid grid--2">
			<div class="info-card"><h3>航空券手配</h3><p>入学日・寮の入退去日に合わせた最適な便をご提案。学生割引や片道航空券（長期の場合）にも対応します。ご自身での手配ももちろんOK。</p></div>
			<div class="info-card"><h3>海外旅行保険</h3><p>治療・救援費用無制限の留学生向けプランをご案内。クレジットカード付帯保険との組み合わせで費用を抑える方法もアドバイスします。</p></div>
		</div>
	</div>
</section>

<section class="section" id="after">
	<div class="container">
		<?php ryugaku_section_title( '出発後サポート', 'AFTER DEPARTURE', '', 'left' ); ?>
		<div class="support-grid">
			<div class="support-item"><span class="support-item__icon">📱</span><h3>LINE 24時間サポート</h3><p>体調不良・盗難・学校とのトラブルなど、緊急時は24時間対応。日常の小さな相談もLINEでどうぞ。</p></div>
			<div class="support-item"><span class="support-item__icon">🔄</span><h3>学校変更・延長・転校</h3><p>「もっと長くいたい」「別の国にも行きたい」。現地での延長や2ヶ国目の手配も無料で対応します。</p></div>
			<div class="support-item"><span class="support-item__icon">👨‍👩‍👧</span><h3>保護者への定期報告</h3><p>ご希望に応じて、ご家族へ近況や学校からの評価を定期的にご報告します。</p></div>
			<div class="support-item"><span class="support-item__icon">💼</span><h3>帰国後のキャリア相談</h3><p>留学経験を活かした就職・転職のご相談。英語を使う仕事の求人紹介も行っています。</p></div>
		</div>
	</div>
</section>

<section class="section section--tint" id="local">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '現地サポート', 'LOCAL SUPPORT', '', 'left' ); ?>
		<p class="lead-text">セブ・シドニー・バンクーバー・トロントに現地オフィスを設置。日本人スタッフが常駐し、到着後のオリエンテーション、銀行口座開設、携帯契約、住まい探し、仕事探しをサポートします。</p>
		<div class="grid grid--4">
			<div class="info-card info-card--center"><h3>🇵🇭 セブ</h3><p>空港送迎・病院同行・ビザ延長</p></div>
			<div class="info-card info-card--center"><h3>🇦🇺 シドニー</h3><p>口座開設・TFN・仕事探し</p></div>
			<div class="info-card info-card--center"><h3>🇨🇦 バンクーバー</h3><p>住まい探し・SIN・Co-op相談</p></div>
			<div class="info-card info-card--center"><h3>🇨🇦 トロント</h3><p>ホームステイ変更・進学相談</p></div>
		</div>
	</div>
</section>

<section class="section" id="compare">
	<div class="container">
		<?php ryugaku_section_title( '他社との違い', 'DIFFERENCE', '', 'left' ); ?>
		<div class="table-wrap">
			<table class="price-table compare-table">
				<thead><tr><th>サポート項目</th><th class="is-highlight">当社</th><th>一般的なエージェント</th></tr></thead>
				<tbody>
					<tr><th scope="row">カウンセリング</th><td class="is-highlight">無制限・無料</td><td>回数制限あり</td></tr>
					<tr><th scope="row">ビザ申請サポート</th><td class="is-highlight">無料</td><td>有料（2〜5万円）</td></tr>
					<tr><th scope="row">出発前英会話</th><td class="is-highlight">無料（週2回）</td><td>有料 or なし</td></tr>
					<tr><th scope="row">緊急時対応</th><td class="is-highlight">LINE 24時間</td><td>メール・営業時間内</td></tr>
					<tr><th scope="row">現地オフィス</th><td class="is-highlight">4都市に日本人常駐</td><td>提携先に委託</td></tr>
					<tr><th scope="row">帰国後サポート</th><td class="is-highlight">キャリア相談あり</td><td>なし</td></tr>
				</tbody>
			</table>
		</div>
	</div>
</section>

<?php if ( get_the_content() ) : ?>
	<section class="section section--tint"><div class="container container--narrow prose"><?php the_content(); ?></div></section>
<?php endif; ?>
<?php get_footer(); ?>
