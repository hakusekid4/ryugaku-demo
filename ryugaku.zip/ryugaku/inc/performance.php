<?php
/**
 * 表示速度対策。不要な head 出力の削除、絵文字 JS 停止、フォントの先読み、jQuery Migrate 停止など。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Remove unnecessary head output.
 */
function ryugaku_clean_head() {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head' );
	add_filter( 'emoji_svg_url', '__return_false' );
}
add_action( 'init', 'ryugaku_clean_head' );

/**
 * Don't load the block library CSS on the front end unless needed for content.
 */
function ryugaku_dequeue_styles() {
	if ( is_admin() ) {
		return;
	}
	wp_dequeue_style( 'classic-theme-styles' );
	wp_dequeue_style( 'global-styles' );
	if ( ! is_singular( array( 'post', 'page', 'purpose', 'voice' ) ) ) {
		wp_dequeue_style( 'wp-block-library' );
	}
}
add_action( 'wp_enqueue_scripts', 'ryugaku_dequeue_styles', 100 );

/**
 * Preconnect / preload for fonts.
 */
function ryugaku_resource_hints() {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
	echo '<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700;900&display=swap" onload="this.onload=null;this.rel=\'stylesheet\'">' . "\n";
	echo '<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700;900&display=swap"></noscript>' . "\n";
}
add_action( 'wp_head', 'ryugaku_resource_hints', 1 );

/**
 * Add fetchpriority to the first content image on singular pages.
 *
 * @param array $attr Attributes.
 * @return array
 */
function ryugaku_hero_image_priority( $attr ) {
	static $done = false;
	if ( ! $done && is_singular() && in_the_loop() ) {
		$done                  = true;
		$attr['loading']       = 'eager';
		$attr['fetchpriority'] = 'high';
	}
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'ryugaku_hero_image_priority' );

/**
 * Disable jQuery migrate on the front end.
 *
 * @param WP_Scripts $scripts Scripts.
 */
function ryugaku_no_jquery_migrate( $scripts ) {
	if ( ! is_admin() && isset( $scripts->registered['jquery'] ) ) {
		$scripts->registered['jquery']->deps = array_diff( $scripts->registered['jquery']->deps, array( 'jquery-migrate' ) );
	}
}
add_action( 'wp_default_scripts', 'ryugaku_no_jquery_migrate' );

/**
 * Disable XML-RPC pingbacks (security + performance).
 */
add_filter( 'xmlrpc_methods', function ( $methods ) {
	unset( $methods['pingback.ping'] );
	return $methods;
} );

/**
 * Limit post revisions to keep the DB light.
 */
add_filter( 'wp_revisions_to_keep', function () { return 10; } );
