<?php
/**
 * テンプレートから呼ぶ共通関数。メタ情報の取得、パンくず、CTA ボタン、アイコン、FAQ 表示など。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Get a post meta value with a default.
 *
 * @param string $key     Meta key without prefix.
 * @param mixed  $default Default value.
 * @param int    $post_id Post ID.
 * @return mixed
 */
function ryugaku_meta( $key, $default = '', $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$value   = get_post_meta( $post_id, '_ryugaku_' . $key, true );
	return ( '' === $value || null === $value ) ? $default : $value;
}

/**
 * Split a textarea meta into a list of non-empty lines.
 *
 * @param string $key     Meta key without prefix.
 * @param int    $post_id Post ID.
 * @return string[]
 */
function ryugaku_meta_lines( $key, $post_id = 0 ) {
	$raw   = (string) ryugaku_meta( $key, '', $post_id );
	$lines = preg_split( '/\r\n|\r|\n/', $raw );
	$lines = array_map( 'trim', $lines );
	return array_values( array_filter( $lines, 'strlen' ) );
}

/**
 * Split "label|description" lines into pairs.
 *
 * @param string $key     Meta key without prefix.
 * @param int    $post_id Post ID.
 * @return array<int, array{0:string,1:string}>
 */
function ryugaku_meta_pairs( $key, $post_id = 0 ) {
	$pairs = array();
	foreach ( ryugaku_meta_lines( $key, $post_id ) as $line ) {
		$parts   = array_map( 'trim', explode( '|', $line, 2 ) );
		$pairs[] = array( $parts[0], isset( $parts[1] ) ? $parts[1] : '' );
	}
	return $pairs;
}

/**
 * Theme option getter (Customizer).
 *
 * @param string $key     Option key.
 * @param mixed  $default Default.
 * @return mixed
 */
function ryugaku_option( $key, $default = '' ) {
	if ( '' === $default ) {
		$defaults = ryugaku_option_defaults();
		$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	}
	$value = get_theme_mod( 'ryugaku_' . $key, $default );
	return ( '' === $value || null === $value ) ? $default : $value;
}

/**
 * カスタマイザー項目の既定値。カスタマイザーの登録とテンプレート表示の両方で使う。
 *
 * @return array<string, string>
 */
function ryugaku_option_defaults() {
	return array(
		'line_url'        => 'https://lin.ee/',
		'counseling_url'  => '',
		'phone'           => '',
		'business_hours'  => '平日 10:00〜19:00',
		'contact_email'   => '',
		'hero_title'      => "あなたに合う留学が、\nきっと見つかる。",
		'hero_lead'       => '手数料0円・無理な営業なし。留学経験のあるカウンセラーが、国選びから出発後まで伴走します。',
		'hero_image'      => '',
		'stat_1'          => '累計サポート|3,200名',
		'stat_2'          => '提携校|450校',
		'stat_3'          => '満足度|98.2%',
		'stat_4'          => '対応国|12ヶ国',
		'company_name'    => '株式会社リュウガクエージェント',
		'company_address' => '東京都渋谷区渋谷1-1-1',
		'company_ceo'     => '',
		'company_founded' => '',
		'company_license' => '',
		'ogp_image'       => '',
		'gtm_id'          => '',
	);
}

/**
 * LINE consultation URL.
 *
 * @return string
 */
function ryugaku_line_url() {
	return esc_url( ryugaku_option( 'line_url', 'https://lin.ee/' ) );
}

/**
 * Free counseling URL (contact page by default).
 *
 * @return string
 */
function ryugaku_counseling_url() {
	$custom = ryugaku_option( 'counseling_url', '' );
	if ( $custom ) {
		return esc_url( $custom );
	}
	return esc_url( ryugaku_page_url( 'contact' ) . '#counseling' );
}

/**
 * Get a page URL by slug with a graceful fallback.
 *
 * @param string $slug Page slug.
 * @return string
 */
function ryugaku_page_url( $slug ) {
	$page = get_page_by_path( $slug );
	if ( $page ) {
		return get_permalink( $page );
	}
	return home_url( '/' . $slug . '/' );
}

/**
 * Format a yen amount in 万円.
 *
 * @param int|float|string $man Amount in 万円.
 * @return string
 */
function ryugaku_man( $man ) {
	if ( '' === $man || null === $man ) {
		return '—';
	}
	return number_format_i18n( (float) $man ) . '万円';
}

/**
 * Get the country post linked to a school.
 *
 * @param int $school_id School post ID.
 * @return WP_Post|null
 */
function ryugaku_school_country( $school_id = 0 ) {
	$country_id = (int) ryugaku_meta( 'school_country', 0, $school_id );
	return $country_id ? get_post( $country_id ) : null;
}

/**
 * Get the flag emoji for a country post.
 *
 * @param int $country_id Country post ID.
 * @return string
 */
function ryugaku_flag( $country_id = 0 ) {
	$flag = ryugaku_meta( 'flag', '', $country_id );
	if ( $flag ) {
		return $flag;
	}
	$code = strtoupper( (string) ryugaku_meta( 'country_code', '', $country_id ) );
	if ( 2 !== strlen( $code ) ) {
		return '🌏';
	}
	$out = '';
	foreach ( str_split( $code ) as $char ) {
		$out .= html_entity_decode( '&#' . ( 127397 + ord( $char ) ) . ';', ENT_QUOTES, 'UTF-8' ); // 国コード2文字を国旗絵文字に変換
	}
	return $out;
}

/**
 * Output the post thumbnail or a decorative placeholder.
 *
 * @param string $size  Image size.
 * @param string $class Extra class.
 * @param int    $post_id Post ID.
 */
function ryugaku_thumbnail( $size = 'ryugaku-card', $class = '', $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( has_post_thumbnail( $post_id ) ) {
		echo get_the_post_thumbnail(
			$post_id,
			$size,
			array(
				'class'    => 'thumb ' . esc_attr( $class ),
				'loading'  => 'lazy',
				'decoding' => 'async',
			)
		);
		return;
	}
	$type   = get_post_type( $post_id );
	$symbol = '📚';
	if ( 'country' === $type ) {
		$symbol = ryugaku_flag( $post_id );
	} elseif ( 'school' === $type ) {
		$symbol = '🏫';
	} elseif ( 'voice' === $type ) {
		$symbol = '🎓';
	} elseif ( 'purpose' === $type ) {
		$symbol = ryugaku_meta( 'icon', '✈️', $post_id );
	}
	$hue = abs( crc32( (string) $post_id ) ) % 360;
	printf(
		'<div class="thumb thumb--placeholder %1$s" style="--ph-hue:%2$d" aria-hidden="true"><span>%3$s</span></div>',
		esc_attr( $class ),
		(int) $hue,
		esc_html( $symbol )
	);
}

/**
 * Output star rating markup.
 *
 * @param float $rating Rating 0-5.
 */
function ryugaku_stars( $rating ) {
	$rating = max( 0, min( 5, (float) $rating ) );
	$full   = (int) floor( $rating );
	$html   = '<span class="stars" aria-label="' . esc_attr( sprintf( '評価 %s / 5', $rating ) ) . '">';
	for ( $i = 1; $i <= 5; $i++ ) {
		$html .= '<span class="star' . ( $i <= $full ? ' is-on' : '' ) . '">★</span>';
	}
	$html .= '<span class="stars__num">' . esc_html( number_format( $rating, 1 ) ) . '</span></span>';
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Breadcrumb trail as an array of [label, url].
 *
 * @return array<int, array{0:string,1:string}>
 */
function ryugaku_breadcrumb_items() {
	$items = array( array( 'ホーム', home_url( '/' ) ) );

	if ( is_front_page() ) {
		return $items;
	}

	if ( is_singular( 'country' ) ) {
		$items[] = array( '国から探す', get_post_type_archive_link( 'country' ) );
		$items[] = array( get_the_title(), '' );
	} elseif ( is_singular( 'school' ) ) {
		$items[] = array( '学校一覧', get_post_type_archive_link( 'school' ) );
		$country = ryugaku_school_country();
		if ( $country ) {
			$items[] = array( $country->post_title, get_permalink( $country ) );
		}
		$items[] = array( get_the_title(), '' );
	} elseif ( is_singular( 'purpose' ) ) {
		$items[] = array( '目的から探す', get_post_type_archive_link( 'purpose' ) );
		$items[] = array( get_the_title(), '' );
	} elseif ( is_singular( 'voice' ) ) {
		$items[] = array( '体験談・実績', get_post_type_archive_link( 'voice' ) );
		$items[] = array( get_the_title(), '' );
	} elseif ( is_singular( 'post' ) ) {
		$items[] = array( 'コラム', ryugaku_column_url() );
		$cats    = get_the_category();
		if ( $cats ) {
			$items[] = array( $cats[0]->name, get_category_link( $cats[0] ) );
		}
		$items[] = array( get_the_title(), '' );
	} elseif ( is_page() ) {
		$ancestors = array_reverse( get_post_ancestors( get_the_ID() ) );
		foreach ( $ancestors as $ancestor ) {
			$items[] = array( get_the_title( $ancestor ), get_permalink( $ancestor ) );
		}
		$items[] = array( get_the_title(), '' );
	} elseif ( is_post_type_archive() ) {
		$labels  = array( 'country' => '国から探す', 'school' => '学校一覧', 'purpose' => '目的から探す', 'voice' => '体験談・実績' );
		$type    = get_query_var( 'post_type' );
		$type    = is_array( $type ) ? reset( $type ) : $type;
		$items[] = array( isset( $labels[ $type ] ) ? $labels[ $type ] : post_type_archive_title( '', false ), '' );
	} elseif ( is_category() ) {
		$items[] = array( 'コラム', ryugaku_column_url() );
		$items[] = array( single_cat_title( '', false ), '' );
	} elseif ( is_tax() ) {
		$items[] = array( single_term_title( '', false ), '' );
	} elseif ( is_home() ) {
		$items[] = array( 'コラム', '' );
	} elseif ( is_search() ) {
		$items[] = array( '検索結果', '' );
	} elseif ( is_404() ) {
		$items[] = array( 'ページが見つかりません', '' );
	} else {
		$items[] = array( wp_get_document_title(), '' );
	}

	return $items;
}

/**
 * URL of the column (blog) index.
 *
 * @return string
 */
function ryugaku_column_url() {
	$page_for_posts = (int) get_option( 'page_for_posts' );
	if ( $page_for_posts ) {
		return get_permalink( $page_for_posts );
	}
	return home_url( '/column/' );
}

/**
 * Render the breadcrumb.
 */
function ryugaku_breadcrumb() {
	$items = ryugaku_breadcrumb_items();
	if ( count( $items ) < 2 ) {
		return;
	}
	echo '<nav class="breadcrumb" aria-label="パンくずリスト"><div class="container"><ol>';
	$last = count( $items ) - 1;
	foreach ( $items as $i => $item ) {
		if ( $i === $last || '' === $item[1] ) {
			printf( '<li aria-current="page">%s</li>', esc_html( $item[0] ) );
		} else {
			printf( '<li><a href="%s">%s</a></li>', esc_url( $item[1] ), esc_html( $item[0] ) );
		}
	}
	echo '</ol></div></nav>';
}

/**
 * Page hero used on inner pages.
 *
 * @param string $title Title.
 * @param string $lead  Lead text.
 * @param string $eyebrow English label.
 */
function ryugaku_page_hero( $title, $lead = '', $eyebrow = '' ) {
	echo '<section class="page-hero"><div class="container">';
	if ( $eyebrow ) {
		printf( '<p class="eyebrow">%s</p>', esc_html( $eyebrow ) );
	}
	printf( '<h1 class="page-hero__title">%s</h1>', esc_html( $title ) );
	if ( $lead ) {
		printf( '<p class="page-hero__lead">%s</p>', esc_html( $lead ) );
	}
	echo '</div></section>';
}

/**
 * Section heading.
 *
 * @param string $title   Japanese title.
 * @param string $eyebrow English label.
 * @param string $lead    Lead text.
 * @param string $align   center|left.
 */
function ryugaku_section_title( $title, $eyebrow = '', $lead = '', $align = 'center' ) {
	printf( '<div class="section-title section-title--%s">', esc_attr( $align ) );
	if ( $eyebrow ) {
		printf( '<p class="eyebrow">%s</p>', esc_html( $eyebrow ) );
	}
	printf( '<h2>%s</h2>', esc_html( $title ) );
	if ( $lead ) {
		printf( '<p class="section-title__lead">%s</p>', esc_html( $lead ) );
	}
	echo '</div>';
}

/**
 * Render both CTA buttons (LINE + counseling).
 *
 * @param string $size   Size modifier.
 * @param bool   $center Center align.
 */
function ryugaku_cta_buttons( $size = '', $center = true ) {
	printf( '<div class="cta-buttons%s%s">', $center ? ' cta-buttons--center' : '', $size ? ' cta-buttons--' . esc_attr( $size ) : '' );
	printf(
		'<a class="btn btn--line" href="%s" target="_blank" rel="noopener"><span class="btn__icon">%s</span>LINEで無料相談</a>',
		ryugaku_line_url(),
		ryugaku_icon( 'line' )
	);
	printf(
		'<a class="btn btn--primary" href="%s"><span class="btn__icon">%s</span>無料カウンセリングを予約</a>',
		ryugaku_counseling_url(),
		ryugaku_icon( 'calendar' )
	);
	echo '</div>';
}

/**
 * Inline SVG icons (kept inline to avoid extra requests).
 *
 * @param string $name Icon name.
 * @return string
 */
function ryugaku_icon( $name ) {
	$icons = array(
		'line'     => '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2C6.48 2 2 5.72 2 10.3c0 4.1 3.55 7.53 8.35 8.18.33.07.77.22.88.5.1.26.07.66.03.92l-.14.86c-.04.26-.2 1 .87.55 1.07-.45 5.77-3.4 7.87-5.82C21.36 13.85 22 12.13 22 10.3 22 5.72 17.52 2 12 2zm-3.7 10.9H6.2a.5.5 0 0 1-.5-.5V8.6a.5.5 0 1 1 1 0v3.3h1.6a.5.5 0 0 1 0 1zm1.6-.5a.5.5 0 1 1-1 0V8.6a.5.5 0 1 1 1 0v3.8zm4.5 0a.5.5 0 0 1-.9.3l-2-2.7v2.4a.5.5 0 1 1-1 0V8.6a.5.5 0 0 1 .9-.3l2 2.7V8.6a.5.5 0 1 1 1 0v3.8zm3.4-2.4a.5.5 0 1 1 0 1h-1.6v1h1.6a.5.5 0 1 1 0 1h-2.1a.5.5 0 0 1-.5-.5V8.6a.5.5 0 0 1 .5-.5h2.1a.5.5 0 1 1 0 1h-1.6v.9h1.6z"/></svg>',
		'calendar' => '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M4 7h16M8 3v4M16 3v4M5 5h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z"/><path fill="currentColor" d="M8 12h3v3H8z"/></svg>',
		'search'   => '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="m16.5 16.5 4 4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
		'check'    => '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" d="m5 12 5 5 9-10"/></svg>',
		'arrow'    => '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M5 12h14m-6-6 6 6-6 6"/></svg>',
		'menu'     => '<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M4 7h16M4 12h16M4 17h16"/></svg>',
		'close'    => '<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M6 6l12 12M18 6 6 18"/></svg>',
		'plus'     => '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M12 5v14M5 12h14"/></svg>',
		'pin'      => '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5" fill="currentColor"/></svg>',
		'yen'      => '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M7 4l5 8 5-8M12 12v8M8 13h8M8 17h8"/></svg>',
		'clock'    => '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M12 7v5l3 2"/></svg>',
	);
	return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
}

/**
 * Convert a plain list of lines to <ul class="check-list">.
 *
 * @param string[] $lines Lines.
 * @param string   $class List class.
 */
function ryugaku_check_list( $lines, $class = 'check-list' ) {
	if ( ! $lines ) {
		return;
	}
	printf( '<ul class="%s">', esc_attr( $class ) );
	foreach ( $lines as $line ) {
		printf( '<li><span class="check-list__icon">%s</span><span>%s</span></li>', ryugaku_icon( 'check' ), esc_html( $line ) );
	}
	echo '</ul>';
}

/**
 * Render the FAQ accordion for a list of [question, answer] pairs.
 *
 * @param array<int, array{0:string,1:string}> $pairs QA pairs.
 */
function ryugaku_faq_list( $pairs ) {
	if ( ! $pairs ) {
		return;
	}
	echo '<div class="faq-list">';
	foreach ( $pairs as $pair ) {
		echo '<details class="faq-item">';
		printf( '<summary class="faq-item__q"><span class="faq-item__mark">Q</span><span>%s</span><span class="faq-item__toggle">%s</span></summary>', esc_html( $pair[0] ), ryugaku_icon( 'plus' ) );
		printf( '<div class="faq-item__a"><span class="faq-item__mark faq-item__mark--a">A</span><div>%s</div></div>', wp_kses_post( wpautop( $pair[1] ) ) );
		echo '</details>';
	}
	echo '</div>';
}

/**
 * Reading-friendly excerpt.
 *
 * @param int $length Length in characters.
 * @param int $post_id Post ID.
 * @return string
 */
function ryugaku_excerpt( $length = 80, $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$post    = get_post( $post_id );
	if ( ! $post ) {
		return '';
	}
	$text = $post->post_excerpt ? $post->post_excerpt : $post->post_content;
	$text = wp_strip_all_tags( strip_shortcodes( $text ) );
	$text = preg_replace( '/\s+/u', ' ', $text );
	return mb_strimwidth( trim( $text ), 0, $length * 2, '…' );
}
