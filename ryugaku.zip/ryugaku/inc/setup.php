<?php
/**
 * テーマの基本設定。対応機能の宣言、メニュー登録、画像サイズ、CSS/JS の読み込み、診断用データ。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register theme supports.
 */
function ryugaku_setup() {
	load_theme_textdomain( 'ryugaku', RYUGAKU_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 320, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor.css' );

	set_post_thumbnail_size( 1200, 630, true );
	add_image_size( 'ryugaku-card', 640, 400, true );
	add_image_size( 'ryugaku-hero', 1600, 900, true );
	add_image_size( 'ryugaku-square', 400, 400, true );

	register_nav_menus(
		array(
			'header' => 'ヘッダーメニュー',
			'footer' => 'フッターメニュー',
			'legal'  => 'フッター（規約系）',
		)
	);
}
add_action( 'after_setup_theme', 'ryugaku_setup' );

/**
 * Content width.
 */
function ryugaku_content_width() {
	$GLOBALS['content_width'] = 840;
}
add_action( 'after_setup_theme', 'ryugaku_content_width', 0 );

/**
 * Widgets.
 */
function ryugaku_widgets() {
	register_sidebar(
		array(
			'name'          => 'コラムサイドバー',
			'id'            => 'sidebar-column',
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget__title">',
			'after_title'   => '</h3>',
		)
	);
}
add_action( 'widgets_init', 'ryugaku_widgets' );

/**
 * Front-end assets.
 */
function ryugaku_assets() {
	$css_ver = filemtime( RYUGAKU_DIR . '/assets/css/main.css' );
	$js_ver  = filemtime( RYUGAKU_DIR . '/assets/js/main.js' );

	wp_enqueue_style( 'ryugaku-main', RYUGAKU_URI . '/assets/css/main.css', array(), $css_ver );
	wp_enqueue_script( 'ryugaku-main', RYUGAKU_URI . '/assets/js/main.js', array(), $js_ver, array( 'strategy' => 'defer', 'in_footer' => true ) );

	$countries = array();
	if ( is_front_page() ) {
		$countries = ryugaku_diagnosis_dataset();
	}

	wp_localize_script(
		'ryugaku-main',
		'ryugakuData',
		array(
			'countries'    => $countries,
			'lineUrl'      => ryugaku_line_url(),
			'counselingUrl' => ryugaku_counseling_url(),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ryugaku_assets' );

/**
 * Dataset used by the country diagnosis widget.
 *
 * @return array<int, array<string, mixed>>
 */
function ryugaku_diagnosis_dataset() {
	$posts = get_posts(
		array(
			'post_type'      => 'country',
			'posts_per_page' => 50,
			'post_status'    => 'publish',
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
		)
	);
	$data  = array();
	foreach ( $posts as $post ) {
		$tags = wp_get_post_terms( $post->ID, 'study_type', array( 'fields' => 'slugs' ) );
		$data[] = array(
			'id'       => $post->ID,
			'name'     => $post->post_title,
			'flag'     => ryugaku_flag( $post->ID ),
			'url'      => get_permalink( $post ),
			'cost'     => (float) ryugaku_meta( 'cost_month', 0, $post->ID ),
			'popular'  => (int) ryugaku_meta( 'popularity', 0, $post->ID ),
			'types'    => is_wp_error( $tags ) ? array() : $tags,
			'climate'  => ryugaku_meta( 'climate', 'mild', $post->ID ),
			'catch'    => ryugaku_meta( 'catch', '', $post->ID ),
			'distance' => (float) ryugaku_meta( 'flight_hours', 10, $post->ID ),
		);
	}
	return $data;
}

/**
 * Body classes.
 *
 * @param string[] $classes Classes.
 * @return string[]
 */
function ryugaku_body_class( $classes ) {
	$classes[] = 'ryugaku';
	if ( is_front_page() ) {
		$classes[] = 'is-front';
	}
	return $classes;
}
add_filter( 'body_class', 'ryugaku_body_class' );

/**
 * Excerpt length / more.
 */
add_filter( 'excerpt_length', function () { return 60; } );
add_filter( 'excerpt_more', function () { return '…'; } );

/**
 * Fallback header menu when no menu is assigned.
 */
function ryugaku_fallback_header_menu() {
	$items = array(
		array( '国から探す', get_post_type_archive_link( 'country' ) ),
		array( '目的から探す', get_post_type_archive_link( 'purpose' ) ),
		array( '料金', ryugaku_page_url( 'plan' ) ),
		array( 'サポート', ryugaku_page_url( 'support' ) ),
		array( 'コラム', ryugaku_column_url() ),
		array( 'FAQ', ryugaku_page_url( 'faq' ) ),
	);
	echo '<ul class="nav-menu">';
	foreach ( $items as $item ) {
		printf( '<li class="menu-item"><a href="%s">%s</a></li>', esc_url( $item[1] ), esc_html( $item[0] ) );
	}
	echo '</ul>';
}

/**
 * Fallback footer menu.
 */
function ryugaku_fallback_footer_menu() {
	$items = array(
		array( '国から探す', get_post_type_archive_link( 'country' ) ),
		array( '目的から探す', get_post_type_archive_link( 'purpose' ) ),
		array( 'サポート内容', ryugaku_page_url( 'support' ) ),
		array( '料金プラン', ryugaku_page_url( 'plan' ) ),
		array( '選ばれる理由', ryugaku_page_url( 'reasons' ) ),
		array( '留学の流れ', ryugaku_page_url( 'flow' ) ),
		array( 'コラム', ryugaku_column_url() ),
		array( '体験談・実績', get_post_type_archive_link( 'voice' ) ),
		array( 'FAQ', ryugaku_page_url( 'faq' ) ),
		array( 'お問い合わせ', ryugaku_page_url( 'contact' ) ),
	);
	echo '<ul class="footer-menu">';
	foreach ( $items as $item ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( $item[1] ), esc_html( $item[0] ) );
	}
	echo '</ul>';
}

/**
 * Fallback legal menu.
 */
function ryugaku_fallback_legal_menu() {
	$items = array(
		array( '会社概要', ryugaku_page_url( 'company' ) ),
		array( 'プライバシーポリシー', ryugaku_page_url( 'privacy-policy' ) ),
		array( '利用規約', ryugaku_page_url( 'terms' ) ),
		array( '約款・条件書', ryugaku_page_url( 'agreement' ) ),
		array( 'カスタマーハラスメントに対する行動指針', ryugaku_page_url( 'customer-harassment-policy' ) ),
	);
	echo '<ul class="footer-menu footer-menu--legal">';
	foreach ( $items as $item ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( $item[1] ), esc_html( $item[0] ) );
	}
	echo '</ul>';
}
