<?php
/**
 * お問い合わせフォームの処理。入力チェック、迷惑投稿対策、管理画面への保存、メール通知、自動返信。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handle form submission on the contact page.
 */
function ryugaku_handle_contact() {
	if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] || ! isset( $_POST['ryugaku_contact'] ) ) {
		return;
	}
	if ( ! isset( $_POST['ryugaku_contact_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ryugaku_contact_nonce'] ) ), 'ryugaku_contact' ) ) {
		ryugaku_contact_redirect( 'error' );
	}
	// Honeypot + timing check (spam protection without external services).
	if ( ! empty( $_POST['website'] ) ) {
		ryugaku_contact_redirect( 'sent' );
	}
	$started = isset( $_POST['ryugaku_ts'] ) ? (int) $_POST['ryugaku_ts'] : 0;
	if ( $started && ( time() - $started ) < 3 ) {
		ryugaku_contact_redirect( 'error' );
	}

	$fields = array(
		'name'    => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
		'email'   => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
		'tel'     => sanitize_text_field( wp_unslash( $_POST['tel'] ?? '' ) ),
		'type'    => sanitize_text_field( wp_unslash( $_POST['type'] ?? '' ) ),
		'country' => sanitize_text_field( wp_unslash( $_POST['country'] ?? '' ) ),
		'period'  => sanitize_text_field( wp_unslash( $_POST['period'] ?? '' ) ),
		'timing'  => sanitize_text_field( wp_unslash( $_POST['timing'] ?? '' ) ),
		'method'  => sanitize_text_field( wp_unslash( $_POST['method'] ?? '' ) ),
		'message' => sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) ),
		'agree'   => ! empty( $_POST['agree'] ),
	);

	$errors = array();
	if ( '' === $fields['name'] ) {
		$errors[] = 'name';
	}
	if ( ! is_email( $fields['email'] ) ) {
		$errors[] = 'email';
	}
	if ( ! $fields['agree'] ) {
		$errors[] = 'agree';
	}
	if ( $errors ) {
		set_transient( 'ryugaku_contact_' . ryugaku_contact_session(), array( 'errors' => $errors, 'values' => $fields ), 300 );
		ryugaku_contact_redirect( 'invalid' );
	}

	$labels = array(
		'name'    => 'お名前',
		'email'   => 'メールアドレス',
		'tel'     => '電話番号',
		'type'    => 'ご相談内容',
		'country' => '希望の国',
		'period'  => '希望期間',
		'timing'  => '出発時期',
		'method'  => '希望の連絡方法',
		'message' => 'ご質問・ご要望',
	);
	$body = '';
	foreach ( $labels as $key => $label ) {
		$body .= $label . "：\n" . ( '' !== $fields[ $key ] ? $fields[ $key ] : '（未入力）' ) . "\n\n";
	}
	$body .= "送信日時：" . wp_date( 'Y-m-d H:i' ) . "\n";
	$body .= "送信ページ：" . esc_url_raw( wp_get_referer() ) . "\n";

	$post_id = wp_insert_post(
		array(
			'post_type'    => 'inquiry',
			'post_status'  => 'private',
			'post_title'   => sprintf( '%s 様（%s）', $fields['name'], $fields['type'] ? $fields['type'] : 'お問い合わせ' ),
			'post_content' => $body,
		)
	);
	if ( $post_id ) {
		foreach ( $fields as $key => $value ) {
			update_post_meta( $post_id, '_ryugaku_inquiry_' . $key, is_bool( $value ) ? (int) $value : $value );
		}
	}

	$to      = ryugaku_option( 'contact_email', '' );
	$to      = $to ? $to : get_option( 'admin_email' );
	$subject = sprintf( '【%s】無料相談のお申し込み：%s 様', get_bloginfo( 'name' ), $fields['name'] );
	$headers = array( 'Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $fields['email'] );
	wp_mail( $to, $subject, $body, $headers );

	$auto = "{$fields['name']} 様\n\nこの度は" . get_bloginfo( 'name' ) . "へお問い合わせいただき、ありがとうございます。\n担当カウンセラーより1営業日以内にご連絡いたします。\n\n--- お問い合わせ内容 ---\n" . $body . "\n※本メールは自動送信です。\n" . get_bloginfo( 'name' ) . "\n" . home_url( '/' );
	wp_mail( $fields['email'], sprintf( '【%s】お問い合わせを受け付けました', get_bloginfo( 'name' ) ), $auto, array( 'Content-Type: text/plain; charset=UTF-8' ) );

	ryugaku_contact_redirect( 'sent' );
}
add_action( 'template_redirect', 'ryugaku_handle_contact' );

/**
 * A per-visitor key for temporary error storage.
 *
 * @return string
 */
function ryugaku_contact_session() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
	return substr( md5( $ip . $ua . wp_salt() ), 0, 16 );
}

/**
 * Redirect back to the contact page with a status.
 *
 * @param string $status Status.
 */
function ryugaku_contact_redirect( $status ) {
	$url = add_query_arg( 'contact', $status, ryugaku_page_url( 'contact' ) ) . '#counseling';
	wp_safe_redirect( $url );
	exit;
}

/**
 * Get stored validation state (and clear it).
 *
 * @return array{errors: string[], values: array<string, mixed>}
 */
function ryugaku_contact_state() {
	$key   = 'ryugaku_contact_' . ryugaku_contact_session();
	$state = get_transient( $key );
	if ( $state ) {
		delete_transient( $key );
		return $state;
	}
	return array( 'errors' => array(), 'values' => array() );
}

/**
 * Show inquiry meta in the admin list.
 */
add_filter( 'manage_inquiry_posts_columns', function ( $columns ) {
	return array(
		'cb'      => $columns['cb'],
		'title'   => 'お名前',
		'email'   => 'メール',
		'type'    => '相談内容',
		'country' => '希望の国',
		'date'    => '受信日',
	);
} );
add_action( 'manage_inquiry_posts_custom_column', function ( $column, $post_id ) {
	if ( in_array( $column, array( 'email', 'type', 'country' ), true ) ) {
		echo esc_html( get_post_meta( $post_id, '_ryugaku_inquiry_' . $column, true ) );
	}
}, 10, 2 );
