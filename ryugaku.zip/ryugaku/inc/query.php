<?php
/**
 * 一覧ページの検索・絞り込み・並び替え(pre_get_posts)と、国に紐づく学校/体験談の取得。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Current sort key from the request.
 *
 * @param string $default Default.
 * @return string
 */
function ryugaku_current_sort( $default = 'popular' ) {
	$sort = isset( $_GET['sort'] ) ? sanitize_key( wp_unslash( $_GET['sort'] ) ) : $default; // phpcs:ignore WordPress.Security.NonceVerification
	return in_array( $sort, array( 'popular', 'cost', 'cost_desc', 'name', 'rating' ), true ) ? $sort : $default;
}

/**
 * Current text query for archives.
 *
 * @return string
 */
function ryugaku_current_keyword() {
	return isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
}

/**
 * Current filter value.
 *
 * @param string $key Key.
 * @return string
 */
function ryugaku_current_filter( $key ) {
	return isset( $_GET[ $key ] ) ? sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
}

/**
 * Apply sorting / filtering to archive queries.
 *
 * @param WP_Query $query Query.
 */
function ryugaku_pre_get_posts( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}

	if ( $query->is_post_type_archive( 'country' ) || $query->is_tax( 'region' ) ) {
		$query->set( 'posts_per_page', 24 );
		ryugaku_apply_sort( $query, 'popular', array( 'popular' => '_ryugaku_popularity', 'cost' => '_ryugaku_cost_month', 'cost_desc' => '_ryugaku_cost_month' ) );
		$keyword = ryugaku_current_keyword();
		if ( $keyword ) {
			$query->set( 's', $keyword );
		}
		$type = ryugaku_current_filter( 'type' );
		if ( $type ) {
			$query->set( 'tax_query', array( array( 'taxonomy' => 'study_type', 'field' => 'slug', 'terms' => $type ) ) );
		}
	}

	if ( $query->is_post_type_archive( 'school' ) ) {
		$query->set( 'posts_per_page', 18 );
		ryugaku_apply_sort( $query, 'popular', array( 'popular' => '_ryugaku_school_rating', 'rating' => '_ryugaku_school_rating', 'cost' => '_ryugaku_school_cost_4w', 'cost_desc' => '_ryugaku_school_cost_4w' ) );
		$keyword = ryugaku_current_keyword();
		if ( $keyword ) {
			$query->set( 's', $keyword );
		}
		$meta_query = array();
		$country    = (int) ryugaku_current_filter( 'country' );
		if ( $country ) {
			$meta_query[] = array( 'key' => '_ryugaku_school_country', 'value' => $country );
		}
		$city = ryugaku_current_filter( 'city' );
		if ( $city ) {
			$meta_query[] = array( 'key' => '_ryugaku_school_city', 'value' => $city, 'compare' => 'LIKE' );
		}
		if ( $meta_query ) {
			// 並び替え条件(あれば)と絞り込み条件を AND で結合する
			$existing = (array) $query->get( 'meta_query' );
			if ( ! $existing ) {
				$existing = array( 'relation' => 'AND' );
			}
			foreach ( $meta_query as $clause ) {
				$existing[] = $clause;
			}
			$query->set( 'meta_query', $existing );
		}
		$type = ryugaku_current_filter( 'type' );
		if ( $type ) {
			$query->set( 'tax_query', array( array( 'taxonomy' => 'study_type', 'field' => 'slug', 'terms' => $type ) ) );
		}
	}

	if ( $query->is_post_type_archive( 'purpose' ) ) {
		$query->set( 'posts_per_page', -1 );
		$query->set( 'orderby', 'menu_order title' );
		$query->set( 'order', 'ASC' );
	}

	if ( $query->is_post_type_archive( 'voice' ) ) {
		$query->set( 'posts_per_page', 12 );
	}

	if ( $query->is_search() ) {
		$query->set( 'post_type', array( 'post', 'page', 'country', 'school', 'purpose', 'voice' ) );
	}
}
add_action( 'pre_get_posts', 'ryugaku_pre_get_posts' );

/**
 * 絞り込みで該当 0 件になっても 404 にせず、一覧ページ(該当なし表示)を返す。
 *
 * @param bool     $preempt 既定の 404 判定を止めるか。
 * @param WP_Query $query   メインクエリ。
 * @return bool
 */
function ryugaku_no_404_on_filtered_archive( $preempt, $query ) {
	if ( $query->is_post_type_archive( array( 'country', 'school', 'voice', 'purpose' ) ) || $query->is_tax( 'region' ) ) {
		return true;
	}
	return $preempt;
}
add_filter( 'pre_handle_404', 'ryugaku_no_404_on_filtered_archive', 10, 2 );

/**
 * Apply sorting based on the request.
 *
 * @param WP_Query $query   Query.
 * @param string   $default Default sort.
 * @param array    $map     Sort key => meta key.
 */
function ryugaku_apply_sort( $query, $default, $map ) {
	$sort = ryugaku_current_sort( $default );
	if ( 'name' === $sort ) {
		$query->set( 'orderby', 'title' );
		$query->set( 'order', 'ASC' );
		return;
	}
	if ( ! isset( $map[ $sort ] ) ) {
		return;
	}
	// 並び替え用の条件は OR(値あり or 値なし)でまとめ、絞り込み条件とは AND で組み合わせる。
	// 値が未入力の投稿も一覧から消えないようにするための書き方。
	$query->set(
		'meta_query',
		array(
			'relation' => 'AND',
			array(
				'relation' => 'OR',
				'sort_key' => array( 'key' => $map[ $sort ], 'type' => 'DECIMAL(10,2)' ),
				array( 'key' => $map[ $sort ], 'compare' => 'NOT EXISTS' ),
			),
		)
	);
	$query->set( 'orderby', array( 'sort_key' => ( 'cost' === $sort ) ? 'ASC' : 'DESC', 'title' => 'ASC' ) );
}

/**
 * Build a URL for the current archive with modified query args.
 *
 * @param array $args Args to merge.
 * @return string
 */
function ryugaku_archive_url( $args ) {
	$current = array();
	foreach ( array( 'sort', 'q', 'type', 'country', 'city' ) as $key ) {
		$value = ryugaku_current_filter( $key );
		if ( '' !== $value ) {
			$current[ $key ] = $value;
		}
	}
	$merged = array_filter( array_merge( $current, $args ), 'strlen' );
	$base   = get_pagenum_link( 1, false );
	$base   = remove_query_arg( array( 'sort', 'q', 'type', 'country', 'city' ), $base );
	return esc_url( add_query_arg( array_map( 'rawurlencode', $merged ), $base ) );
}

/**
 * Get schools for a country.
 *
 * @param int $country_id Country ID.
 * @param int $limit      Limit.
 * @return WP_Post[]
 */
function ryugaku_schools_for_country( $country_id, $limit = 6 ) {
	return get_posts(
		array(
			'post_type'      => 'school',
			'posts_per_page' => $limit,
			'meta_key'       => '_ryugaku_school_country',
			'meta_value'     => $country_id,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
		)
	);
}

/**
 * Get testimonials for a country.
 *
 * @param int $country_id Country ID.
 * @param int $limit      Limit.
 * @return WP_Post[]
 */
function ryugaku_voices_for_country( $country_id, $limit = 3 ) {
	return get_posts(
		array(
			'post_type'      => 'voice',
			'posts_per_page' => $limit,
			'meta_key'       => '_ryugaku_voice_country',
			'meta_value'     => $country_id,
		)
	);
}

/**
 * Get FAQ items grouped by category.
 *
 * @return array<string, array{term: WP_Term, items: WP_Post[]}>
 */
function ryugaku_faq_groups() {
	$terms  = get_terms( array( 'taxonomy' => 'faq_category', 'hide_empty' => true, 'orderby' => 'term_id' ) );
	$groups = array();
	if ( is_wp_error( $terms ) ) {
		return $groups;
	}
	foreach ( $terms as $term ) {
		$items = get_posts(
			array(
				'post_type'      => 'faq',
				'posts_per_page' => -1,
				'orderby'        => 'menu_order title',
				'order'          => 'ASC',
				'tax_query'      => array( array( 'taxonomy' => 'faq_category', 'field' => 'term_id', 'terms' => $term->term_id ) ),
			)
		);
		if ( $items ) {
			$groups[ $term->slug ] = array( 'term' => $term, 'items' => $items );
		}
	}
	return $groups;
}
