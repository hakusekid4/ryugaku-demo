<?php
/**
 * 管理画面の補助。一覧カラム、メディア選択ボタン、初期設定ページ(固定ページ作成・デモ投入)。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin assets for meta boxes.
 *
 * @param string $hook Hook.
 */
function ryugaku_admin_assets( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php', 'appearance_page_ryugaku-setup' ), true ) ) {
		return;
	}
	wp_enqueue_media();
	wp_add_inline_style( 'wp-admin', '.ryugaku-fields th{width:240px}.ryugaku-fields textarea{font-family:monospace}' );
	wp_add_inline_script(
		'media-editor',
		"document.addEventListener('click',function(e){var b=e.target.closest('.ryugaku-media-btn');if(!b)return;e.preventDefault();var t=document.getElementById(b.dataset.target);var f=wp.media({title:'写真を選択',multiple:true,library:{type:'image'}});f.on('select',function(){var ids=f.state().get('selection').map(function(a){return a.id});var cur=t.value?t.value.split(',').filter(Boolean):[];t.value=cur.concat(ids).filter(function(v,i,a){return a.indexOf(v)===i}).join(',');});f.open();});"
	);
}
add_action( 'admin_enqueue_scripts', 'ryugaku_admin_assets' );

/**
 * Country list columns.
 */
add_filter( 'manage_country_posts_columns', function ( $columns ) {
	$new = array();
	foreach ( $columns as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'title' === $key ) {
			$new['popularity'] = '人気度';
			$new['cost']       = '1ヶ月費用';
		}
	}
	return $new;
} );
add_action( 'manage_country_posts_custom_column', function ( $column, $post_id ) {
	if ( 'popularity' === $column ) {
		echo esc_html( ryugaku_meta( 'popularity', '—', $post_id ) );
	} elseif ( 'cost' === $column ) {
		echo esc_html( ryugaku_man( ryugaku_meta( 'cost_month', '', $post_id ) ) );
	}
}, 10, 2 );
add_filter( 'manage_edit-country_sortable_columns', function ( $columns ) {
	$columns['popularity'] = 'popularity';
	$columns['cost']       = 'cost';
	return $columns;
} );

/**
 * School list columns.
 */
add_filter( 'manage_school_posts_columns', function ( $columns ) {
	$new = array();
	foreach ( $columns as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'title' === $key ) {
			$new['country'] = '国';
			$new['city']    = '都市';
			$new['cost']    = '4週間費用';
		}
	}
	return $new;
} );
add_action( 'manage_school_posts_custom_column', function ( $column, $post_id ) {
	if ( 'country' === $column ) {
		$country = ryugaku_school_country( $post_id );
		echo $country ? esc_html( $country->post_title ) : '—';
	} elseif ( 'city' === $column ) {
		echo esc_html( ryugaku_meta( 'school_city', '—', $post_id ) );
	} elseif ( 'cost' === $column ) {
		echo esc_html( ryugaku_man( ryugaku_meta( 'school_cost_4w', '', $post_id ) ) );
	}
}, 10, 2 );

/**
 * Sort admin lists by meta columns.
 *
 * @param WP_Query $query Query.
 */
function ryugaku_admin_orderby( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}
	$orderby = $query->get( 'orderby' );
	if ( 'popularity' === $orderby ) {
		$query->set( 'meta_key', '_ryugaku_popularity' );
		$query->set( 'orderby', 'meta_value_num' );
	} elseif ( 'cost' === $orderby ) {
		$query->set( 'meta_key', 'country' === $query->get( 'post_type' ) ? '_ryugaku_cost_month' : '_ryugaku_school_cost_4w' );
		$query->set( 'orderby', 'meta_value_num' );
	}
}
add_action( 'pre_get_posts', 'ryugaku_admin_orderby' );

/**
 * Setup page under Appearance.
 */
function ryugaku_admin_menu() {
	add_theme_page( '留学サイト初期設定', '留学サイト初期設定', 'manage_options', 'ryugaku-setup', 'ryugaku_render_setup_page' );
}
add_action( 'admin_menu', 'ryugaku_admin_menu' );

/**
 * Render setup page.
 */
function ryugaku_render_setup_page() {
	if ( isset( $_POST['ryugaku_import_demo'] ) && check_admin_referer( 'ryugaku_import_demo' ) && current_user_can( 'manage_options' ) ) {
		$result = ryugaku_import_demo_content();
		printf( '<div class="notice notice-success"><p>デモコンテンツを投入しました（作成：%d件、スキップ：%d件）。パーマリンクを再保存済みです。</p></div>', (int) $result['created'], (int) $result['skipped'] );
	}
	if ( isset( $_POST['ryugaku_create_pages'] ) && check_admin_referer( 'ryugaku_create_pages' ) && current_user_can( 'manage_options' ) ) {
		$result = ryugaku_create_required_pages();
		printf( '<div class="notice notice-success"><p>固定ページを作成しました（作成：%d件、スキップ：%d件）。</p></div>', (int) $result['created'], (int) $result['skipped'] );
	}
	?>
	<div class="wrap">
		<h1>留学サイト初期設定</h1>
		<p>このテーマは、国・学校・留学タイプ・体験談・FAQ・コラムを管理画面から更新できます。初回セットアップとして、以下を順に実行してください。</p>
		<h2>1. 固定ページとメニューを作成</h2>
		<p>HOME／国から探す／料金プラン／サポート内容／留学の流れ／FAQ／お問い合わせ／会社概要／規約系ページを作成し、フロントページとコラム一覧を設定します。既存のスラッグは上書きしません。</p>
		<form method="post">
			<?php wp_nonce_field( 'ryugaku_create_pages' ); ?>
			<p><button class="button button-primary" name="ryugaku_create_pages" value="1">固定ページを作成する</button></p>
		</form>
		<h2>2. デモコンテンツを投入（任意）</h2>
		<p>国・学校・留学タイプ・体験談・FAQ・コラムのサンプルデータを投入します。本番運用前に内容を差し替えてください。既に同じタイトルの投稿がある場合はスキップされます。</p>
		<form method="post">
			<?php wp_nonce_field( 'ryugaku_import_demo' ); ?>
			<p><button class="button" name="ryugaku_import_demo" value="1">デモコンテンツを投入する</button></p>
		</form>
		<h2>3. サイト設定</h2>
		<ul style="list-style:disc;padding-left:1.5em">
			<li><a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>">カスタマイザー</a>：LINE相談URL・電話番号・キャッチコピー・会社情報・OGP画像</li>
			<li><a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>">メニュー</a>：ヘッダー／フッター／規約系メニュー（未設定でも自動で表示されます）</li>
			<li><a href="<?php echo esc_url( admin_url( 'options-permalink.php' ) ); ?>">パーマリンク</a>：「投稿名」を推奨</li>
		</ul>
	</div>
	<?php
}

/**
 * Create required pages with templates.
 *
 * @return array{created:int,skipped:int}
 */
function ryugaku_create_required_pages() {
	$pages = array(
		'home'       => array( 'title' => 'ホーム', 'template' => '' ),
		'column'     => array( 'title' => 'コラム', 'template' => '' ),
		'reasons'    => array( 'title' => '選ばれる理由', 'template' => 'page-templates/reasons.php' ),
		'plan'       => array( 'title' => '料金プラン', 'template' => 'page-templates/plan.php' ),
		'support'    => array( 'title' => 'サポート内容', 'template' => 'page-templates/support.php' ),
		'flow'       => array( 'title' => '留学の流れ', 'template' => 'page-templates/flow.php' ),
		'faq'        => array( 'title' => 'よくある質問', 'template' => 'page-templates/faq.php' ),
		'contact'    => array( 'title' => 'お問い合わせ・無料カウンセリング', 'template' => 'page-templates/contact.php' ),
		'company'    => array( 'title' => '会社概要', 'template' => 'page-templates/company.php' ),
		'privacy-policy' => array( 'title' => 'プライバシーポリシー', 'template' => '', 'content' => ryugaku_legal_content( 'privacy' ) ),
		'terms'      => array( 'title' => '利用規約', 'template' => '', 'content' => ryugaku_legal_content( 'terms' ) ),
		'agreement'  => array( 'title' => '約款・条件書', 'template' => '', 'content' => ryugaku_legal_content( 'agreement' ) ),
		'customer-harassment-policy' => array( 'title' => 'カスタマーハラスメントに対する行動指針', 'template' => '', 'content' => ryugaku_legal_content( 'harassment' ) ),
	);
	$created = 0;
	$skipped = 0;
	$ids     = array();
	foreach ( $pages as $slug => $page ) {
		$existing = get_page_by_path( $slug );
		if ( $existing && 'publish' === $existing->post_status ) {
			$ids[ $slug ] = $existing->ID;
			$skipped++;
			continue;
		}
		if ( $existing ) {
			// WordPress が自動で作る下書きの「プライバシーポリシー」などは、内容を入れて公開する
			wp_update_post(
				array(
					'ID'           => $existing->ID,
					'post_status'  => 'publish',
					'post_title'   => $page['title'],
					'post_content' => isset( $page['content'] ) ? $page['content'] : $existing->post_content,
				)
			);
			if ( $page['template'] ) {
				update_post_meta( $existing->ID, '_wp_page_template', $page['template'] );
			}
			$ids[ $slug ] = $existing->ID;
			$created++;
			continue;
		}
		$id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $page['title'],
				'post_name'    => $slug,
				'post_content' => isset( $page['content'] ) ? $page['content'] : '',
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			if ( $page['template'] ) {
				update_post_meta( $id, '_wp_page_template', $page['template'] );
			}
			$ids[ $slug ] = $id;
			$created++;
		}
	}
	if ( isset( $ids['home'], $ids['column'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $ids['home'] );
		update_option( 'page_for_posts', $ids['column'] );
	}
	if ( isset( $ids['privacy-policy'] ) ) {
		update_option( 'wp_page_for_privacy_policy', $ids['privacy-policy'] );
	}
	flush_rewrite_rules();
	return array( 'created' => $created, 'skipped' => $skipped );
}
