<?php
/**
 * SEO 内部対策。title・meta description・OGP・canonical・noindex・JSON-LD(組織/パンくず/記事/FAQ/学校)・サイトマップ。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Title separator.
 */
add_filter( 'document_title_separator', function () { return '|'; } );

/**
 * Custom title parts.
 *
 * @param array $parts Title parts.
 * @return array
 */
function ryugaku_document_title_parts( $parts ) {
	if ( is_singular() ) {
		$custom = ryugaku_meta( 'seo_title', '', get_queried_object_id() );
		if ( $custom ) {
			$parts['title'] = $custom;
		}
	} elseif ( is_post_type_archive( 'country' ) ) {
		$parts['title'] = '国から探す｜留学先の国一覧・費用比較';
	} elseif ( is_post_type_archive( 'school' ) ) {
		$parts['title'] = '学校一覧｜語学学校を国・都市・費用で探す';
	} elseif ( is_post_type_archive( 'purpose' ) ) {
		$parts['title'] = '目的から探す｜語学留学・ワーホリ・インターン・キャリア留学';
	} elseif ( is_post_type_archive( 'voice' ) ) {
		$parts['title'] = '体験談・実績｜留学した先輩のリアルな声';
	}
	if ( is_front_page() ) {
		$parts = array( 'title' => get_bloginfo( 'name' ), 'tagline' => get_bloginfo( 'description' ) );
	}
	return $parts;
}
add_filter( 'document_title_parts', 'ryugaku_document_title_parts' );

/**
 * Build the meta description for the current view.
 *
 * @return string
 */
function ryugaku_meta_description() {
	if ( is_front_page() ) {
		return get_bloginfo( 'description' ) . ' 語学留学・ワーホリ・インターン・キャリア留学まで、手数料0円で国選びから出発後までサポート。LINEで気軽に無料相談できます。';
	}
	if ( is_singular() ) {
		$id     = get_queried_object_id();
		$custom = ryugaku_meta( 'seo_description', '', $id );
		if ( $custom ) {
			return $custom;
		}
		if ( is_singular( 'country' ) ) {
			return sprintf( '%sの留学情報。特徴・おすすめの人・費用目安（1ヶ月%s〜）・人気都市・学校一覧・メリットとデメリットをまとめました。', get_the_title( $id ), ryugaku_man( ryugaku_meta( 'cost_month', '', $id ) ) );
		}
		if ( is_singular( 'school' ) ) {
			$country = ryugaku_school_country( $id );
			return sprintf( '%s（%s・%s）の学校情報。費用目安・コース・滞在方法・特徴を紹介。無料カウンセリングで詳しくご案内します。', get_the_title( $id ), $country ? $country->post_title : '', ryugaku_meta( 'school_city', '', $id ) );
		}
		return ryugaku_excerpt( 60, $id );
	}
	if ( is_post_type_archive( 'country' ) ) {
		return '留学先の国を人気順・費用順で比較。フィリピン・オーストラリア・カナダ・アメリカなど、各国の特徴と費用目安を一覧で確認できます。';
	}
	if ( is_post_type_archive( 'school' ) ) {
		return '提携する語学学校を国・都市・費用で検索。日本人比率や定員、コース内容まで比較して、あなたに合う学校を見つけられます。';
	}
	if ( is_post_type_archive( 'purpose' ) ) {
		return '語学留学・ワーキングホリデー・インターン留学・キャリア留学。目的別に概要・メリット・費用・期間・よくある質問をまとめました。';
	}
	if ( is_post_type_archive( 'voice' ) ) {
		return '実際に留学した先輩のインタビュー。留学前の悩みから留学後の変化、保護者の声、卒業後のキャリアまで紹介します。';
	}
	if ( is_category() || is_tax() || is_tag() ) {
		$desc = term_description();
		return $desc ? wp_strip_all_tags( $desc ) : single_term_title( '', false ) . 'に関する記事一覧です。';
	}
	if ( is_home() ) {
		return '留学費用・国比較・英語学習・体験談など、留学準備に役立つコラムを配信しています。';
	}
	return get_bloginfo( 'description' );
}

/**
 * OGP image URL.
 *
 * @return string
 */
function ryugaku_og_image() {
	if ( is_singular() && has_post_thumbnail() ) {
		$src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'post-thumbnail' );
		if ( $src ) {
			return $src[0];
		}
	}
	$default = ryugaku_option( 'ogp_image', '' );
	return $default ? $default : RYUGAKU_URI . '/assets/img/ogp.svg';
}

/**
 * Output meta tags.
 */
function ryugaku_meta_tags() {
	$description = ryugaku_meta_description();
	$title       = wp_get_document_title();
	$url         = '';
	$type        = 'website';
	$noindex     = false;

	if ( is_singular() ) {
		$url     = get_permalink();
		$type    = is_singular( 'post' ) ? 'article' : 'website';
		$noindex = (bool) ryugaku_meta( 'seo_noindex', '', get_queried_object_id() );
	} elseif ( is_front_page() ) {
		$url = home_url( '/' );
	} elseif ( is_post_type_archive() ) {
		$url = get_post_type_archive_link( get_query_var( 'post_type' ) );
	} elseif ( is_category() || is_tax() || is_tag() ) {
		$url = get_term_link( get_queried_object() );
	} elseif ( is_home() ) {
		$url = ryugaku_column_url();
	}

	if ( is_search() || is_404() || is_date() || is_author() ) {
		$noindex = true;
	}
	if ( is_paged() ) {
		$url = get_pagenum_link( get_query_var( 'paged' ), false );
	} elseif ( ! is_singular() && ! empty( $_GET ) && ( is_post_type_archive( 'country' ) || is_post_type_archive( 'school' ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$noindex = true;
	}

	echo "\n<!-- SEO -->\n";
	printf( '<meta name="description" content="%s">' . "\n", esc_attr( $description ) );
	if ( $noindex ) {
		echo '<meta name="robots" content="noindex,follow">' . "\n";
	} else {
		echo '<meta name="robots" content="index,follow,max-image-preview:large">' . "\n";
	}
	if ( $url ) {
		printf( '<link rel="canonical" href="%s">' . "\n", esc_url( $url ) );
		printf( '<meta property="og:url" content="%s">' . "\n", esc_url( $url ) );
	}
	printf( '<meta property="og:type" content="%s">' . "\n", esc_attr( $type ) );
	printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
	printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $description ) );
	printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( get_bloginfo( 'name' ) ) );
	printf( '<meta property="og:image" content="%s">' . "\n", esc_url( ryugaku_og_image() ) );
	echo '<meta property="og:locale" content="ja_JP">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="format-detection" content="telephone=no">' . "\n";
	echo '<meta name="theme-color" content="#0b7285">' . "\n";
}
add_action( 'wp_head', 'ryugaku_meta_tags', 2 );

/**
 * JSON-LD structured data.
 */
function ryugaku_json_ld() {
	$graph = array();
	$home  = home_url( '/' );
	$name  = ryugaku_option( 'company_name', get_bloginfo( 'name' ) );

	$graph[] = array(
		'@type'    => 'Organization',
		'@id'      => $home . '#organization',
		'name'     => $name,
		'url'      => $home,
		'logo'     => ryugaku_og_image(),
		'address'  => array( '@type' => 'PostalAddress', 'streetAddress' => ryugaku_option( 'company_address', '' ), 'addressCountry' => 'JP' ),
	);
	$graph[] = array(
		'@type'           => 'WebSite',
		'@id'             => $home . '#website',
		'url'             => $home,
		'name'            => get_bloginfo( 'name' ),
		'publisher'       => array( '@id' => $home . '#organization' ),
		'potentialAction' => array(
			'@type'       => 'SearchAction',
			'target'      => $home . '?s={search_term_string}',
			'query-input' => 'required name=search_term_string',
		),
	);

	$crumbs = ryugaku_breadcrumb_items();
	if ( count( $crumbs ) > 1 ) {
		$list = array();
		foreach ( $crumbs as $i => $crumb ) {
			$item = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $crumb[0] );
			if ( $crumb[1] ) {
				$item['item'] = $crumb[1];
			}
			$list[] = $item;
		}
		$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => $list );
	}

	if ( is_singular( 'post' ) ) {
		$graph[] = array(
			'@type'            => 'Article',
			'headline'         => get_the_title(),
			'datePublished'    => get_the_date( 'c' ),
			'dateModified'     => get_the_modified_date( 'c' ),
			'author'           => array( '@type' => 'Organization', 'name' => $name ),
			'publisher'        => array( '@id' => $home . '#organization' ),
			'image'            => ryugaku_og_image(),
			'mainEntityOfPage' => get_permalink(),
			'description'      => ryugaku_meta_description(),
		);
	}

	$faq_pairs = array();
	if ( is_singular( array( 'country', 'purpose' ) ) ) {
		$faq_pairs = ryugaku_meta_pairs( 'faq' );
	} elseif ( is_page_template( 'page-templates/faq.php' ) ) {
		foreach ( ryugaku_faq_groups() as $group ) {
			foreach ( $group['items'] as $item ) {
				$faq_pairs[] = array( $item->post_title, wp_strip_all_tags( $item->post_content ) );
			}
		}
	}
	if ( $faq_pairs ) {
		$entities = array();
		foreach ( $faq_pairs as $pair ) {
			$entities[] = array(
				'@type'          => 'Question',
				'name'           => $pair[0],
				'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $pair[1] ),
			);
		}
		$graph[] = array( '@type' => 'FAQPage', 'mainEntity' => $entities );
	}

	if ( is_singular( 'school' ) ) {
		$country = ryugaku_school_country();
		$graph[] = array(
			'@type'   => 'EducationalOrganization',
			'name'    => get_the_title(),
			'url'     => get_permalink(),
			'address' => array(
				'@type'           => 'PostalAddress',
				'addressLocality' => ryugaku_meta( 'school_city' ),
				'addressCountry'  => $country ? ryugaku_meta( 'country_code', '', $country->ID ) : '',
				'streetAddress'   => ryugaku_meta( 'school_address' ),
			),
		);
	}

	printf(
		'<script type="application/ld+json">%s</script>' . "\n",
		wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES )
	);
}
add_action( 'wp_head', 'ryugaku_json_ld', 3 );

/**
 * Add CPTs to the core sitemap and hide noindex posts.
 */
add_filter( 'wp_sitemaps_post_types', function ( $types ) {
	unset( $types['attachment'] );
	return $types;
} );

add_filter( 'wp_sitemaps_posts_query_args', function ( $args ) {
	$args['meta_query'] = array( array( 'key' => '_ryugaku_seo_noindex', 'compare' => 'NOT EXISTS' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	return $args;
} );

/**
 * Google Tag Manager (optional).
 */
function ryugaku_gtm_head() {
	$id = ryugaku_option( 'gtm_id', '' );
	if ( ! $id ) {
		return;
	}
	printf( "<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','%s');</script>\n", esc_js( $id ) );
}
add_action( 'wp_head', 'ryugaku_gtm_head', 4 );
