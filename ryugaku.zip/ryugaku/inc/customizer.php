<?php
/**
 * 外観 > カスタマイズ から変えられるサイト全体の設定(LINE URL・電話・キャッチコピー・会社情報・OGP 画像)。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register settings.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 */
function ryugaku_customize_register( $wp_customize ) {
	$wp_customize->add_panel( 'ryugaku_panel', array( 'title' => '留学サイト設定', 'priority' => 10 ) );

	$sections = array(
		'ryugaku_cta'     => array(
			'title'  => 'CTA・連絡先',
			'fields' => array(
				'line_url'        => array( 'label' => 'LINE相談URL', 'type' => 'url', 'default' => 'https://lin.ee/' ),
				'counseling_url'  => array( 'label' => '無料カウンセリング予約URL（空欄でお問い合わせページ）', 'type' => 'url', 'default' => '' ),
				'phone'           => array( 'label' => '電話番号', 'type' => 'text', 'default' => '' ),
				'business_hours'  => array( 'label' => '受付時間', 'type' => 'text', 'default' => '平日 10:00〜19:00' ),
				'contact_email'   => array( 'label' => 'お問い合わせ通知先メール（空欄で管理者メール）', 'type' => 'email', 'default' => '' ),
			),
		),
		'ryugaku_hero'    => array(
			'title'  => 'トップページ',
			'fields' => array(
				'hero_title'    => array( 'label' => 'キャッチコピー', 'type' => 'text', 'default' => "あなたに合う留学が、\nきっと見つかる。" ),
				'hero_lead'     => array( 'label' => 'リード文', 'type' => 'textarea', 'default' => '手数料0円・無理な営業なし。留学経験のあるカウンセラーが、国選びから出発後まで伴走します。' ),
				'hero_image'    => array( 'label' => 'ファーストビュー画像', 'type' => 'image', 'default' => '' ),
				'stat_1'        => array( 'label' => '実績1（例：累計サポート|3,200名）', 'type' => 'text', 'default' => '累計サポート|3,200名' ),
				'stat_2'        => array( 'label' => '実績2', 'type' => 'text', 'default' => '提携校|450校' ),
				'stat_3'        => array( 'label' => '実績3', 'type' => 'text', 'default' => '満足度|98.2%' ),
				'stat_4'        => array( 'label' => '実績4', 'type' => 'text', 'default' => '対応国|12ヶ国' ),
			),
		),
		'ryugaku_company' => array(
			'title'  => '会社情報',
			'fields' => array(
				'company_name'    => array( 'label' => '会社名', 'type' => 'text', 'default' => '株式会社リュウガクエージェント' ),
				'company_address' => array( 'label' => '所在地', 'type' => 'text', 'default' => '東京都渋谷区渋谷1-1-1' ),
				'company_ceo'     => array( 'label' => '代表者', 'type' => 'text', 'default' => '' ),
				'company_founded' => array( 'label' => '設立', 'type' => 'text', 'default' => '' ),
				'company_license' => array( 'label' => '登録・認可', 'type' => 'text', 'default' => '' ),
				'ogp_image'       => array( 'label' => 'OGP画像（1200×630推奨）', 'type' => 'image', 'default' => '' ),
				'gtm_id'          => array( 'label' => 'Google Tag Manager ID（任意）', 'type' => 'text', 'default' => '' ),
			),
		),
	);

	foreach ( $sections as $section_id => $section ) {
		$wp_customize->add_section( $section_id, array( 'title' => $section['title'], 'panel' => 'ryugaku_panel' ) );
		foreach ( $section['fields'] as $key => $field ) {
			$setting = 'ryugaku_' . $key;
			$sanitize = 'sanitize_text_field';
			if ( 'url' === $field['type'] ) {
				$sanitize = 'esc_url_raw';
			} elseif ( 'textarea' === $field['type'] ) {
				$sanitize = 'sanitize_textarea_field';
			} elseif ( 'email' === $field['type'] ) {
				$sanitize = 'sanitize_email';
			}
			$defaults = ryugaku_option_defaults();
			$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : $field['default'];
			$wp_customize->add_setting( $setting, array( 'default' => $default, 'sanitize_callback' => $sanitize ) );
			if ( 'image' === $field['type'] ) {
				$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $setting, array( 'label' => $field['label'], 'section' => $section_id ) ) );
			} else {
				$wp_customize->add_control( $setting, array( 'label' => $field['label'], 'section' => $section_id, 'type' => $field['type'] ) );
			}
		}
	}
}
add_action( 'customize_register', 'ryugaku_customize_register' );
