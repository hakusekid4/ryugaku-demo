<?php
/**
 * 管理画面の入力欄(メタボックス)。国・学校・留学タイプ・体験談の項目と SEO 設定を定義し、保存時に無害化する。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Field definitions per post type.
 *
 * @return array<string, array<string, mixed>>
 */
function ryugaku_field_groups() {
	return array(
		'country' => array(
			'title'  => '国の情報',
			'fields' => array(
				'country_code' => array( 'label' => '国コード（2文字）', 'type' => 'text', 'desc' => '例：PH、AU、CA。国旗の自動表示に使用します。' ),
				'flag'         => array( 'label' => '国旗（絵文字・任意）', 'type' => 'text' ),
				'catch'        => array( 'label' => 'キャッチコピー', 'type' => 'text', 'desc' => '一覧カードや診断結果に表示されます。' ),
				'popularity'   => array( 'label' => '人気度（数値が大きいほど上位）', 'type' => 'number' ),
				'cost_month'   => array( 'label' => '1ヶ月の費用目安（万円）', 'type' => 'number', 'step' => '0.1' ),
				'cost_3month'  => array( 'label' => '3ヶ月の費用目安（万円）', 'type' => 'number', 'step' => '0.1' ),
				'cost_6month'  => array( 'label' => '6ヶ月の費用目安（万円）', 'type' => 'number', 'step' => '0.1' ),
				'cost_year'    => array( 'label' => '1年の費用目安（万円）', 'type' => 'number', 'step' => '0.1' ),
				'cost_breakdown' => array( 'label' => '費用の内訳（1行に「項目|金額」）', 'type' => 'textarea', 'desc' => '例：授業料（4週）|15万円' ),
				'features'     => array( 'label' => '国の特徴（1行に1項目）', 'type' => 'textarea' ),
				'recommended'  => array( 'label' => 'こんな人におすすめ（1行に1項目）', 'type' => 'textarea' ),
				'merits'       => array( 'label' => 'メリット（1行に1項目）', 'type' => 'textarea' ),
				'demerits'     => array( 'label' => 'デメリット（1行に1項目）', 'type' => 'textarea' ),
				'cities'       => array( 'label' => '人気都市（1行に「都市名|説明」）', 'type' => 'textarea' ),
				'faq'          => array( 'label' => 'よくある質問（1行に「質問|回答」）', 'type' => 'textarea' ),
				'language'     => array( 'label' => '公用語', 'type' => 'text' ),
				'visa'         => array( 'label' => 'ビザ', 'type' => 'text' ),
				'flight_hours' => array( 'label' => '日本からのフライト時間（時間）', 'type' => 'number', 'step' => '0.5' ),
				'timezone'     => array( 'label' => '時差', 'type' => 'text' ),
				'currency'     => array( 'label' => '通貨', 'type' => 'text' ),
				'season'       => array( 'label' => 'ベストシーズン', 'type' => 'text' ),
				'climate'      => array( 'label' => '気候タイプ（診断用）', 'type' => 'select', 'options' => array( 'warm' => '温暖・常夏', 'mild' => '四季あり・穏やか', 'cold' => '冷涼' ) ),
			),
		),
		'school'  => array(
			'title'  => '学校の情報',
			'fields' => array(
				'school_country'        => array( 'label' => '国', 'type' => 'post', 'post_type' => 'country' ),
				'school_city'           => array( 'label' => '都市', 'type' => 'text' ),
				'school_cost_4w'        => array( 'label' => '4週間の費用目安（万円）', 'type' => 'number', 'step' => '0.1', 'desc' => '授業料＋滞在費の合計目安。費用順の並び替えに使用します。' ),
				'school_min_weeks'      => array( 'label' => '最短受講期間（週）', 'type' => 'number' ),
				'school_capacity'       => array( 'label' => '定員（人）', 'type' => 'number' ),
				'school_japanese_ratio' => array( 'label' => '日本人比率', 'type' => 'text' ),
				'school_founded'        => array( 'label' => '設立年', 'type' => 'text' ),
				'school_rating'         => array( 'label' => '総合評価（0〜5）', 'type' => 'number', 'step' => '0.1' ),
				'school_features'       => array( 'label' => '特徴（1行に1項目）', 'type' => 'textarea' ),
				'school_courses'        => array( 'label' => 'コース（1行に「コース名|説明」）', 'type' => 'textarea' ),
				'school_accommodation'  => array( 'label' => '滞在方法（1行に「種類|説明」）', 'type' => 'textarea' ),
				'school_recommended'    => array( 'label' => 'こんな人におすすめ（1行に1項目）', 'type' => 'textarea' ),
				'school_address'        => array( 'label' => '住所', 'type' => 'text' ),
				'school_website'        => array( 'label' => '公式サイトURL', 'type' => 'url' ),
			),
		),
		'purpose' => array(
			'title'  => '留学タイプの情報',
			'fields' => array(
				'icon'      => array( 'label' => 'アイコン（絵文字）', 'type' => 'text' ),
				'catch'     => array( 'label' => 'キャッチコピー', 'type' => 'text' ),
				'type_slug' => array( 'label' => '対応する留学タイプ分類のスラッグ', 'type' => 'text', 'desc' => '例：language、working-holiday。国・学校の絞り込みに使用します。' ),
				'overview'  => array( 'label' => '概要', 'type' => 'textarea' ),
				'merits'    => array( 'label' => 'メリット（1行に「見出し|説明」）', 'type' => 'textarea' ),
				'suited'    => array( 'label' => '向いている人（1行に1項目）', 'type' => 'textarea' ),
				'cost'      => array( 'label' => '費用目安（1行に「項目|金額」）', 'type' => 'textarea' ),
				'period'    => array( 'label' => '期間の目安（1行に「期間|説明」）', 'type' => 'textarea' ),
				'faq'       => array( 'label' => 'FAQ（1行に「質問|回答」）', 'type' => 'textarea' ),
			),
		),
		'voice'   => array(
			'title'  => '体験談の情報',
			'fields' => array(
				'voice_name'       => array( 'label' => 'お名前（ニックネーム可）', 'type' => 'text' ),
				'voice_age'        => array( 'label' => '年齢・属性', 'type' => 'text', 'desc' => '例：22歳・大学生' ),
				'voice_country'    => array( 'label' => '留学先の国', 'type' => 'post', 'post_type' => 'country' ),
				'voice_school'     => array( 'label' => '留学先の学校', 'type' => 'post', 'post_type' => 'school' ),
				'voice_period'     => array( 'label' => '留学期間', 'type' => 'text' ),
				'voice_type'       => array( 'label' => '留学タイプ', 'type' => 'text' ),
				'voice_before'     => array( 'label' => '留学前の悩み', 'type' => 'textarea' ),
				'voice_after'      => array( 'label' => '留学後の変化', 'type' => 'textarea' ),
				'voice_parent'     => array( 'label' => '保護者の声', 'type' => 'textarea' ),
				'voice_career'     => array( 'label' => '卒業後のキャリア', 'type' => 'textarea' ),
				'voice_photos'     => array( 'label' => '写真（メディアIDをカンマ区切り）', 'type' => 'media' ),
				'voice_featured'   => array( 'label' => 'トップページに表示', 'type' => 'checkbox' ),
			),
		),
	);
}

/**
 * SEO fields for all public types.
 *
 * @return string[]
 */
function ryugaku_seo_post_types() {
	return array( 'post', 'page', 'country', 'school', 'purpose', 'voice' );
}

/**
 * Register meta boxes.
 */
function ryugaku_add_meta_boxes() {
	foreach ( ryugaku_field_groups() as $post_type => $group ) {
		add_meta_box( 'ryugaku_' . $post_type, $group['title'], 'ryugaku_render_meta_box', $post_type, 'normal', 'high', array( 'post_type' => $post_type ) );
	}
	foreach ( ryugaku_seo_post_types() as $post_type ) {
		add_meta_box( 'ryugaku_seo', 'SEO設定', 'ryugaku_render_seo_box', $post_type, 'normal', 'default' );
	}
}
add_action( 'add_meta_boxes', 'ryugaku_add_meta_boxes' );

/**
 * Render a field.
 *
 * @param string $key   Key.
 * @param array  $field Field definition.
 * @param mixed  $value Current value.
 */
function ryugaku_render_field( $key, $field, $value ) {
	$id   = 'ryugaku_' . $key;
	$name = 'ryugaku[' . $key . ']';
	echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';
	switch ( $field['type'] ) {
		case 'textarea':
			printf( '<textarea id="%s" name="%s" rows="5" class="large-text">%s</textarea>', esc_attr( $id ), esc_attr( $name ), esc_textarea( $value ) );
			break;
		case 'number':
			printf( '<input type="number" id="%s" name="%s" value="%s" step="%s" class="regular-text">', esc_attr( $id ), esc_attr( $name ), esc_attr( $value ), esc_attr( isset( $field['step'] ) ? $field['step'] : '1' ) );
			break;
		case 'select':
			printf( '<select id="%s" name="%s">', esc_attr( $id ), esc_attr( $name ) );
			foreach ( $field['options'] as $opt_value => $opt_label ) {
				printf( '<option value="%s"%s>%s</option>', esc_attr( $opt_value ), selected( $value, $opt_value, false ), esc_html( $opt_label ) );
			}
			echo '</select>';
			break;
		case 'post':
			$posts = get_posts( array( 'post_type' => $field['post_type'], 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'any' ) );
			printf( '<select id="%s" name="%s"><option value="">— 選択 —</option>', esc_attr( $id ), esc_attr( $name ) );
			foreach ( $posts as $p ) {
				printf( '<option value="%d"%s>%s</option>', $p->ID, selected( (int) $value, $p->ID, false ), esc_html( $p->post_title ) );
			}
			echo '</select>';
			break;
		case 'checkbox':
			printf( '<label><input type="checkbox" id="%s" name="%s" value="1"%s> 有効にする</label>', esc_attr( $id ), esc_attr( $name ), checked( $value, '1', false ) );
			break;
		case 'media':
			printf( '<input type="text" id="%s" name="%s" value="%s" class="regular-text ryugaku-media-ids"> <button type="button" class="button ryugaku-media-btn" data-target="%s">メディアから選択</button>', esc_attr( $id ), esc_attr( $name ), esc_attr( $value ), esc_attr( $id ) );
			break;
		case 'url':
			printf( '<input type="url" id="%s" name="%s" value="%s" class="large-text">', esc_attr( $id ), esc_attr( $name ), esc_attr( $value ) );
			break;
		default:
			printf( '<input type="text" id="%s" name="%s" value="%s" class="large-text">', esc_attr( $id ), esc_attr( $name ), esc_attr( $value ) );
	}
	if ( ! empty( $field['desc'] ) ) {
		printf( '<p class="description">%s</p>', esc_html( $field['desc'] ) );
	}
	echo '</td></tr>';
}

/**
 * Render meta box.
 *
 * @param WP_Post $post Post.
 * @param array   $box  Box args.
 */
function ryugaku_render_meta_box( $post, $box ) {
	$groups = ryugaku_field_groups();
	$group  = $groups[ $box['args']['post_type'] ];
	wp_nonce_field( 'ryugaku_save_meta', 'ryugaku_meta_nonce' );
	echo '<table class="form-table ryugaku-fields">';
	foreach ( $group['fields'] as $key => $field ) {
		ryugaku_render_field( $key, $field, get_post_meta( $post->ID, '_ryugaku_' . $key, true ) );
	}
	echo '</table>';
}

/**
 * Render SEO box.
 *
 * @param WP_Post $post Post.
 */
function ryugaku_render_seo_box( $post ) {
	wp_nonce_field( 'ryugaku_save_meta', 'ryugaku_meta_nonce' );
	echo '<table class="form-table ryugaku-fields">';
	ryugaku_render_field( 'seo_title', array( 'label' => 'SEOタイトル', 'type' => 'text', 'desc' => '空欄の場合は投稿タイトル＋サイト名が使われます。32文字前後推奨。' ), get_post_meta( $post->ID, '_ryugaku_seo_title', true ) );
	ryugaku_render_field( 'seo_description', array( 'label' => 'メタディスクリプション', 'type' => 'textarea', 'desc' => '空欄の場合は抜粋または本文冒頭が使われます。120文字前後推奨。' ), get_post_meta( $post->ID, '_ryugaku_seo_description', true ) );
	ryugaku_render_field( 'seo_noindex', array( 'label' => '検索エンジンに表示しない（noindex）', 'type' => 'checkbox' ), get_post_meta( $post->ID, '_ryugaku_seo_noindex', true ) );
	echo '</table>';
}

/**
 * Save meta.
 *
 * @param int $post_id Post ID.
 */
function ryugaku_save_meta( $post_id ) {
	if ( ! isset( $_POST['ryugaku_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ryugaku_meta_nonce'] ) ), 'ryugaku_save_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$input     = isset( $_POST['ryugaku'] ) && is_array( $_POST['ryugaku'] ) ? wp_unslash( $_POST['ryugaku'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$post_type = get_post_type( $post_id );
	$groups    = ryugaku_field_groups();
	$fields    = isset( $groups[ $post_type ] ) ? $groups[ $post_type ]['fields'] : array();

	if ( in_array( $post_type, ryugaku_seo_post_types(), true ) ) {
		$fields['seo_title']       = array( 'type' => 'text' );
		$fields['seo_description'] = array( 'type' => 'textarea' );
		$fields['seo_noindex']     = array( 'type' => 'checkbox' );
	}

	foreach ( $fields as $key => $field ) {
		$raw = isset( $input[ $key ] ) ? $input[ $key ] : '';
		switch ( $field['type'] ) {
			case 'textarea':
				$value = sanitize_textarea_field( $raw );
				break;
			case 'number':
				$value = '' === $raw ? '' : (string) (float) $raw;
				break;
			case 'post':
				$value = (int) $raw;
				break;
			case 'checkbox':
				$value = $raw ? '1' : '';
				break;
			case 'url':
				$value = esc_url_raw( $raw );
				break;
			case 'media':
				$ids   = array_filter( array_map( 'absint', explode( ',', (string) $raw ) ) );
				$value = implode( ',', $ids );
				break;
			default:
				$value = sanitize_text_field( $raw );
		}
		if ( '' === $value || 0 === $value ) {
			delete_post_meta( $post_id, '_ryugaku_' . $key );
		} else {
			update_post_meta( $post_id, '_ryugaku_' . $key, $value );
		}
	}
}
add_action( 'save_post', 'ryugaku_save_meta' );

/**
 * Register meta for REST (block editor compatibility).
 */
function ryugaku_register_meta() {
	foreach ( ryugaku_field_groups() as $post_type => $group ) {
		foreach ( $group['fields'] as $key => $field ) {
			register_post_meta(
				$post_type,
				'_ryugaku_' . $key,
				array(
					'show_in_rest'  => false,
					'single'        => true,
					'type'          => in_array( $field['type'], array( 'number', 'post' ), true ) ? 'number' : 'string',
					'auth_callback' => function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}
}
add_action( 'init', 'ryugaku_register_meta' );
