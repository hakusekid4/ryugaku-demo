<?php
/**
 * カスタム投稿タイプ(国・学校・留学タイプ・体験談・FAQ・問い合わせ)と分類(エリア・留学タイプ・FAQ カテゴリ)の登録。
 *
 * @package Ryugaku
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register CPTs.
 */
function ryugaku_register_post_types() {
	$types = array(
		'country' => array(
			'labels'    => array( 'name' => '国', 'singular_name' => '国', 'add_new_item' => '国を追加', 'edit_item' => '国を編集', 'all_items' => '国一覧' ),
			'rewrite'   => array( 'slug' => 'countries', 'with_front' => false ),
			'menu_icon' => 'dashicons-admin-site-alt3',
			'supports'  => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'revisions' ),
			'position'  => 20,
		),
		'school'  => array(
			'labels'    => array( 'name' => '学校', 'singular_name' => '学校', 'add_new_item' => '学校を追加', 'edit_item' => '学校を編集', 'all_items' => '学校一覧' ),
			'rewrite'   => array( 'slug' => 'schools', 'with_front' => false ),
			'menu_icon' => 'dashicons-welcome-learn-more',
			'supports'  => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'revisions' ),
			'position'  => 21,
		),
		'purpose' => array(
			'labels'    => array( 'name' => '留学タイプ', 'singular_name' => '留学タイプ', 'add_new_item' => '留学タイプを追加', 'edit_item' => '留学タイプを編集', 'all_items' => '留学タイプ一覧' ),
			'rewrite'   => array( 'slug' => 'types', 'with_front' => false ),
			'menu_icon' => 'dashicons-flag',
			'supports'  => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'revisions' ),
			'position'  => 22,
		),
		'voice'   => array(
			'labels'    => array( 'name' => '体験談', 'singular_name' => '体験談', 'add_new_item' => '体験談を追加', 'edit_item' => '体験談を編集', 'all_items' => '体験談一覧' ),
			'rewrite'   => array( 'slug' => 'voices', 'with_front' => false ),
			'menu_icon' => 'dashicons-format-quote',
			'supports'  => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ),
			'position'  => 23,
		),
		'faq'     => array(
			'labels'    => array( 'name' => 'FAQ', 'singular_name' => 'FAQ', 'add_new_item' => 'FAQを追加', 'edit_item' => 'FAQを編集', 'all_items' => 'FAQ一覧' ),
			'rewrite'   => false,
			'menu_icon' => 'dashicons-editor-help',
			'supports'  => array( 'title', 'editor', 'page-attributes' ),
			'position'  => 24,
			'public'    => false,
		),
	);

	foreach ( $types as $slug => $args ) {
		$public = ! isset( $args['public'] ) || $args['public'];
		register_post_type(
			$slug,
			array(
				'labels'              => $args['labels'],
				'public'              => $public,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => true,
				'has_archive'         => $public,
				'rewrite'             => $args['rewrite'],
				'menu_icon'           => $args['menu_icon'],
				'menu_position'       => $args['position'],
				'supports'            => $args['supports'],
				'exclude_from_search' => ! $public,
				'publicly_queryable'  => $public,
				// ?country=17 のような絞り込みパラメータと投稿タイプ名が衝突しないよう、クエリ変数は登録しない
				'query_var'           => false,
			)
		);
	}

	register_post_type(
		'inquiry',
		array(
			'labels'          => array( 'name' => 'お問い合わせ', 'singular_name' => 'お問い合わせ', 'all_items' => '受信一覧' ),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'menu_icon'       => 'dashicons-email-alt',
			'menu_position'   => 25,
			'supports'        => array( 'title', 'editor' ),
			'capability_type' => 'post',
			'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'    => true,
		)
	);
}
add_action( 'init', 'ryugaku_register_post_types' );

/**
 * Register taxonomies.
 */
function ryugaku_register_taxonomies() {
	register_taxonomy(
		'region',
		array( 'country' ),
		array(
			'labels'            => array( 'name' => 'エリア', 'singular_name' => 'エリア', 'add_new_item' => 'エリアを追加' ),
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'region', 'with_front' => false ),
		)
	);

	register_taxonomy(
		'study_type',
		array( 'country', 'school', 'voice' ),
		array(
			'labels'            => array( 'name' => '留学タイプ（分類）', 'singular_name' => '留学タイプ', 'add_new_item' => '留学タイプを追加' ),
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'study-type', 'with_front' => false ),
		)
	);

	register_taxonomy(
		'faq_category',
		array( 'faq' ),
		array(
			'labels'            => array( 'name' => 'FAQカテゴリ', 'singular_name' => 'FAQカテゴリ', 'add_new_item' => 'FAQカテゴリを追加' ),
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => false,
			'public'            => false,
		)
	);
}
add_action( 'init', 'ryugaku_register_taxonomies' );

/**
 * Flush rewrite rules on theme switch.
 */
function ryugaku_flush_rewrites() {
	ryugaku_register_post_types();
	ryugaku_register_taxonomies();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'ryugaku_flush_rewrites' );
