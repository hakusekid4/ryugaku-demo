<?php
/**
 * 国から探す(国一覧)。検索・留学タイプ絞り込み・エリア・並び替え(人気順/費用順/名前順)。
 *
 * @package Ryugaku
 */

get_header();
$ryugaku_keyword = ryugaku_current_keyword();
$ryugaku_type    = ryugaku_current_filter( 'type' );
$ryugaku_regions = get_terms( array( 'taxonomy' => 'region', 'hide_empty' => true ) );
$ryugaku_types   = get_terms( array( 'taxonomy' => 'study_type', 'hide_empty' => true ) );
$ryugaku_title   = is_tax( 'region' ) ? single_term_title( '', false ) . 'の留学先' : '国から探す';
?>
<?php ryugaku_page_hero( $ryugaku_title, '人気順・費用順で比較して、あなたに合う留学先を見つけましょう。', 'COUNTRIES' ); ?>

<section class="section section--flush">
	<div class="container">
		<form class="filter-form" method="get" action="<?php echo esc_url( get_post_type_archive_link( 'country' ) ); ?>" role="search">
			<label class="filter-form__search">
				<span class="screen-reader-text">国名・キーワードで検索</span>
				<?php echo ryugaku_icon( 'search' ); ?>
				<input type="search" name="q" value="<?php echo esc_attr( $ryugaku_keyword ); ?>" placeholder="国名・都市名・キーワード（例：セブ、ワーホリ）">
			</label>
			<?php if ( $ryugaku_types && ! is_wp_error( $ryugaku_types ) ) : ?>
				<label class="filter-form__select">
					<span class="screen-reader-text">留学タイプ</span>
					<select name="type">
						<option value="">留学タイプ：すべて</option>
						<?php foreach ( $ryugaku_types as $ryugaku_t ) : ?>
							<option value="<?php echo esc_attr( $ryugaku_t->slug ); ?>" <?php selected( $ryugaku_type, $ryugaku_t->slug ); ?>><?php echo esc_html( $ryugaku_t->name ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
			<?php endif; ?>
			<input type="hidden" name="sort" value="<?php echo esc_attr( ryugaku_current_sort() ); ?>">
			<button class="btn btn--primary" type="submit">検索</button>
		</form>

		<?php if ( $ryugaku_regions && ! is_wp_error( $ryugaku_regions ) ) : ?>
			<ul class="chip-list" aria-label="エリアで絞り込む">
				<li><a class="chip <?php echo is_tax( 'region' ) ? '' : 'is-active'; ?>" href="<?php echo esc_url( get_post_type_archive_link( 'country' ) ); ?>">すべて</a></li>
				<?php foreach ( $ryugaku_regions as $ryugaku_region ) : ?>
					<li><a class="chip <?php echo is_tax( 'region', $ryugaku_region->slug ) ? 'is-active' : ''; ?>" href="<?php echo esc_url( get_term_link( $ryugaku_region ) ); ?>"><?php echo esc_html( $ryugaku_region->name ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<?php get_template_part( 'template-parts/sort-bar', null, array( 'options' => array( 'popular' => '人気順', 'cost' => '費用が安い順', 'cost_desc' => '費用が高い順', 'name' => '名前順' ) ) ); ?>

		<?php if ( have_posts() ) : ?>
			<div class="grid grid--3" data-country-grid>
				<?php
				$ryugaku_rank = ( max( 1, (int) get_query_var( 'paged' ) ) - 1 ) * (int) get_query_var( 'posts_per_page' );
				while ( have_posts() ) :
					the_post();
					$ryugaku_rank++;
					get_template_part( 'template-parts/card', 'country', array( 'rank' => 'popular' === ryugaku_current_sort() ? $ryugaku_rank : 0 ) );
				endwhile;
				?>
			</div>
			<?php get_template_part( 'template-parts/pagination' ); ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/no-results' ); ?>
		<?php endif; ?>
	</div>
</section>

<section class="section section--tint">
	<div class="container">
		<?php ryugaku_section_title( '国選びに迷ったら', 'HOW TO CHOOSE' ); ?>
		<div class="grid grid--3">
			<div class="info-card">
				<h3>費用で選ぶ</h3>
				<p>フィリピンやマルタは費用を抑えやすく、欧米圏は生活費が高め。1ヶ月あたりの総額で比較するのがコツです。</p>
			</div>
			<div class="info-card">
				<h3>目的で選ぶ</h3>
				<p>短期集中で英語力を上げたいならマンツーマン中心のフィリピン、働きたいならワーホリ協定国、進学・就職ならカナダ・アメリカ。</p>
			</div>
			<div class="info-card">
				<h3>環境で選ぶ</h3>
				<p>気候・治安・日本人比率・都市の規模など、住みやすさは意外と重要。診断やカウンセリングで整理しましょう。</p>
			</div>
		</div>
		<p class="section__more"><a class="btn btn--ghost" href="<?php echo esc_url( home_url( '/#diagnosis' ) ); ?>">おすすめの国を診断する<?php echo ryugaku_icon( 'arrow' ); ?></a></p>
	</div>
</section>
<?php get_footer(); ?>
