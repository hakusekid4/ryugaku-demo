<?php
/**
 * コラム一覧・カテゴリ一覧・検索結果の共通テンプレート。
 *
 * @package Ryugaku
 */

get_header();
$ryugaku_title = is_home() ? '留学コラム' : get_the_archive_title();
$ryugaku_lead  = is_home() ? '留学費用・国比較・英語学習・特集・体験談。留学準備に役立つ情報をお届けします。' : wp_strip_all_tags( get_the_archive_description() );
if ( is_search() ) {
	$ryugaku_title = '「' . get_search_query() . '」の検索結果';
	$ryugaku_lead  = '';
}
if ( is_category() ) {
	$ryugaku_title = single_cat_title( '', false );
}
?>
<?php ryugaku_page_hero( $ryugaku_title, $ryugaku_lead, is_search() ? 'SEARCH' : 'COLUMN' ); ?>

<section class="section">
	<div class="container column-layout">
		<div class="column-layout__main">
			<?php if ( is_home() || is_category() ) : ?>
				<?php
				$ryugaku_cats = get_categories( array( 'hide_empty' => true ) );
				if ( $ryugaku_cats ) :
					?>
					<ul class="chip-list">
						<li><a class="chip <?php echo is_home() ? 'is-active' : ''; ?>" href="<?php echo esc_url( ryugaku_column_url() ); ?>">すべて</a></li>
						<?php foreach ( $ryugaku_cats as $ryugaku_cat ) : ?>
							<li><a class="chip <?php echo is_category( $ryugaku_cat->term_id ) ? 'is-active' : ''; ?>" href="<?php echo esc_url( get_category_link( $ryugaku_cat ) ); ?>"><?php echo esc_html( $ryugaku_cat->name ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			<?php endif; ?>

			<?php if ( have_posts() ) : ?>
				<div class="grid grid--2">
					<?php
					while ( have_posts() ) :
						the_post();
						if ( 'post' === get_post_type() ) {
							get_template_part( 'template-parts/card', 'post' );
						} elseif ( 'country' === get_post_type() ) {
							get_template_part( 'template-parts/card', 'country' );
						} elseif ( 'school' === get_post_type() ) {
							get_template_part( 'template-parts/card', 'school' );
						} elseif ( 'voice' === get_post_type() ) {
							get_template_part( 'template-parts/card', 'voice' );
						} else {
							?>
							<article class="card card--post">
								<a class="card__link" href="<?php the_permalink(); ?>">
									<div class="card__body">
										<h3 class="card__title"><?php the_title(); ?></h3>
										<p class="card__catch"><?php echo esc_html( ryugaku_excerpt( 45 ) ); ?></p>
									</div>
								</a>
							</article>
							<?php
						}
					endwhile;
					?>
				</div>
				<?php get_template_part( 'template-parts/pagination' ); ?>
			<?php else : ?>
				<?php get_template_part( 'template-parts/no-results' ); ?>
			<?php endif; ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</section>
<?php get_footer(); ?>
