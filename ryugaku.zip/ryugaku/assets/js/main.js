/**
 * Ryugaku Agent theme scripts (no dependencies).
 */
(function () {
	'use strict';

	var data = window.ryugakuData || { countries: [] };

	/* ---------- Mobile navigation ---------- */
	var toggle = document.querySelector('.nav-toggle');
	var nav = document.getElementById('site-nav');
	if (toggle && nav) {
		var closeNav = function () {
			document.body.classList.remove('nav-open');
			toggle.setAttribute('aria-expanded', 'false');
			toggle.setAttribute('aria-label', 'メニューを開く');
		};
		toggle.addEventListener('click', function () {
			var open = document.body.classList.toggle('nav-open');
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			toggle.setAttribute('aria-label', open ? 'メニューを閉じる' : 'メニューを開く');
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') { closeNav(); }
		});
		nav.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', closeNav); });
		window.addEventListener('resize', function () {
			if (window.innerWidth > 1024) { closeNav(); }
		});
	}

	/* ---------- Sticky header shadow ---------- */
	var header = document.getElementById('site-header');
	if (header) {
		var onScroll = function () {
			header.classList.toggle('is-scrolled', window.scrollY > 8);
		};
		onScroll();
		window.addEventListener('scroll', onScroll, { passive: true });
	}

	/* ---------- Mobile CTA visibility (hide when the footer CTA is in view) ---------- */
	var mobileCta = document.querySelector('.mobile-cta');
	var ctaBand = document.getElementById('cta');
	if (mobileCta && ctaBand && 'IntersectionObserver' in window) {
		new IntersectionObserver(function (entries) {
			mobileCta.classList.toggle('is-hidden', entries[0].isIntersecting);
		}, { threshold: 0.2 }).observe(ctaBand);
	}

	/* ---------- FAQ: close others in the same list (accordion) ---------- */
	document.querySelectorAll('.faq-list').forEach(function (list) {
		list.addEventListener('toggle', function (e) {
			if (!e.target.open) { return; }
			list.querySelectorAll('details[open]').forEach(function (d) {
				if (d !== e.target) { d.removeAttribute('open'); }
			});
		}, true);
	});

	/* ---------- Auto-submit filters on select change ---------- */
	document.querySelectorAll('.filter-form select').forEach(function (select) {
		select.addEventListener('change', function () {
			select.form.requestSubmit ? select.form.requestSubmit() : select.form.submit();
		});
	});

	/* ---------- Reveal animation ---------- */
	if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
		var targets = document.querySelectorAll('.card, .reason, .info-card, .type-card, .counseling-card, .flow-step, .support-item, .plan-card');
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (entry.isIntersecting) {
					entry.target.classList.add('is-visible');
					io.unobserve(entry.target);
				}
			});
		}, { rootMargin: '0px 0px -8% 0px' });
		targets.forEach(function (el) {
			el.classList.add('reveal');
			io.observe(el);
		});
	}

	/* ---------- Country diagnosis ---------- */
	var diag = document.querySelector('[data-diagnosis]');
	if (diag) {
		var steps = Array.prototype.slice.call(diag.querySelectorAll('.diagnosis__step'));
		var bar = diag.querySelector('[data-diagnosis-bar]');
		var result = diag.querySelector('[data-diagnosis-result]');
		var cardsWrap = diag.querySelector('[data-diagnosis-cards]');
		var answers = {};
		var current = 0;

		var setProgress = function (index) {
			if (bar) { bar.style.width = Math.round((index / steps.length) * 100) + '%'; }
		};

		var showStep = function (index) {
			steps.forEach(function (s, i) { s.classList.toggle('is-active', i === index); });
			current = index;
			setProgress(index);
		};

		var escapeHtml = function (str) {
			return String(str).replace(/[&<>"']/g, function (c) {
				return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
			});
		};

		var score = function (country) {
			var s = 0;
			var reasons = [];
			if (answers.purpose && country.types.indexOf(answers.purpose) !== -1) { s += 40; reasons.push('目的に合致'); }
			var budget = parseFloat(answers.budget);
			if (budget) {
				if (country.cost && country.cost <= budget) { s += 30; reasons.push('予算内'); }
				else if (country.cost && country.cost <= budget * 1.2) { s += 12; }
				else if (budget >= 999) { s += 15; }
			}
			if (answers.climate && answers.climate !== 'any') {
				if (country.climate === answers.climate) { s += 15; reasons.push('気候が好み'); }
			} else { s += 8; }
			if (answers.distance && answers.distance !== 'any') {
				var d = country.distance || 10;
				var ok = (answers.distance === 'near' && d <= 6) || (answers.distance === 'mid' && d <= 12) || answers.distance === 'far';
				if (ok) { s += 15; reasons.push('距離も◎'); }
			} else { s += 8; }
			s += Math.min(10, (country.popular || 0) / 10);
			return { score: s, reasons: reasons };
		};

		var render = function () {
			var ranked = data.countries.map(function (c) {
				var r = score(c);
				return { c: c, score: r.score, reasons: r.reasons };
			}).sort(function (a, b) { return b.score - a.score; }).slice(0, 3);

			if (!ranked.length) {
				cardsWrap.innerHTML = '<p>国データが登録されると診断結果が表示されます。</p>';
			} else {
				cardsWrap.innerHTML = ranked.map(function (item, i) {
					var c = item.c;
					return '<a class="diagnosis-card' + (i === 0 ? ' is-top' : '') + '" href="' + escapeHtml(c.url) + '">' +
						'<span class="diagnosis-card__rank">' + (i === 0 ? 'ベストマッチ' : 'おすすめ ' + (i + 1)) + '</span>' +
						'<span class="diagnosis-card__flag" aria-hidden="true">' + escapeHtml(c.flag) + '</span>' +
						'<span class="diagnosis-card__name">' + escapeHtml(c.name) + '</span>' +
						'<span class="diagnosis-card__catch">' + escapeHtml(c.catch || '') + '</span>' +
						'<span class="diagnosis-card__cost">1ヶ月 ' + escapeHtml(c.cost ? c.cost + '万円〜' : '—') + '</span>' +
						(item.reasons.length ? '<span class="diagnosis-card__reasons">' + item.reasons.map(function (r) { return '<em>' + escapeHtml(r) + '</em>'; }).join('') + '</span>' : '') +
						'<span class="diagnosis-card__more">詳しく見る →</span>' +
						'</a>';
				}).join('');
			}
			steps.forEach(function (s) { s.classList.remove('is-active'); });
			setProgress(steps.length);
			result.hidden = false;
			result.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
		};

		steps.forEach(function (step, index) {
			step.querySelectorAll('button').forEach(function (btn) {
				btn.addEventListener('click', function () {
					answers[step.dataset.step] = btn.dataset.value;
					step.querySelectorAll('button').forEach(function (b) { b.classList.toggle('is-selected', b === btn); });
					if (index < steps.length - 1) { showStep(index + 1); } else { render(); }
				});
			});
		});

		var reset = diag.querySelector('[data-diagnosis-reset]');
		if (reset) {
			reset.addEventListener('click', function () {
				answers = {};
				result.hidden = true;
				diag.querySelectorAll('button.is-selected').forEach(function (b) { b.classList.remove('is-selected'); });
				showStep(0);
				diag.scrollIntoView({ behavior: 'smooth', block: 'start' });
			});
		}
		showStep(0);
	}

	/* ---------- Smooth anchor scrolling with header offset ---------- */
	document.querySelectorAll('a[href^="#"]').forEach(function (a) {
		a.addEventListener('click', function (e) {
			var id = a.getAttribute('href').slice(1);
			if (!id) { return; }
			var target = document.getElementById(id);
			if (!target) { return; }
			e.preventDefault();
			var offset = (header ? header.offsetHeight : 0) + 12;
			var top = target.getBoundingClientRect().top + window.scrollY - offset;
			window.scrollTo({ top: top, behavior: 'smooth' });
			history.replaceState(null, '', '#' + id);
		});
	});
})();
