<?php
/**
 * 国詳細。特徴・おすすめの人・費用目安・人気都市・学校一覧・メリット/デメリット・FAQ・CTA。
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_id      = get_the_ID();
$ryugaku_schools = ryugaku_schools_for_country( $ryugaku_id, 6 );
$ryugaku_voices  = ryugaku_voices_for_country( $ryugaku_id, 3 );
$ryugaku_cities  = ryugaku_meta_pairs( 'cities' );
$ryugaku_faq     = ryugaku_meta_pairs( 'faq' );
$ryugaku_costs   = ryugaku_meta_pairs( 'cost_breakdown' );
?>
<article class="country">
	<section class="detail-hero">
		<div class="container detail-hero__inner">
			<div class="detail-hero__text">
				<p class="eyebrow"><?php echo esc_html( strtoupper( (string) ryugaku_meta( 'country_code' ) ) ); ?></p>
				<h1 class="detail-hero__title"><span aria-hidden="true"><?php echo esc_html( ryugaku_flag( $ryugaku_id ) ); ?></span> <?php the_title(); ?>留学</h1>
				<?php if ( ryugaku_meta( 'catch' ) ) : ?>
					<p class="detail-hero__catch"><?php echo esc_html( ryugaku_meta( 'catch' ) ); ?></p>
				<?php endif; ?>
				<dl class="spec-list">
					<div><dt>1ヶ月の費用目安</dt><dd><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_month', '' ) ) ); ?>〜</dd></div>
					<div><dt>公用語</dt><dd><?php echo esc_html( ryugaku_meta( 'language', '—' ) ); ?></dd></div>
					<div><dt>フライト</dt><dd>約<?php echo esc_html( ryugaku_meta( 'flight_hours', '—' ) ); ?>時間</dd></div>
					<div><dt>時差</dt><dd><?php echo esc_html( ryugaku_meta( 'timezone', '—' ) ); ?></dd></div>
					<div><dt>通貨</dt><dd><?php echo esc_html( ryugaku_meta( 'currency', '—' ) ); ?></dd></div>
					<div><dt>ビザ</dt><dd><?php echo esc_html( ryugaku_meta( 'visa', '—' ) ); ?></dd></div>
				</dl>
				<?php ryugaku_cta_buttons( '', false ); ?>
			</div>
			<div class="detail-hero__media">
				<?php ryugaku_thumbnail( 'ryugaku-hero' ); ?>
			</div>
		</div>
	</section>

	<nav class="local-nav" aria-label="ページ内リンク">
		<div class="container">
			<ul>
				<li><a href="#features">特徴</a></li>
				<li><a href="#recommended">おすすめの人</a></li>
				<li><a href="#cost">費用目安</a></li>
				<li><a href="#cities">人気都市</a></li>
				<li><a href="#schools">学校一覧</a></li>
				<li><a href="#merits">メリット・デメリット</a></li>
				<?php if ( $ryugaku_faq ) : ?><li><a href="#faq">FAQ</a></li><?php endif; ?>
			</ul>
		</div>
	</nav>

	<section class="section" id="features">
		<div class="container container--narrow">
			<?php ryugaku_section_title( get_the_title() . '留学の特徴', 'FEATURES', '', 'left' ); ?>
			<?php ryugaku_check_list( ryugaku_meta_lines( 'features' ), 'check-list check-list--grid' ); ?>
			<?php if ( get_the_content() ) : ?>
				<div class="prose"><?php the_content(); ?></div>
			<?php endif; ?>
		</div>
	</section>

	<?php if ( ryugaku_meta_lines( 'recommended' ) ) : ?>
		<section class="section section--tint" id="recommended">
			<div class="container container--narrow">
				<?php ryugaku_section_title( 'こんな人におすすめ', 'RECOMMENDED', '', 'left' ); ?>
				<?php ryugaku_check_list( ryugaku_meta_lines( 'recommended' ), 'check-list check-list--cards' ); ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="section" id="cost">
		<div class="container container--narrow">
			<?php ryugaku_section_title( '費用目安', 'COST', '授業料＋滞在費の目安です。航空券・海外保険・ビザ申請費は別途。為替や時期により変動します。', 'left' ); ?>
			<div class="cost-cards">
				<?php
				foreach ( array( 'cost_month' => '1ヶ月', 'cost_3month' => '3ヶ月', 'cost_6month' => '6ヶ月', 'cost_year' => '1年' ) as $ryugaku_key => $ryugaku_label ) :
					if ( '' === ryugaku_meta( $ryugaku_key, '' ) ) {
						continue;
					}
					?>
					<div class="cost-card"><span class="cost-card__label"><?php echo esc_html( $ryugaku_label ); ?></span><strong class="cost-card__value"><?php echo esc_html( ryugaku_man( ryugaku_meta( $ryugaku_key ) ) ); ?>〜</strong></div>
				<?php endforeach; ?>
			</div>
			<?php if ( $ryugaku_costs ) : ?>
				<div class="table-wrap">
					<table class="price-table price-table--compact">
						<caption>1ヶ月あたりの内訳例</caption>
						<tbody>
							<?php foreach ( $ryugaku_costs as $ryugaku_row ) : ?>
								<tr><th scope="row"><?php echo esc_html( $ryugaku_row[0] ); ?></th><td><?php echo esc_html( $ryugaku_row[1] ); ?></td></tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
			<p class="section__more"><a class="btn btn--ghost" href="<?php echo esc_url( ryugaku_page_url( 'plan' ) ); ?>">料金プランを詳しく見る<?php echo ryugaku_icon( 'arrow' ); ?></a></p>
		</div>
	</section>

	<?php if ( $ryugaku_cities ) : ?>
		<section class="section section--tint" id="cities">
			<div class="container">
				<?php ryugaku_section_title( '人気都市', 'CITIES', '', 'left' ); ?>
				<div class="grid grid--3">
					<?php foreach ( $ryugaku_cities as $ryugaku_city ) : ?>
						<div class="info-card">
							<h3><?php echo ryugaku_icon( 'pin' ); ?><?php echo esc_html( $ryugaku_city[0] ); ?></h3>
							<p><?php echo esc_html( $ryugaku_city[1] ); ?></p>
							<a class="text-link" href="<?php echo esc_url( add_query_arg( array( 'country' => $ryugaku_id, 'city' => rawurlencode( $ryugaku_city[0] ) ), get_post_type_archive_link( 'school' ) ) ); ?>"><?php echo esc_html( $ryugaku_city[0] ); ?>の学校を見る<?php echo ryugaku_icon( 'arrow' ); ?></a>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<section class="section" id="schools">
		<div class="container">
			<?php ryugaku_section_title( get_the_title() . 'の学校一覧', 'SCHOOLS', '', 'left' ); ?>
			<?php if ( $ryugaku_schools ) : ?>
				<div class="grid grid--3">
					<?php
					global $post;
					foreach ( $ryugaku_schools as $post ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride
						setup_postdata( $post );
						get_template_part( 'template-parts/card', 'school' );
					endforeach;
					wp_reset_postdata();
					?>
				</div>
				<p class="section__more"><a class="btn btn--ghost" href="<?php echo esc_url( add_query_arg( 'country', $ryugaku_id, get_post_type_archive_link( 'school' ) ) ); ?>"><?php the_title(); ?>の学校をすべて見る<?php echo ryugaku_icon( 'arrow' ); ?></a></p>
			<?php else : ?>
				<p>掲載準備中です。ご希望の学校があればカウンセラーまでご相談ください。</p>
			<?php endif; ?>
		</div>
	</section>

	<section class="section section--tint" id="merits">
		<div class="container">
			<?php ryugaku_section_title( 'メリット・デメリット', 'PROS & CONS', '良い面だけでなく注意点も正直にお伝えします。', 'left' ); ?>
			<div class="pros-cons">
				<div class="pros-cons__col pros-cons__col--pro">
					<h3>メリット</h3>
					<?php ryugaku_check_list( ryugaku_meta_lines( 'merits' ) ); ?>
				</div>
				<div class="pros-cons__col pros-cons__col--con">
					<h3>デメリット・注意点</h3>
					<ul class="dash-list">
						<?php foreach ( ryugaku_meta_lines( 'demerits' ) as $ryugaku_line ) : ?>
							<li><?php echo esc_html( $ryugaku_line ); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		</div>
	</section>

	<?php if ( $ryugaku_voices ) : ?>
		<section class="section">
			<div class="container">
				<?php ryugaku_section_title( get_the_title() . '留学の体験談', 'VOICES', '', 'left' ); ?>
				<div class="grid grid--3">
					<?php
					foreach ( $ryugaku_voices as $post ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride
						setup_postdata( $post );
						get_template_part( 'template-parts/card', 'voice' );
					endforeach;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $ryugaku_faq ) : ?>
		<section class="section section--tint" id="faq">
			<div class="container container--narrow">
				<?php ryugaku_section_title( get_the_title() . '留学のよくある質問', 'FAQ', '', 'left' ); ?>
				<?php ryugaku_faq_list( $ryugaku_faq ); ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="section">
		<div class="container inline-cta">
			<h2 class="inline-cta__title"><?php the_title(); ?>留学について相談する</h2>
			<p>費用シミュレーション・学校選び・ビザの疑問など、何でもお気軽に。</p>
			<?php ryugaku_cta_buttons(); ?>
		</div>
	</section>
</article>
<?php get_footer(); ?>
