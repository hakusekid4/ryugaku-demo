<?php
/**
 * 目的から探す(留学タイプ一覧)と比較早見表。
 *
 * @package Ryugaku
 */

get_header();
?>
<?php ryugaku_page_hero( '目的から探す', '語学留学・ワーホリ・インターン・キャリア留学。目的に合った留学のかたちを選びましょう。', 'STUDY TYPES' ); ?>

<section class="section">
	<div class="container">
		<?php if ( have_posts() ) : ?>
			<div class="type-list">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article class="type-row">
						<div class="type-row__media">
							<?php ryugaku_thumbnail( 'ryugaku-card' ); ?>
						</div>
						<div class="type-row__body">
							<p class="type-row__icon" aria-hidden="true"><?php echo esc_html( ryugaku_meta( 'icon', '✈️' ) ); ?></p>
							<h2 class="type-row__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
							<p class="type-row__catch"><?php echo esc_html( ryugaku_meta( 'catch' ) ); ?></p>
							<p><?php echo esc_html( ryugaku_meta( 'overview', ryugaku_excerpt( 90 ) ) ); ?></p>
							<?php
							$ryugaku_suited = array_slice( ryugaku_meta_lines( 'suited' ), 0, 3 );
							if ( $ryugaku_suited ) :
								?>
								<p class="type-row__label">向いている人</p>
								<?php ryugaku_check_list( $ryugaku_suited ); ?>
							<?php endif; ?>
							<a class="btn btn--ghost" href="<?php the_permalink(); ?>"><?php the_title(); ?>を詳しく見る<?php echo ryugaku_icon( 'arrow' ); ?></a>
						</div>
					</article>
				<?php endwhile; ?>
			</div>
		<?php else : ?>
			<?php get_template_part( 'template-parts/no-results' ); ?>
		<?php endif; ?>
	</div>
</section>

<section class="section section--tint">
	<div class="container container--narrow">
		<?php ryugaku_section_title( '目的別 比較早見表', 'COMPARISON' ); ?>
		<div class="table-wrap">
			<table class="price-table">
				<thead><tr><th></th><th>語学留学</th><th>ワーホリ</th><th>インターン</th><th>キャリア</th></tr></thead>
				<tbody>
					<tr><th scope="row">期間の目安</th><td>1週間〜1年</td><td>6ヶ月〜1年</td><td>3ヶ月〜1年</td><td>6ヶ月〜2年</td></tr>
					<tr><th scope="row">必要な英語力</th><td>不問</td><td>初級〜</td><td>中級〜</td><td>中級〜</td></tr>
					<tr><th scope="row">就労</th><td>不可（国による）</td><td>可</td><td>可（有給/無給）</td><td>一部可</td></tr>
					<tr><th scope="row">年齢制限</th><td>なし</td><td>18〜30歳</td><td>なし</td><td>なし</td></tr>
					<tr><th scope="row">費用目安（1ヶ月）</th><td>20〜50万円</td><td>15〜35万円</td><td>20〜40万円</td><td>30〜60万円</td></tr>
				</tbody>
			</table>
		</div>
	</div>
</section>
<?php get_footer(); ?>
