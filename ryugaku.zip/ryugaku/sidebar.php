<?php
/**
 * コラム用サイドバー(CTA・検索・カテゴリ・新着)。
 *
 * @package Ryugaku
 */
?>
<aside class="column-layout__side">
	<div class="widget widget--cta">
		<p class="widget__title">留学の相談は無料です</p>
		<p>費用・国・学校選び、何でもお気軽に。</p>
		<a class="btn btn--line btn--block" href="<?php echo ryugaku_line_url(); ?>" target="_blank" rel="noopener"><span class="btn__icon"><?php echo ryugaku_icon( 'line' ); ?></span>LINEで無料相談</a>
		<a class="btn btn--primary btn--block" href="<?php echo ryugaku_counseling_url(); ?>">無料カウンセリング</a>
	</div>
	<div class="widget">
		<h3 class="widget__title">記事を検索</h3>
		<?php get_search_form(); ?>
	</div>
	<?php
	$ryugaku_cats = get_categories( array( 'hide_empty' => true ) );
	if ( $ryugaku_cats ) :
		?>
		<div class="widget">
			<h3 class="widget__title">カテゴリ</h3>
			<ul class="widget__list">
				<?php foreach ( $ryugaku_cats as $ryugaku_cat ) : ?>
					<li><a href="<?php echo esc_url( get_category_link( $ryugaku_cat ) ); ?>"><?php echo esc_html( $ryugaku_cat->name ); ?><span><?php echo esc_html( $ryugaku_cat->count ); ?></span></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
	<?php
	$ryugaku_recent = get_posts( array( 'posts_per_page' => 5 ) );
	if ( $ryugaku_recent ) :
		?>
		<div class="widget">
			<h3 class="widget__title">新着記事</h3>
			<ul class="widget__posts">
				<?php foreach ( $ryugaku_recent as $ryugaku_p ) : ?>
					<li><a href="<?php echo esc_url( get_permalink( $ryugaku_p ) ); ?>"><?php echo esc_html( $ryugaku_p->post_title ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
	<?php if ( is_active_sidebar( 'sidebar-column' ) ) : ?>
		<?php dynamic_sidebar( 'sidebar-column' ); ?>
	<?php endif; ?>
</aside>
