<?php
/**
 * ページが見つからないときの表示。
 *
 * @package Ryugaku
 */

get_header();
?>
<?php ryugaku_page_hero( 'ページが見つかりません', 'お探しのページは移動または削除された可能性があります。', '404' ); ?>
<section class="section">
	<div class="container container--narrow" style="text-align:center">
		<?php get_search_form(); ?>
		<p style="margin-top:2rem"><a class="btn btn--ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>">トップページへ戻る</a></p>
	</div>
</section>
<?php get_footer(); ?>
