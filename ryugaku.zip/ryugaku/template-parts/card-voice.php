<?php
/**
 * 体験談カード。
 *
 * @package Ryugaku
 */

$ryugaku_country_id = (int) ryugaku_meta( 'voice_country', 0 );
?>
<article class="card card--voice">
	<a class="card__link" href="<?php the_permalink(); ?>">
		<div class="card__media card__media--square">
			<?php ryugaku_thumbnail( 'ryugaku-square' ); ?>
		</div>
		<div class="card__body">
			<p class="card__voice-meta">
				<?php if ( $ryugaku_country_id ) : ?>
					<span><?php echo esc_html( ryugaku_flag( $ryugaku_country_id ) . ' ' . get_the_title( $ryugaku_country_id ) ); ?></span>
				<?php endif; ?>
				<?php if ( ryugaku_meta( 'voice_period' ) ) : ?>
					<span><?php echo esc_html( ryugaku_meta( 'voice_period' ) ); ?></span>
				<?php endif; ?>
				<?php if ( ryugaku_meta( 'voice_type' ) ) : ?>
					<span><?php echo esc_html( ryugaku_meta( 'voice_type' ) ); ?></span>
				<?php endif; ?>
			</p>
			<h3 class="card__title card__title--quote"><?php the_title(); ?></h3>
			<p class="card__person"><?php echo esc_html( ryugaku_meta( 'voice_name' ) ); ?><?php echo ryugaku_meta( 'voice_age' ) ? esc_html( '（' . ryugaku_meta( 'voice_age' ) . '）' ) : ''; ?></p>
		</div>
	</a>
</article>
