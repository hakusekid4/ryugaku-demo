<?php
/**
 * 国カード(一覧・トップで共通)。
 *
 * @package Ryugaku
 */

$ryugaku_rank = isset( $args['rank'] ) ? (int) $args['rank'] : 0;
$ryugaku_id   = get_the_ID();
?>
<article class="card card--country" data-name="<?php echo esc_attr( get_the_title() ); ?>" data-cost="<?php echo esc_attr( ryugaku_meta( 'cost_month', 0 ) ); ?>" data-popular="<?php echo esc_attr( ryugaku_meta( 'popularity', 0 ) ); ?>">
	<a class="card__link" href="<?php the_permalink(); ?>">
		<div class="card__media">
			<?php ryugaku_thumbnail( 'ryugaku-card' ); ?>
			<?php if ( $ryugaku_rank ) : ?>
				<span class="card__rank">No.<?php echo esc_html( $ryugaku_rank ); ?></span>
			<?php endif; ?>
		</div>
		<div class="card__body">
			<h3 class="card__title"><span class="card__flag" aria-hidden="true"><?php echo esc_html( ryugaku_flag( $ryugaku_id ) ); ?></span><?php the_title(); ?></h3>
			<?php if ( ryugaku_meta( 'catch' ) ) : ?>
				<p class="card__catch"><?php echo esc_html( ryugaku_meta( 'catch' ) ); ?></p>
			<?php endif; ?>
			<dl class="card__meta">
				<div><dt><?php echo ryugaku_icon( 'yen' ); ?>1ヶ月目安</dt><dd><?php echo esc_html( ryugaku_man( ryugaku_meta( 'cost_month', '' ) ) ); ?>〜</dd></div>
				<div><dt><?php echo ryugaku_icon( 'clock' ); ?>フライト</dt><dd>約<?php echo esc_html( ryugaku_meta( 'flight_hours', '—' ) ); ?>時間</dd></div>
			</dl>
			<?php
			$ryugaku_terms = get_the_terms( $ryugaku_id, 'study_type' );
			if ( $ryugaku_terms && ! is_wp_error( $ryugaku_terms ) ) :
				?>
				<ul class="tag-list">
					<?php foreach ( array_slice( $ryugaku_terms, 0, 3 ) as $ryugaku_term ) : ?>
						<li><?php echo esc_html( $ryugaku_term->name ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
	</a>
</article>
