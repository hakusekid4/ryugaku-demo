<?php
/**
 * 件数と並び替えタブ。
 *
 * @package Ryugaku
 */

$ryugaku_options = isset( $args['options'] ) ? $args['options'] : array();
$ryugaku_current = ryugaku_current_sort( isset( $args['default'] ) ? $args['default'] : 'popular' );
?>
<div class="sort-bar">
	<p class="sort-bar__count"><?php echo esc_html( number_format_i18n( (int) $GLOBALS['wp_query']->found_posts ) ); ?>件</p>
	<ul class="sort-bar__list" aria-label="並び替え">
		<?php foreach ( $ryugaku_options as $ryugaku_key => $ryugaku_label ) : ?>
			<li><a href="<?php echo ryugaku_archive_url( array( 'sort' => $ryugaku_key ) ); ?>" class="<?php echo $ryugaku_current === $ryugaku_key ? 'is-active' : ''; ?>"<?php echo $ryugaku_current === $ryugaku_key ? ' aria-current="true"' : ''; ?>><?php echo esc_html( $ryugaku_label ); ?></a></li>
		<?php endforeach; ?>
	</ul>
</div>
