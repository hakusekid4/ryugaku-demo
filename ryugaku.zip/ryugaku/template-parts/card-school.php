<?php
/**
 * 学校カード。
 *
 * @package Ryugaku
 */

$ryugaku_country = ryugaku_school_country();
?>
<article class="card card--school">
	<a class="card__link" href="<?php the_permalink(); ?>">
		<div class="card__media">
			<?php ryugaku_thumbnail( 'ryugaku-card' ); ?>
			<?php if ( $ryugaku_country ) : ?>
				<span class="card__badge"><?php echo esc_html( ryugaku_flag( $ryugaku_country->ID ) . ' ' . $ryugaku_country->post_title ); ?><?php echo ryugaku_meta( 'school_city' ) ? esc_html( '・' . ryugaku_meta( 'school_city' ) ) : ''; ?></span>
			<?php endif; ?>
		</div>
		<div class="card__body">
			<h3 class="card__title"><?php the_title(); ?></h3>
			<?php if ( ryugaku_meta( 'school_rating' ) ) : ?>
				<?php ryugaku_stars( ryugaku_meta( 'school_rating' ) ); ?>
			<?php endif; ?>
			<p class="card__catch"><?php echo esc_html( ryugaku_excerpt( 50 ) ); ?></p>
			<dl class="card__meta">
				<div><dt><?php echo ryugaku_icon( 'yen' ); ?>4週間目安</dt><dd><?php echo esc_html( ryugaku_man( ryugaku_meta( 'school_cost_4w', '' ) ) ); ?>〜</dd></div>
				<div><dt>日本人比率</dt><dd><?php echo esc_html( ryugaku_meta( 'school_japanese_ratio', '—' ) ); ?></dd></div>
			</dl>
		</div>
	</a>
</article>
