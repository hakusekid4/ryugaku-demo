<?php
/**
 * 該当なしのときの表示。
 *
 * @package Ryugaku
 */
?>
<div class="no-results">
	<p>条件に合う結果が見つかりませんでした。条件を変えて再度お試しいただくか、カウンセラーにご相談ください。</p>
	<?php ryugaku_cta_buttons(); ?>
</div>
