<?php
/**
 * ページ送り。
 *
 * @package Ryugaku
 */

the_posts_pagination(
	array(
		'mid_size'           => 1,
		'prev_text'          => '前へ',
		'next_text'          => '次へ',
		'screen_reader_text' => 'ページ送り',
		'class'              => 'pagination',
	)
);
