<?php
/**
 * 全ページ下部の CTA 帯(LINE・無料カウンセリング)。
 *
 * @package Ryugaku
 */
?>
<section class="cta-band" id="cta">
	<div class="container cta-band__inner">
		<p class="eyebrow eyebrow--light">FREE CONSULTATION</p>
		<h2 class="cta-band__title">まずは気軽に、<br class="sp-only">留学の相談から。</h2>
		<p class="cta-band__lead">「何から始めればいいかわからない」段階でも大丈夫。留学経験のあるカウンセラーが、あなたの目的・予算・期間に合わせて最適なプランをご提案します。無理な営業は一切ありません。</p>
		<?php ryugaku_cta_buttons( 'lg' ); ?>
		<ul class="cta-band__points">
			<li><?php echo ryugaku_icon( 'check' ); ?>相談・手続き代行 0円</li>
			<li><?php echo ryugaku_icon( 'check' ); ?>オンライン・来社どちらもOK</li>
			<li><?php echo ryugaku_icon( 'check' ); ?>1営業日以内に返信</li>
		</ul>
	</div>
</section>
