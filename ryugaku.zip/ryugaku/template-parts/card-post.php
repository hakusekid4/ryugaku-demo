<?php
/**
 * コラム記事カード。
 *
 * @package Ryugaku
 */

$ryugaku_cats = get_the_category();
?>
<article class="card card--post">
	<a class="card__link" href="<?php the_permalink(); ?>">
		<div class="card__media">
			<?php ryugaku_thumbnail( 'ryugaku-card' ); ?>
			<?php if ( $ryugaku_cats ) : ?>
				<span class="card__badge"><?php echo esc_html( $ryugaku_cats[0]->name ); ?></span>
			<?php endif; ?>
		</div>
		<div class="card__body">
			<h3 class="card__title"><?php the_title(); ?></h3>
			<p class="card__catch"><?php echo esc_html( ryugaku_excerpt( 45 ) ); ?></p>
			<time class="card__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></time>
		</div>
	</a>
</article>
