<?php
/**
 * コラム記事の詳細。本文・記事内 CTA・タグ・関連記事・サイドバー。
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_cats = get_the_category();
?>
<article class="article">
	<div class="container column-layout">
		<div class="column-layout__main">
			<header class="article__header">
				<?php if ( $ryugaku_cats ) : ?>
					<a class="chip is-active" href="<?php echo esc_url( get_category_link( $ryugaku_cats[0] ) ); ?>"><?php echo esc_html( $ryugaku_cats[0]->name ); ?></a>
				<?php endif; ?>
				<h1 class="article__title"><?php the_title(); ?></h1>
				<p class="article__meta">
					<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">公開：<?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></time>
					<?php if ( get_the_modified_date( 'Ymd' ) !== get_the_date( 'Ymd' ) ) : ?>
						<time datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>">更新：<?php echo esc_html( get_the_modified_date( 'Y.m.d' ) ); ?></time>
					<?php endif; ?>
				</p>
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="article__thumb"><?php the_post_thumbnail( 'post-thumbnail', array( 'fetchpriority' => 'high' ) ); ?></div>
				<?php endif; ?>
			</header>

			<div class="prose article__body">
				<?php the_content(); ?>
			</div>

			<div class="inline-cta inline-cta--compact">
				<p class="inline-cta__title">記事を読んで気になったら、まずは無料相談</p>
				<p>費用シミュレーションや国・学校の比較資料を無料でお作りします。</p>
				<?php ryugaku_cta_buttons(); ?>
			</div>

			<?php
			$ryugaku_tags = get_the_tags();
			if ( $ryugaku_tags ) :
				?>
				<ul class="tag-list tag-list--links">
					<?php foreach ( $ryugaku_tags as $ryugaku_tag ) : ?>
						<li><a href="<?php echo esc_url( get_tag_link( $ryugaku_tag ) ); ?>">#<?php echo esc_html( $ryugaku_tag->name ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<?php
			$ryugaku_related = $ryugaku_cats ? get_posts( array( 'posts_per_page' => 3, 'category__in' => wp_list_pluck( $ryugaku_cats, 'term_id' ), 'post__not_in' => array( get_the_ID() ) ) ) : array();
			if ( $ryugaku_related ) :
				?>
				<section class="related">
					<h2 class="related__title">関連記事</h2>
					<div class="grid grid--3">
						<?php
						global $post;
						foreach ( $ryugaku_related as $post ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride
							setup_postdata( $post );
							get_template_part( 'template-parts/card', 'post' );
						endforeach;
						wp_reset_postdata();
						?>
					</div>
				</section>
			<?php endif; ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</article>
<?php get_footer(); ?>
