<?php
/**
 * 通常の固定ページ(規約類など、テンプレート未指定のページ)。
 *
 * @package Ryugaku
 */

get_header();
the_post();
?>
<?php ryugaku_page_hero( get_the_title(), has_excerpt() ? get_the_excerpt() : '' ); ?>
<section class="section">
	<div class="container container--narrow">
		<div class="prose">
			<?php the_content(); ?>
		</div>
	</div>
</section>
<?php get_footer(); ?>
