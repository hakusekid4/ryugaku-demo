<?php
/**
 * 全ページ共通のヘッダー。ロゴ・グローバルナビ・CTA ボタン・スマホ用メニュー開閉ボタン。
 *
 * @package Ryugaku
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">本文へスキップ</a>
<header class="site-header" id="site-header">
	<div class="container site-header__inner">
		<div class="site-header__brand">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a class="site-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
					<span class="site-logo__mark" aria-hidden="true">✈</span>
					<span class="site-logo__text"><?php bloginfo( 'name' ); ?></span>
				</a>
			<?php endif; ?>
		</div>

		<nav class="site-nav" id="site-nav" aria-label="グローバルナビゲーション">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'header',
					'container'      => false,
					'menu_class'     => 'nav-menu',
					'fallback_cb'    => 'ryugaku_fallback_header_menu',
					'depth'          => 2,
				)
			);
			?>
			<div class="site-nav__cta">
				<a class="btn btn--line btn--sm" href="<?php echo ryugaku_line_url(); ?>" target="_blank" rel="noopener"><span class="btn__icon"><?php echo ryugaku_icon( 'line' ); ?></span>LINEで無料相談</a>
				<a class="btn btn--primary btn--sm" href="<?php echo ryugaku_counseling_url(); ?>"><span class="btn__icon"><?php echo ryugaku_icon( 'calendar' ); ?></span>無料カウンセリング</a>
			</div>
		</nav>

		<button class="nav-toggle" type="button" aria-controls="site-nav" aria-expanded="false" aria-label="メニューを開く">
			<span class="nav-toggle__open"><?php echo ryugaku_icon( 'menu' ); ?></span>
			<span class="nav-toggle__close"><?php echo ryugaku_icon( 'close' ); ?></span>
		</button>
	</div>
</header>
<?php if ( ! is_front_page() ) : ?>
	<?php ryugaku_breadcrumb(); ?>
<?php endif; ?>
<main id="main" class="site-main">
