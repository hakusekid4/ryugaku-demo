<?php
/**
 * サイト内検索フォーム。
 *
 * @package Ryugaku
 */
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label>
		<span class="screen-reader-text">サイト内検索</span>
		<input type="search" class="search-form__input" placeholder="キーワードで検索" value="<?php echo get_search_query(); ?>" name="s">
	</label>
	<button type="submit" class="search-form__submit" aria-label="検索"><?php echo ryugaku_icon( 'search' ); ?></button>
</form>
