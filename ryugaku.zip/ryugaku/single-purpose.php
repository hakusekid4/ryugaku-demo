<?php
/**
 * 留学タイプ詳細。概要・メリット・向いている人・費用・期間・おすすめの国・FAQ・CTA。
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_merits = ryugaku_meta_pairs( 'merits' );
$ryugaku_costs  = ryugaku_meta_pairs( 'cost' );
$ryugaku_period = ryugaku_meta_pairs( 'period' );
$ryugaku_faq    = ryugaku_meta_pairs( 'faq' );
$ryugaku_slug   = ryugaku_meta( 'type_slug', '' );
$ryugaku_countries = $ryugaku_slug ? get_posts(
	array(
		'post_type'      => 'country',
		'posts_per_page' => 6,
		'meta_key'       => '_ryugaku_popularity',
		'orderby'        => 'meta_value_num',
		'order'          => 'DESC',
		'tax_query'      => array( array( 'taxonomy' => 'study_type', 'field' => 'slug', 'terms' => $ryugaku_slug ) ),
	)
) : array();
?>
<article class="purpose">
	<section class="detail-hero">
		<div class="container detail-hero__inner">
			<div class="detail-hero__text">
				<p class="eyebrow">STUDY TYPE</p>
				<h1 class="detail-hero__title"><span aria-hidden="true"><?php echo esc_html( ryugaku_meta( 'icon', '✈️' ) ); ?></span> <?php the_title(); ?></h1>
				<?php if ( ryugaku_meta( 'catch' ) ) : ?>
					<p class="detail-hero__catch"><?php echo esc_html( ryugaku_meta( 'catch' ) ); ?></p>
				<?php endif; ?>
				<?php ryugaku_cta_buttons( '', false ); ?>
			</div>
			<div class="detail-hero__media">
				<?php ryugaku_thumbnail( 'ryugaku-hero' ); ?>
			</div>
		</div>
	</section>

	<nav class="local-nav" aria-label="ページ内リンク">
		<div class="container">
			<ul>
				<li><a href="#overview">概要</a></li>
				<li><a href="#merits">メリット</a></li>
				<li><a href="#suited">向いている人</a></li>
				<li><a href="#cost">費用</a></li>
				<li><a href="#period">期間</a></li>
				<?php if ( $ryugaku_faq ) : ?><li><a href="#faq">FAQ</a></li><?php endif; ?>
			</ul>
		</div>
	</nav>

	<section class="section" id="overview">
		<div class="container container--narrow">
			<?php ryugaku_section_title( get_the_title() . 'とは', 'OVERVIEW', '', 'left' ); ?>
			<?php if ( ryugaku_meta( 'overview' ) ) : ?>
				<p class="lead-text"><?php echo esc_html( ryugaku_meta( 'overview' ) ); ?></p>
			<?php endif; ?>
			<?php if ( get_the_content() ) : ?>
				<div class="prose"><?php the_content(); ?></div>
			<?php endif; ?>
		</div>
	</section>

	<?php if ( $ryugaku_merits ) : ?>
		<section class="section section--tint" id="merits">
			<div class="container">
				<?php ryugaku_section_title( get_the_title() . 'のメリット', 'MERITS', '', 'left' ); ?>
				<div class="grid grid--3">
					<?php foreach ( $ryugaku_merits as $ryugaku_i => $ryugaku_m ) : ?>
						<div class="reason"><span class="reason__num"><?php echo esc_html( sprintf( '%02d', $ryugaku_i + 1 ) ); ?></span><h3><?php echo esc_html( $ryugaku_m[0] ); ?></h3><p><?php echo esc_html( $ryugaku_m[1] ); ?></p></div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<section class="section" id="suited">
		<div class="container container--narrow">
			<?php ryugaku_section_title( 'こんな人に向いています', 'RECOMMENDED', '', 'left' ); ?>
			<?php ryugaku_check_list( ryugaku_meta_lines( 'suited' ), 'check-list check-list--cards' ); ?>
		</div>
	</section>

	<?php if ( $ryugaku_costs ) : ?>
		<section class="section section--tint" id="cost">
			<div class="container container--narrow">
				<?php ryugaku_section_title( '費用の目安', 'COST', '為替・時期・学校により変動します。正確な見積もりはカウンセリングでご案内します。', 'left' ); ?>
				<div class="table-wrap">
					<table class="price-table price-table--compact">
						<tbody>
							<?php foreach ( $ryugaku_costs as $ryugaku_row ) : ?>
								<tr><th scope="row"><?php echo esc_html( $ryugaku_row[0] ); ?></th><td><?php echo esc_html( $ryugaku_row[1] ); ?></td></tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $ryugaku_period ) : ?>
		<section class="section" id="period">
			<div class="container container--narrow">
				<?php ryugaku_section_title( '期間の目安', 'PERIOD', '', 'left' ); ?>
				<div class="timeline timeline--compact">
					<?php foreach ( $ryugaku_period as $ryugaku_row ) : ?>
						<div class="timeline__item"><h3><?php echo esc_html( $ryugaku_row[0] ); ?></h3><p><?php echo esc_html( $ryugaku_row[1] ); ?></p></div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $ryugaku_countries ) : ?>
		<section class="section section--tint">
			<div class="container">
				<?php ryugaku_section_title( get_the_title() . 'におすすめの国', 'COUNTRIES', '', 'left' ); ?>
				<div class="grid grid--3">
					<?php
					global $post;
					foreach ( $ryugaku_countries as $post ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride
						setup_postdata( $post );
						get_template_part( 'template-parts/card', 'country' );
					endforeach;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $ryugaku_faq ) : ?>
		<section class="section" id="faq">
			<div class="container container--narrow">
				<?php ryugaku_section_title( 'よくある質問', 'FAQ', '', 'left' ); ?>
				<?php ryugaku_faq_list( $ryugaku_faq ); ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="section section--tint">
		<div class="container inline-cta">
			<h2 class="inline-cta__title"><?php the_title(); ?>について相談する</h2>
			<p>あなたの状況に合わせて、国・学校・期間・費用のプランをご提案します。</p>
			<?php ryugaku_cta_buttons(); ?>
		</div>
	</section>
</article>
<?php get_footer(); ?>
