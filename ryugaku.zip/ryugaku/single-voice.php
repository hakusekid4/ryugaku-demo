<?php
/**
 * 体験談詳細。留学前の悩み → インタビュー → 写真 → 留学後の変化 → CTA → 保護者の声 → キャリア。
 *
 * @package Ryugaku
 */

get_header();
the_post();
$ryugaku_country_id = (int) ryugaku_meta( 'voice_country', 0 );
$ryugaku_school_id  = (int) ryugaku_meta( 'voice_school', 0 );
$ryugaku_photos     = array_filter( array_map( 'absint', explode( ',', (string) ryugaku_meta( 'voice_photos', '' ) ) ) );
$ryugaku_related    = get_posts( array( 'post_type' => 'voice', 'posts_per_page' => 3, 'post__not_in' => array( get_the_ID() ) ) );
?>
<article class="voice">
	<section class="detail-hero detail-hero--voice">
		<div class="container detail-hero__inner">
			<div class="detail-hero__text">
				<p class="eyebrow">INTERVIEW</p>
				<h1 class="detail-hero__title detail-hero__title--quote"><?php the_title(); ?></h1>
				<p class="voice__person"><strong><?php echo esc_html( ryugaku_meta( 'voice_name' ) ); ?></strong><?php echo ryugaku_meta( 'voice_age' ) ? esc_html( '（' . ryugaku_meta( 'voice_age' ) . '）' ) : ''; ?></p>
				<dl class="spec-list">
					<?php if ( $ryugaku_country_id ) : ?><div><dt>留学先</dt><dd><a href="<?php echo esc_url( get_permalink( $ryugaku_country_id ) ); ?>"><?php echo esc_html( ryugaku_flag( $ryugaku_country_id ) . ' ' . get_the_title( $ryugaku_country_id ) ); ?></a></dd></div><?php endif; ?>
					<?php if ( $ryugaku_school_id ) : ?><div><dt>学校</dt><dd><a href="<?php echo esc_url( get_permalink( $ryugaku_school_id ) ); ?>"><?php echo esc_html( get_the_title( $ryugaku_school_id ) ); ?></a></dd></div><?php endif; ?>
					<?php if ( ryugaku_meta( 'voice_period' ) ) : ?><div><dt>期間</dt><dd><?php echo esc_html( ryugaku_meta( 'voice_period' ) ); ?></dd></div><?php endif; ?>
					<?php if ( ryugaku_meta( 'voice_type' ) ) : ?><div><dt>留学タイプ</dt><dd><?php echo esc_html( ryugaku_meta( 'voice_type' ) ); ?></dd></div><?php endif; ?>
				</dl>
			</div>
			<div class="detail-hero__media detail-hero__media--square">
				<?php ryugaku_thumbnail( 'ryugaku-square' ); ?>
			</div>
		</div>
	</section>

	<div class="container container--narrow">
		<?php if ( ryugaku_meta( 'voice_before' ) ) : ?>
			<section class="section voice__block">
				<p class="eyebrow">BEFORE</p>
				<h2>留学前の悩み</h2>
				<div class="voice__quote"><?php echo wp_kses_post( wpautop( ryugaku_meta( 'voice_before' ) ) ); ?></div>
			</section>
		<?php endif; ?>

		<?php if ( get_the_content() ) : ?>
			<section class="section voice__block">
				<p class="eyebrow">INTERVIEW</p>
				<h2>留学中のこと</h2>
				<div class="prose"><?php the_content(); ?></div>
			</section>
		<?php endif; ?>

		<?php if ( $ryugaku_photos ) : ?>
			<section class="section voice__block">
				<p class="eyebrow">PHOTOS</p>
				<h2>留学中の写真</h2>
				<div class="photo-grid">
					<?php foreach ( $ryugaku_photos as $ryugaku_photo ) : ?>
						<?php echo wp_get_attachment_image( $ryugaku_photo, 'ryugaku-card', false, array( 'loading' => 'lazy' ) ); ?>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endif; ?>

		<?php if ( ryugaku_meta( 'voice_after' ) ) : ?>
			<section class="section voice__block">
				<p class="eyebrow">AFTER</p>
				<h2>留学後の変化</h2>
				<div class="voice__quote voice__quote--after"><?php echo wp_kses_post( wpautop( ryugaku_meta( 'voice_after' ) ) ); ?></div>
			</section>
		<?php endif; ?>

		<div class="inline-cta inline-cta--compact">
			<p class="inline-cta__title">同じような留学をしてみたい方へ</p>
			<?php ryugaku_cta_buttons(); ?>
		</div>

		<?php if ( ryugaku_meta( 'voice_parent' ) ) : ?>
			<section class="section voice__block">
				<p class="eyebrow">PARENTS</p>
				<h2>保護者の声</h2>
				<div class="voice__quote voice__quote--parent"><?php echo wp_kses_post( wpautop( ryugaku_meta( 'voice_parent' ) ) ); ?></div>
			</section>
		<?php endif; ?>

		<?php if ( ryugaku_meta( 'voice_career' ) ) : ?>
			<section class="section voice__block">
				<p class="eyebrow">CAREER</p>
				<h2>卒業後のキャリア</h2>
				<div class="voice__quote"><?php echo wp_kses_post( wpautop( ryugaku_meta( 'voice_career' ) ) ); ?></div>
			</section>
		<?php endif; ?>
	</div>

	<?php if ( $ryugaku_related ) : ?>
		<section class="section section--tint">
			<div class="container">
				<?php ryugaku_section_title( 'ほかの体験談', 'MORE VOICES', '', 'left' ); ?>
				<div class="grid grid--3">
					<?php
					global $post;
					foreach ( $ryugaku_related as $post ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride
						setup_postdata( $post );
						get_template_part( 'template-parts/card', 'voice' );
					endforeach;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
	<?php endif; ?>
</article>
<?php get_footer(); ?>
